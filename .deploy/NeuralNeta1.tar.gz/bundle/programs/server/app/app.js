var require = meteorInstall({"imports":{"api":{"images":{"images.js":["meteor/mongo","meteor/aldeed:simple-schema",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/images/images.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({Images:function(){return Images},Thumbs:function(){return Thumbs}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});
                                                                                                                       // 2
                                                                                                                       //
var Images = new Mongo.Collection('images');                                                                           // 4
var Thumbs = new Mongo.Collection('thumbs');                                                                           // 5
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"comments.js":["meteor/mongo","meteor/aldeed:simple-schema","meteor/accounts-base","./resources.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/comments.js                                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({Comments:function(){return Comments}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var Accounts;module.import('meteor/accounts-base',{"Accounts":function(v){Accounts=v}});var Resources;module.import('./resources.js',{"Resources":function(v){Resources=v}});
                                                                                                                       // 2
                                                                                                                       //
                                                                                                                       // 4
                                                                                                                       // 5
                                                                                                                       //
var Comments = new Mongo.Collection('Comments');                                                                       // 8
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"resources.js":["meteor/mongo","meteor/aldeed:simple-schema","meteor/accounts-base","./comments.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/resources.js                                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({Resources:function(){return Resources}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var Accounts;module.import('meteor/accounts-base',{"Accounts":function(v){Accounts=v}});var Comments;module.import('./comments.js',{"Comments":function(v){Comments=v}});
                                                                                                                       // 2
                                                                                                                       //
                                                                                                                       // 4
                                                                                                                       // 5
                                                                                                                       //
/*class ResourcesCollection extends Mongo.Collection {                                                                 // 7
                                                                                                                       //
}*/                                                                                                                    //
                                                                                                                       //
var Resources = new Mongo.Collection('Resources');                                                                     // 11
                                                                                                                       //
Meteor.methods({                                                                                                       // 14
  //add resource id to users list of favorited Resources                                                               // 15
  'addFavorite': function () {                                                                                         // 16
    function addFavorite(resourceID) {                                                                                 // 16
      var currentUserId = Meteor.userId();                                                                             // 17
      Meteor.users.update({ _id: currentUserId }, { $push: { favoritedResources: resourceID } });                      // 18
    }                                                                                                                  // 19
                                                                                                                       //
    return addFavorite;                                                                                                // 16
  }(),                                                                                                                 // 16
  /*                                                                                                                   // 20
    'getFavorites': function() {                                                                                       //
      //check if a resource is in the favorite list                                                                    //
      var currentUserId = Meteor.userId();                                                                             //
      return Meteor.users.find({ favoritedResources: resourceID });                                                    //
    },*/                                                                                                               //
                                                                                                                       //
  'removeFavorite': function () {                                                                                      // 27
    function removeFavorite(resourceID) {                                                                              // 27
      //removes ID from favorited list - mollie put checks in here                                                     // 28
      var currentUserId = Meteor.userId();                                                                             // 29
      Meteor.users.update({ _id: currentUserId }, { $pull: { favoritedResources: resourceID } });                      // 30
    }                                                                                                                  // 31
                                                                                                                       //
    return removeFavorite;                                                                                             // 27
  }(),                                                                                                                 // 27
                                                                                                                       //
  'getResource': function () {                                                                                         // 33
    function getResource(resourceID) {                                                                                 // 33
      // console.log(Resources.find({_id: resourceID}).fetch());                                                       // 34
      return Resources.find({ _id: resourceID }).fetch();                                                              // 35
    }                                                                                                                  // 36
                                                                                                                       //
    return getResource;                                                                                                // 33
  }(),                                                                                                                 // 33
                                                                                                                       //
  'getFavorites': function () {                                                                                        // 38
    function getFavorites(resourceIDs) {                                                                               // 38
      if (!this.userId) return null;                                                                                   // 39
      var favorites = [];                                                                                              // 40
                                                                                                                       //
      for (i in meteorBabelHelpers.sanitizeForInObject(resourceIDs)) {                                                 // 42
        var obj = Resources.find({ _id: resourceIDs[i] }).fetch();                                                     // 43
        //console.log("resourceID " + resourceIDs[i]);                                                                 // 44
        //console.log(obj[0]);                                                                                         // 45
        favorites.push(obj[0]);                                                                                        // 46
      }                                                                                                                // 47
                                                                                                                       //
      //console.log(favorites);                                                                                        // 49
      return favorites;                                                                                                // 50
    }                                                                                                                  // 51
                                                                                                                       //
    return getFavorites;                                                                                               // 38
  }()                                                                                                                  // 38
});                                                                                                                    // 14
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"mup.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// mup.js                                                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/*                                                                                                                     // 1
to push:                                                                                                               //
cd to project folder                                                                                                   //
meteor build .deploy --debug --architecture os.linux.x86_64                                                            //
cd to .deploy                                                                                                          //
mup init                                                                                                               //
mup.cmd setup                                                                                                          //
mup.cmd deploy                                                                                                         //
*/                                                                                                                     //
                                                                                                                       //
module.exports = {                                                                                                     // 11
  servers: {                                                                                                           // 12
    one: {                                                                                                             // 13
      host: '54.200.31.83',                                                                                            // 14
      username: 'ubuntu',                                                                                              // 15
      pem: 'C:/Users/molli_000/Documents/GitHub/NeuralNeta1/neuralnet-kp-actual.ppk'                                   // 16
      // password:                                                                                                     // 17
      // or leave blank for authenticate from ssh-agent                                                                // 18
    }                                                                                                                  // 13
  },                                                                                                                   // 12
                                                                                                                       //
  meteor: {                                                                                                            // 22
    name: 'NeuralNeta1',                                                                                               // 23
    path: 'C:/Users/molli_000/Documents/GitHub/NeuralNeta1/.deploy',                                                   // 24
    servers: {                                                                                                         // 25
      one: {}                                                                                                          // 26
    },                                                                                                                 // 25
    buildOptions: {                                                                                                    // 28
      serverOnly: true,                                                                                                // 29
      debug: true                                                                                                      // 30
    },                                                                                                                 // 28
    env: {                                                                                                             // 32
      //ROOT_URL: 'app.com',                                                                                           // 33
      MONGO_URL: 'mongodb://localhostlocalhost:27017/meteor'                                                           // 34
    },                                                                                                                 // 32
    dockerImage: "abernix/meteord:base",                                                                               // 36
    deployCheckWaitTime: 60                                                                                            // 37
  },                                                                                                                   // 22
                                                                                                                       //
  mongo: {                                                                                                             // 40
    oplog: true,                                                                                                       // 41
    port: 27017,                                                                                                       // 42
    servers: {                                                                                                         // 43
      one: {}                                                                                                          // 44
    }                                                                                                                  // 43
  }                                                                                                                    // 40
};                                                                                                                     // 11
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"server":{"main.js":["meteor/accounts-base","../imports/api/resources.js","../imports/api/comments.js","../imports/api/images/images.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/main.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Accounts;module.import('meteor/accounts-base',{"Accounts":function(v){Accounts=v}});var Resources;module.import('../imports/api/resources.js',{"Resources":function(v){Resources=v}});var Comments;module.import('../imports/api/comments.js',{"Comments":function(v){Comments=v}});module.import('../imports/api/images/images.js');//import angular from 'angular';
//import angularMeteor from 'angular-meteor';                                                                          // 2
                                                                                                                       //
                                                                                                                       // 4
                                                                                                                       // 5
                                                                                                                       // 6
                                                                                                                       // 7
                                                                                                                       //
Accounts.onCreateUser(function (options, user) {                                                                       // 11
                                                                                                                       //
  user.userXP = 0;                                                                                                     // 13
  Meteor.users.update(user, {});                                                                                       // 14
                                                                                                                       //
  return user;                                                                                                         // 18
});                                                                                                                    // 19
                                                                                                                       //
Meteor.publish('userXP', function () {                                                                                 // 22
  if (!this.userId) return null;                                                                                       // 23
                                                                                                                       //
  return Meteor.users.find(this.userId, { fields: { 'userXP': 1 } });                                                  // 25
});                                                                                                                    // 26
                                                                                                                       //
Meteor.publish('favoritedResources', function () {                                                                     // 28
  if (!this.userId) return null;                                                                                       // 29
                                                                                                                       //
  return Meteor.users.find(this.userId, { fields: { 'favoritedResources': 1 } });                                      // 31
});                                                                                                                    // 32
                                                                                                                       //
Meteor.publish('favoriteObjects', function () {                                                                        // 34
  /*  if(!this.userId) return null;                                                                                    // 35
    var favorites = [];                                                                                                //
    var fResources = Meteor.users.find(this.userId, {fields: {'favoritedResources': 1,}}),                             //
                                                                                                                       //
    for(var i=0; i<fResources.length; i++) {                                                                           //
      var obj = Resources.find({_id: fResources[i]});                                                                  //
      console.log("resourceID " + fResources[i]);                                                                      //
      console.log(obj);                                                                                                //
      favorites.push(obj);                                                                                             //
    }                                                                                                                  //
                                                                                                                       //
    console.log(favorites);                                                                                            //
    return favorites;*/                                                                                                //
});                                                                                                                    // 48
                                                                                                                       //
Meteor.publish('resources', function () {                                                                              // 50
  if (!this.userId) return null;                                                                                       // 51
  return Resources.find({});                                                                                           // 52
});                                                                                                                    // 53
                                                                                                                       //
if (Comments.find().count() === 0) {                                                                                   // 55
  console.log("comments db empty");                                                                                    // 56
  var data1 = [{                                                                                                       // 57
    "ResourceID": "",                                                                                                  // 59
    "Resource_Title": "Minecraft",                                                                                     // 60
    "Author": "Mollie Harms",                                                                                          // 61
    "Title": "Amazing with the right direction",                                                                       // 62
    "Body": "test",                                                                                                    // 63
    "Created_On": "09/09/2016",                                                                                        // 64
    "Comment_Rating": "5",                                                                                             // 65
    "Prep_Time": "3",                                                                                                  // 66
    "Differentiated_Instruction": "5",                                                                                 // 67
    "End_Comprehension": "4",                                                                                          // 68
    "Applicability": "5"                                                                                               // 69
  }, {                                                                                                                 // 58
    "ResourceID": "",                                                                                                  // 72
    "Resource_Title": "Minecraft",                                                                                     // 73
    "Author": "Mollie Harms",                                                                                          // 74
    "Title": "Amazing with the right direction",                                                                       // 75
    "Body": "test",                                                                                                    // 76
    "Created_On": "09/09/2016",                                                                                        // 77
    "Comment_Rating": "5",                                                                                             // 78
    "Prep_Time": "3",                                                                                                  // 79
    "Differentiated_Instruction": "5",                                                                                 // 80
    "End_Comprehension": "4",                                                                                          // 81
    "Applicability": "5"                                                                                               // 82
  }, {                                                                                                                 // 71
    "ResourceID": "",                                                                                                  // 85
    "Resource_Title": "Minecraft",                                                                                     // 86
    "Author": "Mollie Harms",                                                                                          // 87
    "Title": "Amazing with the right direction",                                                                       // 88
    "Body": "test",                                                                                                    // 89
    "Created_On": "09/09/2016",                                                                                        // 90
    "Comment_Rating": "5",                                                                                             // 91
    "Prep_Time": "3",                                                                                                  // 92
    "Differentiated_Instruction": "5",                                                                                 // 93
    "End_Comprehension": "4",                                                                                          // 94
    "Applicability": "5"                                                                                               // 95
  }, {                                                                                                                 // 84
    "ResourceID": "",                                                                                                  // 98
    "Resource_Title": "Minecraft",                                                                                     // 99
    "Author": "Mollie Harms",                                                                                          // 100
    "Title": "Amazing with the right direction",                                                                       // 101
    "Body": "test",                                                                                                    // 102
    "Created_On": "09/09/2016",                                                                                        // 103
    "Comment_Rating": "5",                                                                                             // 104
    "Prep_Time": "3",                                                                                                  // 105
    "Differentiated_Instruction": "5",                                                                                 // 106
    "End_Comprehension": "4",                                                                                          // 107
    "Applicability": "5"                                                                                               // 108
  }];                                                                                                                  // 97
                                                                                                                       //
  for (var i = 0; i < data1.length; i++) {                                                                             // 112
    Comments.insert(data1[i]);                                                                                         // 113
  }                                                                                                                    // 114
}                                                                                                                      // 115
                                                                                                                       //
//if(Resources.find().count() === 0) {                                                                                 // 118
console.log("mongo db empty");                                                                                         // 119
var data = [{                                                                                                          // 120
  "Type": "Video Game",                                                                                                // 122
  "Title": "Concussion Game",                                                                                          // 123
  "Location": "https://www.superbetter.com/",                                                                          // 124
  "Platform": "iOS, Android",                                                                                          // 125
  "Recommended_Ages": "All Ages",                                                                                      // 126
  "Summary": "",                                                                                                       // 127
  "Description": "SuperBetter increases resilience - the ability to stay strong, motivated and optimistic even in the face of difficult obstacles. Playing SuperBetter makes you more capable of getting through any tough situation—and more likely to achieve the goals that matter most to you. Proven results in just 10 minutes a day.",
  "Subjects": "",                                                                                                      // 129
  "Image": "temp-resources/minecraft_5.jpg",                                                                           // 130
  "CC_Tags": ["CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1"]
}, {                                                                                                                   // 121
  "Type": "Videos",                                                                                                    // 134
  "Title": "The Great Courses",                                                                                        // 135
  "Location": "http://www.thegreatcourses.com/",                                                                       // 136
  "Platform": "Website",                                                                                               // 137
  "Recommended_Ages": "Adult",                                                                                         // 138
  "Summary": "",                                                                                                       // 139
  "Description": "",                                                                                                   // 140
  "Subjects": "",                                                                                                      // 141
  "Image": "temp-resources/minecraft_5.jpg",                                                                           // 142
  "CC_Tags": ["CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1"]
}, {                                                                                                                   // 133
  "Type": "Video Game",                                                                                                // 146
  "Title": "Gambit Labs",                                                                                              // 147
  "Location": "http://gambit.mit.edu/index.php",                                                                       // 148
  "Platform": "PC",                                                                                                    // 149
  "Recommended_Ages": "All Ages",                                                                                      // 150
  "Summary": "There are tons here, need to be broken out individually",                                                // 151
  "Description": "",                                                                                                   // 152
  "Subjects": "",                                                                                                      // 153
  "Image": "temp-resources/minecraft_5.jpg",                                                                           // 154
  "CC_Tags": ["CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1"],
  "Connections": ["Rich G.", "Mollie H.", "Leah W.", "Kevin F.", "Elsida K.", "Renis S.", "Phil W.", "Jess K."]        // 156
}, {                                                                                                                   // 145
  "Type": "Video Game",                                                                                                // 159
  "Title": "Minecraft",                                                                                                // 160
  "Location": "http://education.minecraft.net/",                                                                       // 161
  "Platform": "PC",                                                                                                    // 162
  "Recommended_Ages": "All Ages",                                                                                      // 163
  "Summary": "Minecraft encourages millions of players to create, explore, and discover. We want to bring that passion into the classroom. Join us as we create a Minecraft built for learning",
  "Description": "",                                                                                                   // 165
  "Subjects": "",                                                                                                      // 166
  "Image": "temp-resources/minecraft_5.jpg",                                                                           // 167
  "CC_Tags": ["CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1"],
  "Connections": ["Rich G.", "Mollie H.", "Leah W.", "Kevin F.", "Elsida K.", "Renis S.", "Phil W.", "Jess K."]        // 169
}, {                                                                                                                   // 158
  "Type": "Video Game",                                                                                                // 172
  "Title": "ScribbleNauts",                                                                                            // 173
  "Location": "",                                                                                                      // 174
  "Platform": "3DS, Wii U, PC",                                                                                        // 175
  "Recommended_Ages": "Grades 3+",                                                                                     // 176
  "Summary": "",                                                                                                       // 177
  "Description": "5th Cell takes a step forward towards creating a balance between education and Video Gameplay with Scribblenauts. The puzzle game makes an attempt to expand your vocabulary by encouraging you to use different words to solve things, but it also has a cutesy, gamer-y element of using those words in a video game manner. We haven’t seen something like that since the typing games of old like Mavis Beacon, who blend game activities with letter-typing reflex.",
  "Subjects": "English, Art",                                                                                          // 179
  "Image": "temp-resources/scribblenauts-unlimited-wii-u-screenshot-2.jpg",                                            // 180
  "CC_Tags": ["CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1"],
  "Connections": ["Rich G.", "Mollie H.", "Leah W.", "Kevin F.", "Elsida K.", "Renis S.", "Phil W.", "Jess K."]        // 182
}, {                                                                                                                   // 171
  "Type": "Video Game",                                                                                                // 185
  "Title": "Oregon Trail",                                                                                             // 186
  "Location": "",                                                                                                      // 187
  "Platform": "PC",                                                                                                    // 188
  "Recommended_Ages": "Grades 3-6",                                                                                    // 189
  "Summary": "A PC game where students travel and experience the difficulties of travelling the Oregon Trail",         // 190
  "Description": "The Oregon Trail is a computer game originally developed by Don Rawitsch, Bill Heinemann, and Paul Dillenberger in 1971 and produced by the Minnesota Educational Computing Consortium (MECC) in 1974. The original game was designed to teach school children about the realities of 19th century pioneer life on the Oregon Trail. The player assumes the role of a wagon leader guiding his or her party of settlers from Independence, Missouri, to Oregon's Willamette Valley on the Oregon Trail via a covered wagon in 1848. The game is the first entry in the Oregon Trail series of games, and has since been released in many editions by various developers and publishers who have acquired rights to it, as well as inspiring a number of spinoffs (such as The Yukon Trail and The Amazon Trail) and the parody The Organ Trail.",
  "Subjects": "History, Geography",                                                                                    // 192
  "Image": "temp-resources/oregontrail2.jpg",                                                                          // 193
  "CC_Tags": ["CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1"],
  "Connections": ["Rich G.", "Mollie H.", "Leah W.", "Kevin F.", "Elsida K.", "Renis S.", "Phil W.", "Jess K."]        // 195
}, {                                                                                                                   // 184
  "Type": "Video Game",                                                                                                // 198
  "Title": "Zoo Tycoon",                                                                                               // 199
  "Location": "",                                                                                                      // 200
  "Platform": "PC, XBox360, XBox One",                                                                                 // 201
  "Recommended_Ages": "Grades 3+",                                                                                     // 202
  "Summary": "A series of games where you manage a zoo",                                                               // 203
  "Description": "Zoo Tycoon is a series of business simulation video games. The games focus around building and running successful zoo scenarios. The series was initially developed by Blue Fang Games and published by Microsoft Studios who later in 2001-2008 went on to create two stand-alone video games and seven expansion packs for PC and Macintosh platforms. With their contract with Microsoft ending in 2009, Blue Fang announced their official forums would close to incoming posts in June of 2008.[1] In 2013, Microsoft Studios released a new Zoo Tycoon game, developed by Frontier Developments exclusively for Xbox One and Xbox 360 in 2013. https://en.wikipedia.org/wiki/Zoo_Tycoon_(series)",
  "Subjects": "Math, Economics",                                                                                       // 205
  "Image": "temp-resources/zoo-tycoon-5.jpg",                                                                          // 206
  "CC_Tags": ["CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1"],
  "Connections": ["Rich G.", "Mollie H.", "Leah W.", "Kevin F.", "Elsida K.", "Renis S.", "Phil W.", "Jess K."]        // 208
}, {                                                                                                                   // 197
  "Type": "Video Game",                                                                                                // 211
  "Title": "Professor_Layton",                                                                                         // 212
  "Location": "https://en.wikipedia.org/wiki/Professor_Layton",                                                        // 213
  "Platform": "Nintendo DS",                                                                                           // 214
  "Recommended_Ages": "All Ages",                                                                                      // 215
  "Summary": "A series of turn based strategy games.",                                                                 // 216
  "Description": "Civilization is the game that lets you match wits with history’s greatest leaders. You start at the dawn of recorded history – 4,000 B.C., and the founding of the first cities – then nurture your society toward the Space Age. In the beginning, you’ll labor to simply survive while building your settlements, discovering new technologies and fending off barbarians. As your empire prospers, you’ll face competing civilizations guided by history’s most legendary figures: Alexander the Great, Napoleon, Genghis Khan, Julius Caesar and more. You’ll test your capacity for expansion and domination and your ability to outwit and outmaneuver those cunning and brilliant leaders.",
  "Subjects": "Reading, Critical Thinking",                                                                            // 218
  "Image": "temp-resources/civilization-v.jpg",                                                                        // 219
  "CC_Tags": ["CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1"],
  "Connections": ["Rich G.", "Mollie H.", "Leah W.", "Kevin F.", "Elsida K.", "Renis S.", "Phil W.", "Jess K."]        // 221
}, {                                                                                                                   // 210
  "Type": "Video Game",                                                                                                // 224
  "Title": "Civilization Series",                                                                                      // 225
  "Location": "http://www.civilization.com/en/home/",                                                                  // 226
  "Platform": "All",                                                                                                   // 227
  "Recommended_Ages": "Grades 5+",                                                                                     // 228
  "Summary": "A series of turn based strategy games.",                                                                 // 229
  "Description": "Civilization is the game that lets you match wits with history’s greatest leaders. You start at the dawn of recorded history – 4,000 B.C., and the founding of the first cities – then nurture your society toward the Space Age. In the beginning, you’ll labor to simply survive while building your settlements, discovering new technologies and fending off barbarians. As your empire prospers, you’ll face competing civilizations guided by history’s most legendary figures: Alexander the Great, Napoleon, Genghis Khan, Julius Caesar and more. You’ll test your capacity for expansion and domination and your ability to outwit and outmaneuver those cunning and brilliant leaders.",
  "Subjects": "Reading, Critical Thinking",                                                                            // 231
  "Image": "temp-resources/civilization-v.jpg",                                                                        // 232
  "CC_Tags": ["CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1"],
  "Connections": ["Rich G.", "Mollie H.", "Leah W.", "Kevin F.", "Elsida K.", "Renis S.", "Phil W.", "Jess K."]        // 234
}, {                                                                                                                   // 223
  "Type": "Video Game",                                                                                                // 237
  "Title": "Braid",                                                                                                    // 238
  "Location": "http://store.steampowered.com/app/26800/",                                                              // 239
  "Platform": "PC, XBox360",                                                                                           // 240
  "Recommended_Ages": "Grades 3+",                                                                                     // 241
  "Summary": "A man named Tom must solve various puzzles involving time manipulation to save his princess.",           // 242
  "Description": "Braid is a puzzle-platformer, drawn in a painterly style, where you can manipulate the flow of time in strange and unusual ways. From a house in the city, journey to a series of worlds and solve puzzles to rescue an abducted princess. http://store.steampowered.com/app/26800/",
  "Subjects": "Critical Thinking",                                                                                     // 244
  "Image": "temp-resources/Braid-screen01.jpg",                                                                        // 245
  "CC_Tags": ["CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1"],                           // 246
  "Connections": ["Rich G.", "Mollie H.", "Leah W.", "Kevin F.", "Elsida K.", "Renis S.", "Phil W.", "Jess K."]        // 247
}, {                                                                                                                   // 236
  "Type": "Video Game",                                                                                                // 250
  "Title": "The Witness",                                                                                              // 251
  "Location": "http://store.steampowered.com/app/210970/",                                                             // 252
  "Platform": "PC",                                                                                                    // 253
  "Recommended_Ages": "Grades 6+",                                                                                     // 254
  "Summary": "You wake up on an island with no idea who you are, how you got there, and a ton of puzzles to solve.",   // 255
  "Description": "The Witness is a single-player game in an open world with dozens of locations to explore and over 500 puzzles. This game respects you as an intelligent player and it treats your time as precious. There's no filler; each of those puzzles brings its own new idea into the mix. So, this is a game full of ideas. http://store.steampowered.com/app/210970/",
  "Subjects": "Critical Thinking",                                                                                     // 257
  "Image": "temp-resources/witness.png",                                                                               // 258
  "CC_Tags": ["CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1"],
  "Connections": ["Rich G.", "Mollie H.", "Leah W.", "Kevin F.", "Elsida K.", "Renis S.", "Phil W.", "Jess K."]        // 260
}, {                                                                                                                   // 249
  "Type": "Video Game",                                                                                                // 263
  "Title": "Brain Age",                                                                                                // 264
  "Location": "",                                                                                                      // 265
  "Platform": "DS, 3DS",                                                                                               // 266
  "Recommended_Ages": "Grades 4+",                                                                                     // 267
  "Summary": "A series of minigames to challenge your brain.",                                                         // 268
  "Description": "Activities include quickly solving simple math problems & counting people going in and out of a house simultaneously\nDraw pictures on the Touch Screen, or read classic literature out loud\nPlay Sudoku, the popular number puzzle game",
  "Subjects": "Math, English, Brain Training",                                                                         // 270
  "Image": "temp-resources/brainrev1.JPG",                                                                             // 271
  "CC_Tags": ["CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1"],
  "Connections": ["Rich G.", "Mollie H.", "Leah W.", "Kevin F.", "Elsida K.", "Renis S.", "Phil W.", "Jess K."]        // 273
}, {                                                                                                                   // 262
  "Type": "Application",                                                                                               // 276
  "Title": "Garage Band",                                                                                              // 277
  "Location": "http://www.apple.com/mac/garageband/",                                                                  // 278
  "Platform": "OS X",                                                                                                  // 279
  "Recommended_Ages": "Grades 3+",                                                                                     // 280
  "Summary": "A tool for creating and editing music. It includes music lessons.",                                      // 281
  "Description": "GarageBand is a whole music creation studio right inside your Mac — with a complete sound library that includes software instruments, presets for guitar and voice, and virtual session drummers. An intuitive interface makes it easy to learn, play, record, create, and share your hits worldwide. It’s never been easier to make music like a pro.",
  "Subjects": "Music",                                                                                                 // 283
  "Image": "temp-resources/Rocksmith-7.jpg",                                                                           // 284
  "CC_Tags": ["CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1"],
  "Connections": ["Rich G.", "Mollie H.", "Leah W.", "Kevin F.", "Elsida K.", "Renis S.", "Phil W.", "Jess K."]        // 286
}, {                                                                                                                   // 275
  "Type": "Video Game",                                                                                                // 289
  "Title": "Rocksmith",                                                                                                // 290
  "Location": "http://rocksmith.ubi.com/rocksmith/en-us/home/",                                                        // 291
  "Platform": "PC, Xbox 360, PS3",                                                                                     // 292
  "Recommended_Ages": "Grades 3+",                                                                                     // 293
  "Summary": "A game that teaches you how to play guitar.",                                                            // 294
  "Description": "Plug any electric guitar or bass into your PC, Mac, Xbox One, Xbox 360, PlayStation® 4 system or PlayStation® 3 system, and join over 3 million people who have learned to play guitar with award-winning Rocksmith method. Learn to play guitar in 60 days. Get started, now!",
  "Subjects": "Music",                                                                                                 // 296
  "Image": "temp-resources/Rocksmith-7.jpg",                                                                           // 297
  "CC_Tags": ["CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1"],                                                     // 298
  "Connections": ["Rich G.", "Mollie H.", "Leah W.", "Kevin F.", "Elsida K.", "Renis S.", "Phil W.", "Jess K."]        // 299
}, {                                                                                                                   // 288
  "Type": "Video Game",                                                                                                // 302
  "Title": "Depression Quest",                                                                                         // 303
  "Location": "http://www.depressionquest.com/",                                                                       // 304
  "Platform": "PC, OS X, Linux",                                                                                       // 305
  "Recommended_Ages": "Grades 3+",                                                                                     // 306
  "Summary": "A game that simulates living with Depression.",                                                          // 307
  "Description": "Depression Quest is an interactive fiction game where you play as someone living with depression. You are given a series of everyday life events and have to attempt to manage your illness, relationships, job, and possible treatment. This game aims to show other sufferers of depression that they are not alone in their feelings, and to illustrate to people who may not understand the illness the depths of what it can do to people. \n",
  "Subjects": "Mental Health",                                                                                         // 309
  "Image": "temp-resources/depressionquest.jpg",                                                                       // 310
  "CC_Tags": ["CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1"],
  "Connections": ["Rich G.", "Mollie H.", "Leah W.", "Kevin F.", "Elsida K.", "Renis S.", "Phil W.", "Jess K."]        // 312
}, {                                                                                                                   // 301
  "Type": "Video Game",                                                                                                // 315
  "Title": "Typing of The Dead",                                                                                       // 316
  "Location": "",                                                                                                      // 317
  "Platform": "PC",                                                                                                    // 318
  "Recommended_Ages": "Grades 3+",                                                                                     // 319
  "Summary": "A series of games where you defeat zombies by typing words and sentences.",                              // 320
  "Description": "The Typing of the Dead is a modification of Sega's 1998 light gun arcade game The House of the Dead 2 in which the gun is replaced by a computer keyboard. The player takes the role of a secret agent in a zombie-infested Venice and must quickly type letters, words and phrases in order to kill fast-advancing enemies.\nDespite falling under the criteria of \"edutainment\", the game was lauded by mainstream game critics for its humor, difficulty and originality. The PC version of The Typing of the Dead sold 120,000 units in 2003 https://en.wikipedia.org/wiki/The_Typing_of_the_Dead",
  "Subjects": "English, Typing",                                                                                       // 322
  "Image": "temp-resources/zombietyping.jpg",                                                                          // 323
  "CC_Tags": ["CCSS.MATH.PRACTICE.MP1"],                                                                               // 324
  "Connections": ["Rich G.", "Mollie H.", "Leah W.", "Kevin F.", "Elsida K.", "Renis S.", "Phil W.", "Jess K."]        // 325
}, {                                                                                                                   // 314
  "Type": "Video Game",                                                                                                // 328
  "Title": "Reader Rabbit series",                                                                                     // 329
  "Location": "",                                                                                                      // 330
  "Platform": "PC, Wii",                                                                                               // 331
  "Recommended_Ages": "Grades 1-3",                                                                                    // 332
  "Summary": "A series of games that teaches math and reading skills through minigames",                               // 333
  "Description": "The first game in the series taught language arts, featuring a variety of simple games designed to teach schoolchildren basic reading and spelling skills. Originally, the title character's name was changed to reflect a change in subject, as with Math Rabbit, but it has apparently since been decided to retain the character's original name regardless of the subject area covered by a particular game.",
  "Subjects": "Math, Reading",                                                                                         // 335
  "Image": "temp-resources/noclue.jpg",                                                                                // 336
  "CC_Tags": ["CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1"],
  "Connections": ["Rich G.", "Mollie H.", "Leah W.", "Kevin F.", "Elsida K.", "Renis S.", "Phil W.", "Jess K."]        // 338
}, {                                                                                                                   // 327
  "Type": "Video Game",                                                                                                // 341
  "Title": "Math Blaster series",                                                                                      // 342
  "Location": "",                                                                                                      // 343
  "Platform": "PC",                                                                                                    // 344
  "Recommended_Ages": "Grades 1-6",                                                                                    // 345
  "Summary": "A series of games where you help an alien save the planet by solving math problems.",                    // 346
  "Description": "The Blaster Learning System is an educational video game series originally created by Davidson, but is now owned by Knowledge Adventure. Titles in the series have been produced for various computer systems, video game consoles, and as stand-alone handheld units. Originally, the series simply taught mathematics, but eventually expanded to other subjects, such as language arts (reading) and science. Due to the popularity of the original Math Blaster series, Davidson introduced Reading Blaster in 1994, which also went on to become successful. A Science Blaster was introduced 1996, but did not reach the same popularity as its predecessors. https://en.wikipedia.org/wiki/Blaster_Learning_System",
  "Subjects": "Math",                                                                                                  // 348
  "Image": "temp-resources/math-blaster-episode1-04.png",                                                              // 349
  "CC_Tags": ["CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1"],
  "Connections": ["Rich G.", "Mollie H.", "Leah W.", "Kevin F.", "Elsida K.", "Renis S.", "Phil W.", "Jess K."]        // 351
}, {                                                                                                                   // 340
  "Type": "Video Game",                                                                                                // 354
  "Title": "Operation Neptune",                                                                                        // 355
  "Location": "",                                                                                                      // 356
  "Platform": "PC",                                                                                                    // 357
  "Recommended_Ages": "Grades 3+",                                                                                     // 358
  "Summary": "A game where you explore the ocean and make progress by solving challenging math problems.",             // 359
  "Description": "A team of astronauts and scientists have begun a secret research project on a distant planet. The research team's results were sent back to Earth on the \"Galaxy space capsule\", which malfunctioned, crashed into the ocean, and broke into many pieces. The capsule included several data canisters, each of which contains small snippets of the scientists' story, which is revealed to the player as the game progresses and data canisters are found. The capsule also contained some toxic chemicals, which have begun to leak out and threaten the health of the world's sea life. A recovery mission, codenamed Operation Neptune, is sent to recover the pieces of the capsule. https://en.wikipedia.org/wiki/Operation_Neptune_(video_game)",
  "Subjects": "Math",                                                                                                  // 361
  "Image": "temp-resources/operationneptune2.jpg",                                                                     // 362
  "CC_Tags": ["CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1"],
  "Connections": ["Rich G.", "Mollie H.", "Leah W.", "Kevin F.", "Elsida K.", "Renis S.", "Phil W.", "Jess K."]        // 364
}, {                                                                                                                   // 353
  "Type": "Video Game",                                                                                                // 367
  "Title": "Mario's Early Years",                                                                                      // 368
  "Location": "",                                                                                                      // 369
  "Platform": "PC, SNES",                                                                                              // 370
  "Recommended_Ages": "Preschool-Grade 1",                                                                             // 371
  "Summary": "Characters from the Super Mario series teach children basic math and reading.",                          // 372
  "Description": "",                                                                                                   // 373
  "Subjects": "Math, Reading",                                                                                         // 374
  "Image": "temp-resources/carmensandiego.jpg",                                                                        // 375
  "CC_Tags": ["CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1"],                                                     // 376
  "Connections": ["Rich G.", "Mollie H.", "Leah W.", "Kevin F.", "Elsida K.", "Renis S.", "Phil W.", "Jess K."]        // 377
}, {                                                                                                                   // 366
  "Type": "Video Game",                                                                                                // 380
  "Title": "Myst",                                                                                                     // 381
  "Location": "",                                                                                                      // 382
  "Platform": "All",                                                                                                   // 383
  "Recommended_Ages": "Grades 3+",                                                                                     // 384
  "Summary": "A series of games where the story unfolds via solving puzzles",                                          // 385
  "Description": "Myst is a graphic adventure puzzle video game designed and directed by the brothers Robyn and Rand Miller. It was developed by Cyan, Inc., published by Brøderbund, and initially released on the Macintosh platform on September 24, 1993. https://en.wikipedia.org/wiki/Myst",
  "Subjects": "Critical Thinking",                                                                                     // 387
  "Image": "temp-resources/myst-34.jpg",                                                                               // 388
  "CC_Tags": ["CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1"],                           // 389
  "Connections": ["Rich G.", "Mollie H.", "Leah W.", "Kevin F.", "Elsida K.", "Renis S.", "Phil W.", "Jess K."]        // 390
}, {                                                                                                                   // 379
  "Type": "Video Game",                                                                                                // 393
  "Title": "Carmen Sandiego",                                                                                          // 394
  "Location": "",                                                                                                      // 395
  "Platform": "PC",                                                                                                    // 396
  "Recommended_Ages": "Grades 3+",                                                                                     // 397
  "Summary": "A series of games where you solve extraordinary thefts using geography and history skills.",             // 398
  "Description": "",                                                                                                   // 399
  "Subjects": "History, Geography",                                                                                    // 400
  "Image": "temp-resources/carmensandiego.jpg",                                                                        // 401
  "CC_Tags": ["CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1"],
  "Connections": ["Rich G.", "Mollie H.", "Leah W.", "Kevin F.", "Elsida K.", "Renis S.", "Phil W.", "Jess K."]        // 403
}, {                                                                                                                   // 392
  "Type": "Video Game",                                                                                                // 406
  "Title": "Clue Finders",                                                                                             // 407
  "Location": "",                                                                                                      // 408
  "Platform": "PC",                                                                                                    // 409
  "Recommended_Ages": "Grades 3-6",                                                                                    // 410
  "Summary": "A series of games where a group of kids solve various mysteries using problem solving skills.",          // 411
  "Description": "The ClueFinders is a series of Edutainment Games from The Learning Company in which the eponymous Kid Heroes have Scooby-Doo type exploits.",
  "Subjects": "Math, Reading, Critical Thinking",                                                                      // 413
  "Image": "temp-resources/sesame_street_abc_nes_gameplay_screenshot_5.png",                                           // 414
  "CC_Tags": ["CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1"],
  "Connections": ["Rich G.", "Mollie H.", "Leah W.", "Kevin F.", "Elsida K.", "Renis S.", "Phil W.", "Jess K."]        // 416
}, {                                                                                                                   // 405
  "Type": "Video Game",                                                                                                // 419
  "Title": "Sesame Street ABC/123",                                                                                    // 420
  "Location": "",                                                                                                      // 421
  "Platform": "PC, NES",                                                                                               // 422
  "Recommended_Ages": "Preschool-Grade 1",                                                                             // 423
  "Summary": "The characters from Sesame street teach young children basic reading, math, and problem solving through a series of minigames.",
  "Description": "Sesame Street: ABC/123 is an Edutainment game, developed by Rare Ltd. and published by Hi-Tech, which was released in 1991. http://www.amazon.com/Sesame-Street-ABC-Nintendo-Entertainment-System/dp/B003ACHV70",
  "Subjects": "Math, Reading, Critical Thinking",                                                                      // 426
  "Image": "temp-resources/sesame_street_abc_nes_gameplay_screenshot_5.png",                                           // 427
  "CC_Tags": ["CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1"],
  "Connections": ["Rich G.", "Mollie H.", "Leah W.", "Kevin F.", "Elsida K.", "Renis S.", "Phil W.", "Jess K."]        // 429
}, {                                                                                                                   // 418
  "Type": "Video Game",                                                                                                // 432
  "Title": "Donald's Alphabet Chase",                                                                                  // 433
  "Location": "",                                                                                                      // 434
  "Platform": "PC",                                                                                                    // 435
  "Recommended_Ages": "Preschool-Grade 1",                                                                             // 436
  "Summary": "A game where you help Donald Duck find the letters of the alphabet scattered throughout his home.",      // 437
  "Description": "The letters of the alphabet got out of Donald Duck's toybox and are scattered throughout his home. You must use your reading and problem solving skills to get them back.",
  "Subjects": "English",                                                                                               // 439
  "Image": "temp-resources/74770-DonaldsAlphabetChase.jpg",                                                            // 440
  "CC_Tags": ["CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1"],
  "Connections": ["Rich G.", "Mollie H.", "Leah W.", "Kevin F.", "Elsida K.", "Renis S.", "Phil W.", "Jess K."]        // 442
}, {                                                                                                                   // 431
  "Type": "Video Game",                                                                                                // 445
  "Title": "3D Dinosaur Adventure",                                                                                    // 446
  "Location": "",                                                                                                      // 447
  "Platform": "PC",                                                                                                    // 448
  "Recommended_Ages": "Grades 3+",                                                                                     // 449
  "Summary": "A series of minigames where you encounter and learn about dinosaurs",                                    // 450
  "Description": "",                                                                                                   // 451
  "Subjects": "History, Science",                                                                                      // 452
  "Image": "temp-resources/dinosaur3d.jpg",                                                                            // 453
  "CC_Tags": ["CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1"],
  "Connections": ["Rich G.", "Mollie H.", "Leah W.", "Kevin F.", "Elsida K.", "Renis S.", "Phil W.", "Jess K."]        // 455
}, {                                                                                                                   // 444
  "Type": "Video Game",                                                                                                // 458
  "Title": "Plague Inc.",                                                                                              // 459
  "Location": "http://www.ndemiccreations.com/en/22-plague-inc",                                                       // 460
  "Platform": "PC, iOS, Android",                                                                                      // 461
  "Recommended_Ages": "Grades 6+",                                                                                     // 462
  "Summary": "A Risk style strategy game where you attempt to wipe out humanity with a deadly disease.",               // 463
  "Description": "Can you infect the world? Plague Inc. is a unique mix of high strategy and terrifyingly realistic simulation with over 700 million games played!\nYour pathogen has just infected 'Patient Zero'. Now you must bring about the end of human history by evolving a deadly, global Plague whilst adapting against everything humanity can do to defend itself.\n\nBrilliantly executed with innovative gameplay and built from the ground up for the iPhone, iPad, Android & Windows Phone, Plague Inc. evolves the strategy genre and pushes mobile gaming (and you) to new levels. It’s You vs. the world - only the strongest can survive!",
  "Subjects": "Critical Thinking, Science, Geography",                                                                 // 465
  "Image": "temp-resources/mothergoose.jpg",                                                                           // 466
  "CC_Tags": ["CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1"],
  "Connections": ["Rich G.", "Mollie H.", "Leah W.", "Kevin F.", "Elsida K.", "Renis S.", "Phil W.", "Jess K."]        // 468
}, {                                                                                                                   // 457
  "Type": "Video Game",                                                                                                // 471
  "Title": "Mixed-Up Mother Goose",                                                                                    // 472
  "Location": "",                                                                                                      // 473
  "Platform": "PC",                                                                                                    // 474
  "Recommended_Ages": "Preschool-Grade 3",                                                                             // 475
  "Summary": "A game where you go around as a small child fixing nursery rhymes.",                                     // 476
  "Description": "The storyline of the game is very simple, as is common in games for children. One night, while preparing for bed, a child (which is the player's avatar) is sent into the dreamlike world of Mother Goose, who desperately needs his or her help. All the nursery rhymes in the land have gotten mixed up, with none of the inhabitants possessing the items necessary for their rhyme to exist. And so, the child will find themselves helping Humpty Dumpty find a ladder to scramble onto a wall, bringing the little lamb back to Mary and seeking out a pail for Jack and Jill, among others. https://en.wikipedia.org/wiki/Mixed-Up_Mother_Goose",
  "Subjects": "English",                                                                                               // 478
  "Image": "temp-resources/mothergoose.jpg",                                                                           // 479
  "CC_Tags": ["CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1"],
  "Connections": ["Rich G.", "Mollie H.", "Leah W.", "Kevin F.", "Elsida K.", "Renis S.", "Phil W.", "Jess K."]        // 481
}, {                                                                                                                   // 470
  "Type": "Video Game",                                                                                                // 484
  "Title": "Sim City",                                                                                                 // 485
  "Location": "http://www.ea.com/sim-city",                                                                            // 486
  "Platform": "PC",                                                                                                    // 487
  "Recommended_Ages": "Grades 4+",                                                                                     // 488
  "Summary": "A series of simulation games where you build and manage a city.",                                        // 489
  "Description": "In SimCity, the player is given the task of founding and developing a city, while maintaining the happiness of the citizens and keeping a stable budget. https://en.wikipedia.org/wiki/SimCity",
  "Subjects": "Economics, Politics",                                                                                   // 491
  "Image": "temp-resources/SimCity2000_screen2WebEmbed.jpg",                                                           // 492
  "CC_Tags": ["CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1"],
  "Connections": ["Rich G.", "Mollie H.", "Leah W.", "Kevin F.", "Elsida K.", "Renis S.", "Phil W.", "Jess K."]        // 494
}, {                                                                                                                   // 483
  "Type": "Video Game",                                                                                                // 497
  "Title": "Super Seekers Series",                                                                                     // 498
  "Location": "",                                                                                                      // 499
  "Platform": "PC",                                                                                                    // 500
  "Recommended_Ages": "Grades 1+",                                                                                     // 501
  "Summary": "A series of puzzle adventure games that challenge your reading and math skills.",                        // 502
  "Description": "A series of side scrolling, adventure puzzle games by the Learning Company. The Master of Mischief makes, well, mischief in each game and the Super Seeker must foil his scheme via solving math and reading puzzles.",
  "Subjects": "Math, English",                                                                                         // 504
  "Image": "temp-resources/wordrescue6.gif",                                                                           // 505
  "CC_Tags": ["CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1"],
  "Connections": ["Rich G.", "Mollie H.", "Leah W.", "Kevin F.", "Elsida K.", "Renis S.", "Phil W.", "Jess K."]        // 507
}, {                                                                                                                   // 496
  "Type": "Video Game",                                                                                                // 510
  "Title": "Word Rescue",                                                                                              // 511
  "Location": "http://store.steampowered.com/app/358340/",                                                             // 512
  "Platform": "PC",                                                                                                    // 513
  "Recommended_Ages": "Grades 1-3",                                                                                    // 514
  "Summary": "A game where you find letters to spell out words with the help of a book worm.",                         // 515
  "Description": "This is an engrossing educational game with vivid EGA/VGA graphics and support for Adlib and Sound Blaster. Using the Duke Nukem graphical system, Word Rescue has state-of-the-art dual-screen scrolling graphics similar to what's seen on the Super Nintendo and Sega Genesis home gaming systems. Even \"grown-ups\" will like Word Rescue! \n\nPlay as either a girl or a boy. Visit amazing locations on your word-finding adventure, as you hunt for missing words. Dark caves, rocky cliffs, deserts, happy towns, haunted houses, funny factories and creepy dungeons are just some of the places you'll explore.",
  "Subjects": "English",                                                                                               // 517
  "Image": "temp-resources/wordrescue6.gif",                                                                           // 518
  "CC_Tags": ["CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1"],
  "Connections": ["Rich G.", "Mollie H.", "Leah W.", "Kevin F.", "Elsida K.", "Renis S.", "Phil W.", "Jess K."]        // 520
}, {                                                                                                                   // 509
  "Type": "Video Game",                                                                                                // 523
  "Title": "Dungeon Keeper",                                                                                           // 524
  "Location": "https://www.gog.com/game/dungeon_keeper",                                                               // 525
  "Platform": "PC",                                                                                                    // 526
  "Recommended_Ages": "Grades 6+",                                                                                     // 527
  "Summary": "A series of games where you build dungeons to corrupt cities",                                           // 528
  "Description": "Dungeon Keeper is a strategy video game developed by Bullfrog Productions and released by Electronic Arts in July 1997 for DOS. In Dungeon Keeper, the player builds and manage a dungeon while protecting it from invading 'hero' characters intent on stealing the player's accumulated treasures and killing various monsters. https://en.wikipedia.org/wiki/Dungeon_Keeper",
  "Subjects": "Critical Thinking",                                                                                     // 530
  "Image": "temp-resources/dungeonkeeper.jpg",                                                                         // 531
  "CC_Tags": ["CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1", "CCSS.MATH.PRACTICE.MP1"],
  "Connections": ["Rich G.", "Mollie H.", "Leah W.", "Kevin F.", "Elsida K.", "Renis S.", "Phil W.", "Jess K."]        // 533
}];                                                                                                                    // 522
                                                                                                                       //
for (var i = 0; i < data.length; i++) {                                                                                // 536
  Resources.insert(data[i]);                                                                                           // 537
}                                                                                                                      // 538
                                                                                                                       //
//}                                                                                                                    // 540
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json",".html"]});
require("./mup.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
