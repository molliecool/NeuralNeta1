//////////////////////////////////////////////////////////////////////////
//                                                                      //
// This is a generated file. You can view the original                  //
// source in your browser if your browser supports source maps.         //
// Source maps are supported by all recent versions of Chrome, Safari,  //
// and Firefox, and by Internet Explorer 11.                            //
//                                                                      //
//////////////////////////////////////////////////////////////////////////


(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var check = Package.check.check;
var Match = Package.check.Match;
var CollectionHooks = Package['matb33:collection-hooks'].CollectionHooks;
var Mongo = Package.mongo.Mongo;
var Template = Package.templating.Template;
var _ = Package.underscore._;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var Blaze = Package.blaze.Blaze;
var UI = Package.blaze.UI;
var Handlebars = Package.blaze.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var UploadFS;

var require = meteorInstall({"node_modules":{"meteor":{"jalik:ufs":{"ufs.js":["babel-runtime/helpers/typeof","meteor/underscore","meteor/meteor","meteor/mongo",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/jalik_ufs/ufs.js                                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _typeof;module.import('babel-runtime/helpers/typeof',{"default":function(v){_typeof=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});
                                                                                                                       // 1
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       //
var stores = {};                                                                                                       // 5
                                                                                                                       //
UploadFS = {                                                                                                           // 7
                                                                                                                       //
    /**                                                                                                                // 9
     * Contains all stores                                                                                             //
     */                                                                                                                //
    store: {},                                                                                                         // 12
                                                                                                                       //
    /**                                                                                                                // 14
     * Collection of tokens                                                                                            //
     */                                                                                                                //
    tokens: new Mongo.Collection('ufsTokens'),                                                                         // 17
                                                                                                                       //
    /**                                                                                                                // 19
     * Returns the store by its name                                                                                   //
     * @param name                                                                                                     //
     * @return {UploadFS.Store}                                                                                        //
     */                                                                                                                //
    getStore: function () {                                                                                            // 24
        function getStore(name) {                                                                                      // 24
            return stores[name];                                                                                       // 25
        }                                                                                                              // 26
                                                                                                                       //
        return getStore;                                                                                               // 24
    }(),                                                                                                               // 24
                                                                                                                       //
    /**                                                                                                                // 28
     * Returns all stores                                                                                              //
     * @return {object}                                                                                                //
     */                                                                                                                //
    getStores: function () {                                                                                           // 32
        function getStores() {                                                                                         // 32
            return stores;                                                                                             // 33
        }                                                                                                              // 34
                                                                                                                       //
        return getStores;                                                                                              // 32
    }(),                                                                                                               // 32
                                                                                                                       //
    /**                                                                                                                // 36
     * Returns the temporary file path                                                                                 //
     * @param fileId                                                                                                   //
     * @return {string}                                                                                                //
     */                                                                                                                //
    getTempFilePath: function () {                                                                                     // 41
        function getTempFilePath(fileId) {                                                                             // 41
            return UploadFS.config.tmpDir + '/' + fileId;                                                              // 42
        }                                                                                                              // 43
                                                                                                                       //
        return getTempFilePath;                                                                                        // 41
    }(),                                                                                                               // 41
                                                                                                                       //
    /**                                                                                                                // 45
     * Imports a file from a URL                                                                                       //
     * @param url                                                                                                      //
     * @param file                                                                                                     //
     * @param store                                                                                                    //
     * @param callback                                                                                                 //
     */                                                                                                                //
    importFromURL: function () {                                                                                       // 52
        function importFromURL(url, file, store, callback) {                                                           // 52
            if (typeof store === 'string') {                                                                           // 53
                Meteor.call('ufsImportURL', url, file, store, callback);                                               // 54
            } else if ((typeof store === 'undefined' ? 'undefined' : _typeof(store)) === 'object') {                   // 55
                store.importFromURL(url, file, callback);                                                              // 57
            }                                                                                                          // 58
        }                                                                                                              // 59
                                                                                                                       //
        return importFromURL;                                                                                          // 52
    }()                                                                                                                // 52
};                                                                                                                     // 7
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"ufs-mime.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/jalik_ufs/ufs-mime.js                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * MIME types and extensions                                                                                           //
 */                                                                                                                    //
var MIME = {                                                                                                           // 4
                                                                                                                       //
    // application                                                                                                     // 6
    '7z': 'application/x-7z-compressed',                                                                               // 7
    'arc': 'application/octet-stream',                                                                                 // 8
    'ai': 'application/postscript',                                                                                    // 9
    'bin': 'application/octet-stream',                                                                                 // 10
    'bz': 'application/x-bzip',                                                                                        // 11
    'bz2': 'application/x-bzip2',                                                                                      // 12
    'eps': 'application/postscript',                                                                                   // 13
    'exe': 'application/octet-stream',                                                                                 // 14
    'gz': 'application/x-gzip',                                                                                        // 15
    'gzip': 'application/x-gzip',                                                                                      // 16
    'js': 'application/javascript',                                                                                    // 17
    'json': 'application/json',                                                                                        // 18
    'ogx': 'application/ogg',                                                                                          // 19
    'pdf': 'application/pdf',                                                                                          // 20
    'ps': 'application/postscript',                                                                                    // 21
    'psd': 'application/octet-stream',                                                                                 // 22
    'rar': 'application/x-rar-compressed',                                                                             // 23
    'rev': 'application/x-rar-compressed',                                                                             // 24
    'swf': 'application/x-shockwave-flash',                                                                            // 25
    'tar': 'application/x-tar',                                                                                        // 26
    'xhtml': 'application/xhtml+xml',                                                                                  // 27
    'xml': 'application/xml',                                                                                          // 28
    'zip': 'application/zip',                                                                                          // 29
                                                                                                                       //
    // audio                                                                                                           // 31
    'aif': 'audio/aiff',                                                                                               // 32
    'aifc': 'audio/aiff',                                                                                              // 33
    'aiff': 'audio/aiff',                                                                                              // 34
    'au': 'audio/basic',                                                                                               // 35
    'flac': 'audio/flac',                                                                                              // 36
    'midi': 'audio/midi',                                                                                              // 37
    'mp2': 'audio/mpeg',                                                                                               // 38
    'mp3': 'audio/mpeg',                                                                                               // 39
    'mpa': 'audio/mpeg',                                                                                               // 40
    'oga': 'audio/ogg',                                                                                                // 41
    'ogg': 'audio/ogg',                                                                                                // 42
    'opus': 'audio/ogg',                                                                                               // 43
    'ra': 'audio/vnd.rn-realaudio',                                                                                    // 44
    'spx': 'audio/ogg',                                                                                                // 45
    'wav': 'audio/x-wav',                                                                                              // 46
    'weba': 'audio/webm',                                                                                              // 47
    'wma': 'audio/x-ms-wma',                                                                                           // 48
                                                                                                                       //
    // image                                                                                                           // 50
    'avs': 'image/avs-video',                                                                                          // 51
    'bmp': 'image/x-windows-bmp',                                                                                      // 52
    'gif': 'image/gif',                                                                                                // 53
    'ico': 'image/vnd.microsoft.icon',                                                                                 // 54
    'jpeg': 'image/jpeg',                                                                                              // 55
    'jpg': 'image/jpg',                                                                                                // 56
    'mjpg': 'image/x-motion-jpeg',                                                                                     // 57
    'pic': 'image/pic',                                                                                                // 58
    'png': 'image/png',                                                                                                // 59
    'svg': 'image/svg+xml',                                                                                            // 60
    'tif': 'image/tiff',                                                                                               // 61
    'tiff': 'image/tiff',                                                                                              // 62
                                                                                                                       //
    // text                                                                                                            // 64
    'css': 'text/css',                                                                                                 // 65
    'csv': 'text/csv',                                                                                                 // 66
    'html': 'text/html',                                                                                               // 67
    'txt': 'text/plain',                                                                                               // 68
                                                                                                                       //
    // video                                                                                                           // 70
    'avi': 'video/avi',                                                                                                // 71
    'dv': 'video/x-dv',                                                                                                // 72
    'flv': 'video/x-flv',                                                                                              // 73
    'mov': 'video/quicktime',                                                                                          // 74
    'mp4': 'video/mp4',                                                                                                // 75
    'mpeg': 'video/mpeg',                                                                                              // 76
    'mpg': 'video/mpg',                                                                                                // 77
    'ogv': 'video/ogg',                                                                                                // 78
    'vdo': 'video/vdo',                                                                                                // 79
    'webm': 'video/webm',                                                                                              // 80
    'wmv': 'video/x-ms-wmv',                                                                                           // 81
                                                                                                                       //
    // specific to vendors                                                                                             // 83
    'doc': 'application/msword',                                                                                       // 84
    'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',                                 // 85
    'odb': 'application/vnd.oasis.opendocument.database',                                                              // 86
    'odc': 'application/vnd.oasis.opendocument.chart',                                                                 // 87
    'odf': 'application/vnd.oasis.opendocument.formula',                                                               // 88
    'odg': 'application/vnd.oasis.opendocument.graphics',                                                              // 89
    'odi': 'application/vnd.oasis.opendocument.image',                                                                 // 90
    'odm': 'application/vnd.oasis.opendocument.text-master',                                                           // 91
    'odp': 'application/vnd.oasis.opendocument.presentation',                                                          // 92
    'ods': 'application/vnd.oasis.opendocument.spreadsheet',                                                           // 93
    'odt': 'application/vnd.oasis.opendocument.text',                                                                  // 94
    'otg': 'application/vnd.oasis.opendocument.graphics-template',                                                     // 95
    'otp': 'application/vnd.oasis.opendocument.presentation-template',                                                 // 96
    'ots': 'application/vnd.oasis.opendocument.spreadsheet-template',                                                  // 97
    'ott': 'application/vnd.oasis.opendocument.text-template',                                                         // 98
    'ppt': 'application/vnd.ms-powerpoint',                                                                            // 99
    'pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',                               // 100
    'xls': 'application/vnd.ms-excel',                                                                                 // 101
    'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'                                        // 102
                                                                                                                       //
};                                                                                                                     // 4
                                                                                                                       //
/**                                                                                                                    // 106
 * Adds the MIME type for an extension                                                                                 //
 * @param extension                                                                                                    //
 * @param mime                                                                                                         //
 */                                                                                                                    //
UploadFS.addMimeType = function (extension, mime) {                                                                    // 111
    MIME[extension.toLowerCase()] = mime;                                                                              // 112
};                                                                                                                     // 113
                                                                                                                       //
/**                                                                                                                    // 115
 * Returns the MIME type of the extension                                                                              //
 * @param extension                                                                                                    //
 * @returns {*}                                                                                                        //
 */                                                                                                                    //
UploadFS.getMimeType = function (extension) {                                                                          // 120
    extension = extension.toLowerCase();                                                                               // 121
    return MIME[extension];                                                                                            // 122
};                                                                                                                     // 123
                                                                                                                       //
/**                                                                                                                    // 125
 * Returns all MIME types                                                                                              //
 */                                                                                                                    //
UploadFS.getMimeTypes = function () {                                                                                  // 128
    return MIME;                                                                                                       // 129
};                                                                                                                     // 130
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"ufs-utilities.js":["meteor/meteor","meteor/underscore",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/jalik_ufs/ufs-utilities.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});
                                                                                                                       // 2
                                                                                                                       //
if (Meteor.isClient) {                                                                                                 // 5
                                                                                                                       //
    /**                                                                                                                // 7
     * Returns file and data as ArrayBuffer for each files in the event                                                //
     * @deprecated                                                                                                     //
     * @param event                                                                                                    //
     * @param callback                                                                                                 //
     */                                                                                                                //
    // todo remove deprecated method                                                                                   // 13
    UploadFS.readAsArrayBuffer = function (event, callback) {                                                          // 14
        console.error('UploadFS.readAsArrayBuffer is deprecated, see https://github.com/jalik/jalik-ufs#uploading-from-a-file');
    };                                                                                                                 // 16
                                                                                                                       //
    /**                                                                                                                // 18
     * Opens a dialog to select a single file                                                                          //
     * @param callback                                                                                                 //
     */                                                                                                                //
    UploadFS.selectFile = function (callback) {                                                                        // 22
        var input = document.createElement('input');                                                                   // 23
        input.type = 'file';                                                                                           // 24
        input.multiple = false;                                                                                        // 25
        input.onchange = function (ev) {                                                                               // 26
            var files = ev.target.files;                                                                               // 27
            callback.call(UploadFS, files[0]);                                                                         // 28
        };                                                                                                             // 29
        // Fix for iOS                                                                                                 // 30
        input.style = 'display:none';                                                                                  // 31
        document.body.appendChild(input);                                                                              // 32
        input.click();                                                                                                 // 33
    };                                                                                                                 // 34
                                                                                                                       //
    /**                                                                                                                // 36
     * Opens a dialog to select multiple files                                                                         //
     * @param callback                                                                                                 //
     */                                                                                                                //
    UploadFS.selectFiles = function (callback) {                                                                       // 40
        var input = document.createElement('input');                                                                   // 41
        input.type = 'file';                                                                                           // 42
        input.multiple = true;                                                                                         // 43
        input.onchange = function (ev) {                                                                               // 44
            var files = ev.target.files;                                                                               // 45
                                                                                                                       //
            for (var i = 0; i < files.length; i += 1) {                                                                // 47
                callback.call(UploadFS, files[i]);                                                                     // 48
            }                                                                                                          // 49
        };                                                                                                             // 50
        // Fix for iOS                                                                                                 // 51
        input.style = 'display:none';                                                                                  // 52
        document.body.appendChild(input);                                                                              // 53
        input.click();                                                                                                 // 54
    };                                                                                                                 // 55
}                                                                                                                      // 56
                                                                                                                       //
if (Meteor.isServer) {                                                                                                 // 59
                                                                                                                       //
    /**                                                                                                                // 61
     * Adds the path attribute to files                                                                                //
     * @param where                                                                                                    //
     */                                                                                                                //
    UploadFS.addPathAttributeToFiles = function (where) {                                                              // 65
        _.each(UploadFS.getStores(), function (store) {                                                                // 66
            var files = store.getCollection();                                                                         // 67
                                                                                                                       //
            // By default update only files with no path set                                                           // 69
            files.find(where || { path: null }, { fields: { _id: 1 } }).forEach(function (file) {                      // 70
                var path = store.getFileRelativeURL(file._id);                                                         // 71
                files.update({ _id: file._id }, { $set: { path: path } });                                             // 72
            });                                                                                                        // 73
        });                                                                                                            // 74
    };                                                                                                                 // 75
}                                                                                                                      // 76
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"ufs-config.js":["meteor/underscore","meteor/meteor",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/jalik_ufs/ufs-config.js                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _;module.import('meteor/underscore',{"_":function(v){_=v}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});
                                                                                                                       // 2
                                                                                                                       //
/**                                                                                                                    // 4
 * UploadFS configuration                                                                                              //
 * @param options                                                                                                      //
 * @constructor                                                                                                        //
 */                                                                                                                    //
UploadFS.Config = function (options) {                                                                                 // 9
  // Default options                                                                                                   // 10
  options = _.extend({                                                                                                 // 11
    defaultStorePermissions: null,                                                                                     // 12
    https: false,                                                                                                      // 13
    simulateReadDelay: 0,                                                                                              // 14
    simulateUploadSpeed: 0,                                                                                            // 15
    simulateWriteDelay: 0,                                                                                             // 16
    storesPath: 'ufs',                                                                                                 // 17
    tmpDir: '/tmp/ufs',                                                                                                // 18
    tmpDirPermissions: '0700'                                                                                          // 19
  }, options);                                                                                                         // 11
                                                                                                                       //
  // Check options                                                                                                     // 22
  if (options.defaultStorePermissions && !(options.defaultStorePermissions instanceof UploadFS.StorePermissions)) {    // 23
    throw new TypeError('defaultStorePermissions is not an instance of UploadFS.StorePermissions');                    // 24
  }                                                                                                                    // 25
  if (typeof options.https !== 'boolean') {                                                                            // 26
    throw new TypeError('https is not a function');                                                                    // 27
  }                                                                                                                    // 28
  if (typeof options.simulateReadDelay !== 'number') {                                                                 // 29
    throw new Meteor.Error('simulateReadDelay is not a number');                                                       // 30
  }                                                                                                                    // 31
  if (typeof options.simulateUploadSpeed !== 'number') {                                                               // 32
    throw new Meteor.Error('simulateUploadSpeed is not a number');                                                     // 33
  }                                                                                                                    // 34
  if (typeof options.simulateWriteDelay !== 'number') {                                                                // 35
    throw new Meteor.Error('simulateWriteDelay is not a number');                                                      // 36
  }                                                                                                                    // 37
  if (typeof options.storesPath !== 'string') {                                                                        // 38
    throw new Meteor.Error('storesPath is not a string');                                                              // 39
  }                                                                                                                    // 40
  if (typeof options.tmpDir !== 'string') {                                                                            // 41
    throw new Meteor.Error('tmpDir is not a string');                                                                  // 42
  }                                                                                                                    // 43
  if (typeof options.tmpDirPermissions !== 'string') {                                                                 // 44
    throw new Meteor.Error('tmpDirPermissions is not a string');                                                       // 45
  }                                                                                                                    // 46
                                                                                                                       //
  /**                                                                                                                  // 48
   * Default store permissions                                                                                         //
   * @type {UploadFS.StorePermissions}                                                                                 //
   */                                                                                                                  //
  this.defaultStorePermissions = options.defaultStorePermissions;                                                      // 52
  /**                                                                                                                  // 53
   * Use or not secured protocol in URLS                                                                               //
   * @type {boolean}                                                                                                   //
   */                                                                                                                  //
  this.https = options.https;                                                                                          // 57
  /**                                                                                                                  // 58
   * The simulation read delay                                                                                         //
   * @type {Number}                                                                                                    //
   */                                                                                                                  //
  this.simulateReadDelay = parseInt(options.simulateReadDelay);                                                        // 62
  /**                                                                                                                  // 63
   * The simulation upload speed                                                                                       //
   * @type {Number}                                                                                                    //
   */                                                                                                                  //
  this.simulateUploadSpeed = parseInt(options.simulateUploadSpeed);                                                    // 67
  /**                                                                                                                  // 68
   * The simulation write delay                                                                                        //
   * @type {Number}                                                                                                    //
   */                                                                                                                  //
  this.simulateWriteDelay = parseInt(options.simulateWriteDelay);                                                      // 72
  /**                                                                                                                  // 73
   * The URL root path of stores                                                                                       //
   * @type {string}                                                                                                    //
   */                                                                                                                  //
  this.storesPath = options.storesPath;                                                                                // 77
  /**                                                                                                                  // 78
   * The temporary directory of uploading files                                                                        //
   * @type {string}                                                                                                    //
   */                                                                                                                  //
  this.tmpDir = options.tmpDir;                                                                                        // 82
  /**                                                                                                                  // 83
   * The permissions of the temporary directory                                                                        //
   * @type {string}                                                                                                    //
   */                                                                                                                  //
  this.tmpDirPermissions = options.tmpDirPermissions;                                                                  // 87
};                                                                                                                     // 88
                                                                                                                       //
/**                                                                                                                    // 90
 * Global configuration                                                                                                //
 * @type {UploadFS.Config}                                                                                             //
 */                                                                                                                    //
UploadFS.config = new UploadFS.Config();                                                                               // 94
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"ufs-filter.js":["babel-runtime/helpers/typeof","meteor/underscore",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/jalik_ufs/ufs-filter.js                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _typeof;module.import('babel-runtime/helpers/typeof',{"default":function(v){_typeof=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});
                                                                                                                       // 1
                                                                                                                       //
/**                                                                                                                    // 3
 * File filter                                                                                                         //
 * @param options                                                                                                      //
 * @constructor                                                                                                        //
 */                                                                                                                    //
UploadFS.Filter = function (options) {                                                                                 // 8
    var self = this;                                                                                                   // 9
                                                                                                                       //
    // Default options                                                                                                 // 11
    options = _.extend({                                                                                               // 12
        contentTypes: null,                                                                                            // 13
        extensions: null,                                                                                              // 14
        minSize: 1,                                                                                                    // 15
        maxSize: 0,                                                                                                    // 16
        onCheck: null                                                                                                  // 17
    }, options);                                                                                                       // 12
                                                                                                                       //
    // Check options                                                                                                   // 20
    if (options.contentTypes && !(options.contentTypes instanceof Array)) {                                            // 21
        throw new TypeError('contentTypes is not an Array');                                                           // 22
    }                                                                                                                  // 23
    if (options.extensions && !(options.extensions instanceof Array)) {                                                // 24
        throw new TypeError('extensions is not an Array');                                                             // 25
    }                                                                                                                  // 26
    if (typeof options.minSize !== 'number') {                                                                         // 27
        throw new TypeError('minSize is not a number');                                                                // 28
    }                                                                                                                  // 29
    if (typeof options.maxSize !== 'number') {                                                                         // 30
        throw new TypeError('maxSize is not a number');                                                                // 31
    }                                                                                                                  // 32
    if (options.onCheck && typeof options.onCheck !== 'function') {                                                    // 33
        throw new TypeError('onCheck is not a function');                                                              // 34
    }                                                                                                                  // 35
                                                                                                                       //
    // Private attributes                                                                                              // 37
    var contentTypes = options.contentTypes;                                                                           // 38
    var extensions = options.extensions;                                                                               // 39
    var onCheck = options.onCheck;                                                                                     // 40
    var maxSize = parseInt(options.maxSize);                                                                           // 41
    var minSize = parseInt(options.minSize);                                                                           // 42
                                                                                                                       //
    /**                                                                                                                // 44
     * Checks the file                                                                                                 //
     * @param file                                                                                                     //
     */                                                                                                                //
    self.check = function (file) {                                                                                     // 48
        // Check size                                                                                                  // 49
        if (file.size <= 0 || file.size < self.getMinSize()) {                                                         // 50
            throw new Meteor.Error('file-too-small', 'File is too small (min =' + self.getMinSize() + ')');            // 51
        }                                                                                                              // 52
        if (self.getMaxSize() > 0 && file.size > self.getMaxSize()) {                                                  // 53
            throw new Meteor.Error('file-too-large', 'File is too large (max = ' + self.getMaxSize() + ')');           // 54
        }                                                                                                              // 55
        // Check extension                                                                                             // 56
        if (self.getExtensions() && !_.contains(self.getExtensions(), file.extension)) {                               // 57
            throw new Meteor.Error('invalid-file-extension', 'File extension is not accepted');                        // 58
        }                                                                                                              // 59
        // Check content type                                                                                          // 60
        if (self.getContentTypes() && !checkContentType(file.type, self.getContentTypes())) {                          // 61
            throw new Meteor.Error('invalid-file-type', 'File type is not accepted');                                  // 62
        }                                                                                                              // 63
        // Apply custom check                                                                                          // 64
        if (typeof onCheck === 'function' && !onCheck.call(self, file)) {                                              // 65
            throw new Meteor.Error('invalid-file', 'File does not match filter');                                      // 66
        }                                                                                                              // 67
    };                                                                                                                 // 68
                                                                                                                       //
    /**                                                                                                                // 70
     * Returns the allowed content types                                                                               //
     * @return {Array}                                                                                                 //
     */                                                                                                                //
    self.getContentTypes = function () {                                                                               // 74
        return contentTypes;                                                                                           // 75
    };                                                                                                                 // 76
                                                                                                                       //
    /**                                                                                                                // 78
     * Returns the allowed extensions                                                                                  //
     * @return {Array}                                                                                                 //
     */                                                                                                                //
    self.getExtensions = function () {                                                                                 // 82
        return extensions;                                                                                             // 83
    };                                                                                                                 // 84
                                                                                                                       //
    /**                                                                                                                // 86
     * Returns the maximum file size                                                                                   //
     * @return {Number}                                                                                                //
     */                                                                                                                //
    self.getMaxSize = function () {                                                                                    // 90
        return maxSize;                                                                                                // 91
    };                                                                                                                 // 92
                                                                                                                       //
    /**                                                                                                                // 94
     * Returns the minimum file size                                                                                   //
     * @return {Number}                                                                                                //
     */                                                                                                                //
    self.getMinSize = function () {                                                                                    // 98
        return minSize;                                                                                                // 99
    };                                                                                                                 // 100
                                                                                                                       //
    /**                                                                                                                // 102
     * Checks if the file matches filter                                                                               //
     * @param file                                                                                                     //
     * @return {boolean}                                                                                               //
     */                                                                                                                //
    self.isValid = function (file) {                                                                                   // 107
        var result = true;                                                                                             // 108
        try {                                                                                                          // 109
            self.check(file);                                                                                          // 110
        } catch (err) {                                                                                                // 111
            result = false;                                                                                            // 112
        }                                                                                                              // 113
        return result;                                                                                                 // 114
    };                                                                                                                 // 115
};                                                                                                                     // 116
                                                                                                                       //
function checkContentType(type, list) {                                                                                // 118
    if (type) {                                                                                                        // 119
        if (_.contains(list, type)) {                                                                                  // 120
            return true;                                                                                               // 121
        } else {                                                                                                       // 122
            var _ret = function () {                                                                                   // 122
                var wildCardGlob = '/*';                                                                               // 123
                var wildcards = _.filter(list, function (item) {                                                       // 124
                    return item.indexOf(wildCardGlob) > 0;                                                             // 125
                });                                                                                                    // 126
                                                                                                                       //
                if (_.contains(wildcards, type.replace(/(\/.*)$/, wildCardGlob))) {                                    // 128
                    return {                                                                                           // 129
                        v: true                                                                                        // 129
                    };                                                                                                 // 129
                }                                                                                                      // 130
            }();                                                                                                       // 122
                                                                                                                       //
            if ((typeof _ret === 'undefined' ? 'undefined' : _typeof(_ret)) === "object") return _ret.v;               // 122
        }                                                                                                              // 131
    }                                                                                                                  // 132
    return false;                                                                                                      // 133
}                                                                                                                      // 134
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"ufs-store-permissions.js":["meteor/underscore",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/jalik_ufs/ufs-store-permissions.js                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _;module.import('meteor/underscore',{"_":function(v){_=v}});                                                       // 1
                                                                                                                       //
/**                                                                                                                    // 3
 * Store permissions                                                                                                   //
 * @param options                                                                                                      //
 * @constructor                                                                                                        //
 */                                                                                                                    //
UploadFS.StorePermissions = function (options) {                                                                       // 8
    var _this = this;                                                                                                  // 8
                                                                                                                       //
    // Default options                                                                                                 // 9
    options = _.extend({                                                                                               // 10
        insert: null,                                                                                                  // 11
        remove: null,                                                                                                  // 12
        update: null                                                                                                   // 13
    }, options);                                                                                                       // 10
                                                                                                                       //
    // Check options                                                                                                   // 16
    if (typeof options.insert === 'function') {                                                                        // 17
        this.insert = options.insert;                                                                                  // 18
    }                                                                                                                  // 19
    if (typeof options.remove === 'function') {                                                                        // 20
        this.remove = options.remove;                                                                                  // 21
    }                                                                                                                  // 22
    if (typeof options.update === 'function') {                                                                        // 23
        this.update = options.update;                                                                                  // 24
    }                                                                                                                  // 25
                                                                                                                       //
    var checkPermission = function checkPermission(permission, userId, file, fields, modifiers) {                      // 27
        if (typeof _this[permission] === 'function') {                                                                 // 28
            return _this[permission](userId, file, fields, modifiers);                                                 // 29
        }                                                                                                              // 30
        return true; // by default allow all                                                                           // 31
    };                                                                                                                 // 32
                                                                                                                       //
    /**                                                                                                                // 34
     * Checks the insert permission                                                                                    //
     * @param userId                                                                                                   //
     * @param file                                                                                                     //
     * @returns {*}                                                                                                    //
     */                                                                                                                //
    this.checkInsert = function (userId, file) {                                                                       // 40
        return checkPermission('insert', userId, file);                                                                // 41
    };                                                                                                                 // 42
    /**                                                                                                                // 43
     * Checks the remove permission                                                                                    //
     * @param userId                                                                                                   //
     * @param file                                                                                                     //
     * @returns {*}                                                                                                    //
     */                                                                                                                //
    this.checkRemove = function (userId, file) {                                                                       // 49
        return checkPermission('remove', userId, file);                                                                // 50
    };                                                                                                                 // 51
    /**                                                                                                                // 52
     * Checks the update permission                                                                                    //
     * @param userId                                                                                                   //
     * @param file                                                                                                     //
     * @param fields                                                                                                   //
     * @param modifiers                                                                                                //
     * @returns {*}                                                                                                    //
     */                                                                                                                //
    this.checkUpdate = function (userId, file, fields, modifiers) {                                                    // 60
        return checkPermission('update', userId, file, fields, modifiers);                                             // 61
    };                                                                                                                 // 62
};                                                                                                                     // 63
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"ufs-store.js":["meteor/underscore","meteor/check","meteor/meteor","meteor/mongo",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/jalik_ufs/ufs-store.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _;module.import('meteor/underscore',{"_":function(v){_=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       // 4
                                                                                                                       //
/**                                                                                                                    // 6
 * File store                                                                                                          //
 * @param options                                                                                                      //
 * @constructor                                                                                                        //
 */                                                                                                                    //
UploadFS.Store = function (options) {                                                                                  // 11
    var self = this;                                                                                                   // 12
                                                                                                                       //
    // Default options                                                                                                 // 14
    options = _.extend({                                                                                               // 15
        collection: null,                                                                                              // 16
        filter: null,                                                                                                  // 17
        name: null,                                                                                                    // 18
        onCopyError: null,                                                                                             // 19
        onFinishUpload: null,                                                                                          // 20
        onRead: null,                                                                                                  // 21
        onReadError: null,                                                                                             // 22
        onWriteError: null,                                                                                            // 23
        permissions: null,                                                                                             // 24
        transformRead: null,                                                                                           // 25
        transformWrite: null                                                                                           // 26
    }, options);                                                                                                       // 15
                                                                                                                       //
    // Check instance                                                                                                  // 29
    if (!(self instanceof UploadFS.Store)) {                                                                           // 30
        throw new Error('UploadFS.Store is not an instance');                                                          // 31
    }                                                                                                                  // 32
                                                                                                                       //
    // Check options                                                                                                   // 34
    if (!(options.collection instanceof Mongo.Collection)) {                                                           // 35
        throw new TypeError('collection is not a Mongo.Collection');                                                   // 36
    }                                                                                                                  // 37
    if (options.filter && !(options.filter instanceof UploadFS.Filter)) {                                              // 38
        throw new TypeError('filter is not a UploadFS.Filter');                                                        // 39
    }                                                                                                                  // 40
    if (typeof options.name !== 'string') {                                                                            // 41
        throw new TypeError('name is not a string');                                                                   // 42
    }                                                                                                                  // 43
    if (UploadFS.getStore(options.name)) {                                                                             // 44
        throw new TypeError('name already exists');                                                                    // 45
    }                                                                                                                  // 46
    if (options.onCopyError && typeof options.onCopyError !== 'function') {                                            // 47
        throw new TypeError('onCopyError is not a function');                                                          // 48
    }                                                                                                                  // 49
    if (options.onFinishUpload && typeof options.onFinishUpload !== 'function') {                                      // 50
        throw new TypeError('onFinishUpload is not a function');                                                       // 51
    }                                                                                                                  // 52
    if (options.onRead && typeof options.onRead !== 'function') {                                                      // 53
        throw new TypeError('onRead is not a function');                                                               // 54
    }                                                                                                                  // 55
    if (options.onReadError && typeof options.onReadError !== 'function') {                                            // 56
        throw new TypeError('onReadError is not a function');                                                          // 57
    }                                                                                                                  // 58
    if (options.onWriteError && typeof options.onWriteError !== 'function') {                                          // 59
        throw new TypeError('onWriteError is not a function');                                                         // 60
    }                                                                                                                  // 61
    if (options.permissions && !(options.permissions instanceof UploadFS.StorePermissions)) {                          // 62
        throw new TypeError('permissions is not a UploadFS.StorePermissions');                                         // 63
    }                                                                                                                  // 64
    if (options.transformRead && typeof options.transformRead !== 'function') {                                        // 65
        throw new TypeError('transformRead is not a function');                                                        // 66
    }                                                                                                                  // 67
    if (options.transformWrite && typeof options.transformWrite !== 'function') {                                      // 68
        throw new TypeError('transformWrite is not a function');                                                       // 69
    }                                                                                                                  // 70
                                                                                                                       //
    // Public attributes                                                                                               // 72
    self.onCopyError = options.onCopyError || self.onCopyError;                                                        // 73
    self.onFinishUpload = options.onFinishUpload || self.onFinishUpload;                                               // 74
    self.onRead = options.onRead || self.onRead;                                                                       // 75
    self.onReadError = options.onReadError || self.onReadError;                                                        // 76
    self.onWriteError = options.onWriteError || self.onWriteError;                                                     // 77
    self.permissions = options.permissions;                                                                            // 78
                                                                                                                       //
    // Private attributes                                                                                              // 80
    var collection = options.collection;                                                                               // 81
    var copyTo = options.copyTo;                                                                                       // 82
    var filter = options.filter;                                                                                       // 83
    var name = options.name;                                                                                           // 84
    var transformRead = options.transformRead;                                                                         // 85
    var transformWrite = options.transformWrite;                                                                       // 86
                                                                                                                       //
    // Set default permissions                                                                                         // 88
    if (!(self.permissions instanceof UploadFS.StorePermissions)) {                                                    // 89
        // Uses user's default permissions or UFS default permissions (deny all)                                       // 90
        if (UploadFS.config.defaultStorePermissions instanceof UploadFS.StorePermissions) {                            // 91
            self.permissions = UploadFS.config.defaultStorePermissions;                                                // 92
        } else {                                                                                                       // 93
            self.permissions = new UploadFS.StorePermissions();                                                        // 94
            console.warn('ufs: permissions are not defined for store "' + name + '"');                                 // 95
        }                                                                                                              // 96
    }                                                                                                                  // 97
                                                                                                                       //
    // Add the store to the list                                                                                       // 99
    UploadFS.getStores()[name] = self;                                                                                 // 100
                                                                                                                       //
    /**                                                                                                                // 102
     * Returns the collection                                                                                          //
     * @return {Mongo.Collection}                                                                                      //
     */                                                                                                                //
    self.getCollection = function () {                                                                                 // 106
        return collection;                                                                                             // 107
    };                                                                                                                 // 108
                                                                                                                       //
    /**                                                                                                                // 110
     * Returns the file filter                                                                                         //
     * @return {UploadFS.Filter}                                                                                       //
     */                                                                                                                //
    self.getFilter = function () {                                                                                     // 114
        return filter;                                                                                                 // 115
    };                                                                                                                 // 116
                                                                                                                       //
    /**                                                                                                                // 118
     * Returns the store name                                                                                          //
     * @return {string}                                                                                                //
     */                                                                                                                //
    self.getName = function () {                                                                                       // 122
        return name;                                                                                                   // 123
    };                                                                                                                 // 124
                                                                                                                       //
    /**                                                                                                                // 126
     * Defines the store permissions                                                                                   //
     * @param permissions                                                                                              //
     */                                                                                                                //
    self.setPermissions = function (permissions) {                                                                     // 130
        if (!(permissions instanceof UploadFS.StorePermissions)) {                                                     // 131
            throw new TypeError("permissions is not an instance of UploadFS.StorePermissions");                        // 132
        }                                                                                                              // 133
        self.permissions = permissions;                                                                                // 134
    };                                                                                                                 // 135
                                                                                                                       //
    if (Meteor.isServer) {                                                                                             // 137
                                                                                                                       //
        /**                                                                                                            // 139
         * Checks token validity                                                                                       //
         * @param token                                                                                                //
         * @param fileId                                                                                               //
         * @returns {boolean}                                                                                          //
         */                                                                                                            //
        self.checkToken = function (token, fileId) {                                                                   // 145
            check(token, String);                                                                                      // 146
            check(fileId, String);                                                                                     // 147
            return UploadFS.tokens.find({ value: token, fileId: fileId }).count() === 1;                               // 148
        };                                                                                                             // 149
                                                                                                                       //
        /**                                                                                                            // 151
         * Copies the file to a store                                                                                  //
         * @param fileId                                                                                               //
         * @param store                                                                                                //
         * @param callback                                                                                             //
         */                                                                                                            //
        self.copy = function (fileId, store, callback) {                                                               // 157
            check(fileId, String);                                                                                     // 158
                                                                                                                       //
            if (!(store instanceof UploadFS.Store)) {                                                                  // 160
                throw new TypeError('store is not a UploadFS.store.Store');                                            // 161
            }                                                                                                          // 162
            // Get original file                                                                                       // 163
            var file = collection.findOne({ _id: fileId });                                                            // 164
            if (!file) {                                                                                               // 165
                throw new Meteor.Error(404, 'File not found');                                                         // 166
            }                                                                                                          // 167
            // Ignore the file if it does not match store filter                                                       // 168
            var filter = store.getFilter();                                                                            // 169
            if (filter instanceof UploadFS.Filter && !filter.isValid(file)) {                                          // 170
                return;                                                                                                // 171
            }                                                                                                          // 172
                                                                                                                       //
            // Prepare copy                                                                                            // 174
            var copy = _.omit(file, '_id', 'url');                                                                     // 175
            copy.originalStore = self.getName();                                                                       // 176
            copy.originalId = fileId;                                                                                  // 177
                                                                                                                       //
            // Create the copy                                                                                         // 179
            var copyId = store.create(copy);                                                                           // 180
                                                                                                                       //
            // Get original stream                                                                                     // 182
            var rs = self.getReadStream(fileId, file);                                                                 // 183
                                                                                                                       //
            // Catch errors to avoid app crashing                                                                      // 185
            rs.on('error', Meteor.bindEnvironment(function (err) {                                                     // 186
                callback.call(self, err, null);                                                                        // 187
            }));                                                                                                       // 188
                                                                                                                       //
            // Copy file data                                                                                          // 190
            store.write(rs, copyId, Meteor.bindEnvironment(function (err) {                                            // 191
                if (err) {                                                                                             // 192
                    collection.remove({ _id: copyId });                                                                // 193
                    self.onCopyError.call(self, err, fileId, file);                                                    // 194
                }                                                                                                      // 195
                if (typeof callback === 'function') {                                                                  // 196
                    callback.call(self, err, copyId, copy, store);                                                     // 197
                }                                                                                                      // 198
            }));                                                                                                       // 199
        };                                                                                                             // 200
                                                                                                                       //
        /**                                                                                                            // 202
         * Creates the file in the collection                                                                          //
         * @param file                                                                                                 //
         * @param callback                                                                                             //
         * @return {string}                                                                                            //
         */                                                                                                            //
        self.create = function (file, callback) {                                                                      // 208
            check(file, Object);                                                                                       // 209
            file.store = name;                                                                                         // 210
            return collection.insert(file, callback);                                                                  // 211
        };                                                                                                             // 212
                                                                                                                       //
        /**                                                                                                            // 214
         * Creates a token for the file (only needed for client side upload)                                           //
         * @param fileId                                                                                               //
         * @returns {*}                                                                                                //
         */                                                                                                            //
        self.createToken = function (fileId) {                                                                         // 219
            var token = self.generateToken();                                                                          // 220
                                                                                                                       //
            // Check if token exists                                                                                   // 222
            if (UploadFS.tokens.find({ fileId: fileId }).count()) {                                                    // 223
                UploadFS.tokens.update({ fileId: fileId }, {                                                           // 224
                    $set: {                                                                                            // 225
                        createdAt: new Date(),                                                                         // 226
                        value: token                                                                                   // 227
                    }                                                                                                  // 225
                });                                                                                                    // 224
            } else {                                                                                                   // 230
                UploadFS.tokens.insert({                                                                               // 231
                    createdAt: new Date(),                                                                             // 232
                    fileId: fileId,                                                                                    // 233
                    value: token                                                                                       // 234
                });                                                                                                    // 231
            }                                                                                                          // 236
            return token;                                                                                              // 237
        };                                                                                                             // 238
                                                                                                                       //
        /**                                                                                                            // 240
         * Generates a random token                                                                                    //
         * @param pattern                                                                                              //
         * @return {string}                                                                                            //
         */                                                                                                            //
        self.generateToken = function (pattern) {                                                                      // 245
            return (pattern || 'xyxyxyxyxy').replace(/[xy]/g, function (c) {                                           // 246
                var r = Math.random() * 16 | 0,                                                                        // 247
                    v = c == 'x' ? r : r & 0x3 | 0x8;                                                                  // 247
                var s = v.toString(16);                                                                                // 248
                return Math.round(Math.random()) ? s.toUpperCase() : s;                                                // 249
            });                                                                                                        // 250
        };                                                                                                             // 251
                                                                                                                       //
        /**                                                                                                            // 253
         * Transforms the file on reading                                                                              //
         * @param readStream                                                                                           //
         * @param writeStream                                                                                          //
         * @param fileId                                                                                               //
         * @param file                                                                                                 //
         * @param request                                                                                              //
         * @param headers                                                                                              //
         */                                                                                                            //
        self.transformRead = function (readStream, writeStream, fileId, file, request, headers) {                      // 262
            if (typeof transformRead === 'function') {                                                                 // 263
                transformRead.call(self, readStream, writeStream, fileId, file, request, headers);                     // 264
            } else {                                                                                                   // 265
                readStream.pipe(writeStream);                                                                          // 266
            }                                                                                                          // 267
        };                                                                                                             // 268
                                                                                                                       //
        /**                                                                                                            // 270
         * Transforms the file on writing                                                                              //
         * @param readStream                                                                                           //
         * @param writeStream                                                                                          //
         * @param fileId                                                                                               //
         * @param file                                                                                                 //
         */                                                                                                            //
        self.transformWrite = function (readStream, writeStream, fileId, file) {                                       // 277
            if (typeof transformWrite === 'function') {                                                                // 278
                transformWrite.call(self, readStream, writeStream, fileId, file);                                      // 279
            } else {                                                                                                   // 280
                readStream.pipe(writeStream);                                                                          // 281
            }                                                                                                          // 282
        };                                                                                                             // 283
                                                                                                                       //
        /**                                                                                                            // 285
         * Writes the file to the store                                                                                //
         * @param rs                                                                                                   //
         * @param fileId                                                                                               //
         * @param callback                                                                                             //
         */                                                                                                            //
        self.write = function (rs, fileId, callback) {                                                                 // 291
            var file = collection.findOne({ _id: fileId });                                                            // 292
            var ws = self.getWriteStream(fileId, file);                                                                // 293
                                                                                                                       //
            var errorHandler = Meteor.bindEnvironment(function (err) {                                                 // 295
                collection.remove({ _id: fileId });                                                                    // 296
                self.onWriteError.call(self, err, fileId, file);                                                       // 297
                callback.call(self, err);                                                                              // 298
            });                                                                                                        // 299
                                                                                                                       //
            ws.on('error', errorHandler);                                                                              // 301
            ws.on('finish', Meteor.bindEnvironment(function () {                                                       // 302
                var size = 0;                                                                                          // 303
                var readStream = self.getReadStream(fileId, file);                                                     // 304
                                                                                                                       //
                readStream.on('error', Meteor.bindEnvironment(function (error) {                                       // 306
                    callback.call(self, error, null);                                                                  // 307
                }));                                                                                                   // 308
                readStream.on('data', Meteor.bindEnvironment(function (data) {                                         // 309
                    size += data.length;                                                                               // 310
                }));                                                                                                   // 311
                readStream.on('end', Meteor.bindEnvironment(function () {                                              // 312
                    // Set file attribute                                                                              // 313
                    file.complete = true;                                                                              // 314
                    file.path = self.getFileRelativeURL(fileId);                                                       // 315
                    file.progress = 1;                                                                                 // 316
                    file.size = size;                                                                                  // 317
                    file.token = self.generateToken();                                                                 // 318
                    file.uploading = false;                                                                            // 319
                    file.uploadedAt = new Date();                                                                      // 320
                    file.url = self.getFileURL(fileId);                                                                // 321
                                                                                                                       //
                    // Sets the file URL when file transfer is complete,                                               // 323
                    // this way, the image will loads entirely.                                                        // 324
                    collection.direct.update({ _id: fileId }, {                                                        // 325
                        $set: {                                                                                        // 326
                            complete: file.complete,                                                                   // 327
                            path: file.path,                                                                           // 328
                            progress: file.progress,                                                                   // 329
                            size: file.size,                                                                           // 330
                            token: file.token,                                                                         // 331
                            uploading: file.uploading,                                                                 // 332
                            uploadedAt: file.uploadedAt,                                                               // 333
                            url: file.url                                                                              // 334
                        }                                                                                              // 326
                    });                                                                                                // 325
                                                                                                                       //
                    // Return file info                                                                                // 338
                    callback.call(self, null, file);                                                                   // 339
                                                                                                                       //
                    // Execute callback                                                                                // 341
                    if (typeof self.onFinishUpload == 'function') {                                                    // 342
                        self.onFinishUpload.call(self, file);                                                          // 343
                    }                                                                                                  // 344
                                                                                                                       //
                    // Simulate write speed                                                                            // 346
                    if (UploadFS.config.simulateWriteDelay) {                                                          // 347
                        Meteor._sleepForMs(UploadFS.config.simulateWriteDelay);                                        // 348
                    }                                                                                                  // 349
                                                                                                                       //
                    // Copy file to other stores                                                                       // 351
                    if (copyTo instanceof Array) {                                                                     // 352
                        for (var i = 0; i < copyTo.length; i += 1) {                                                   // 353
                            var store = copyTo[i];                                                                     // 354
                                                                                                                       //
                            if (!store.getFilter() || store.getFilter().isValid(file)) {                               // 356
                                self.copy(fileId, store);                                                              // 357
                            }                                                                                          // 358
                        }                                                                                              // 359
                    }                                                                                                  // 360
                }));                                                                                                   // 361
            }));                                                                                                       // 362
                                                                                                                       //
            // Execute transformation                                                                                  // 364
            self.transformWrite(rs, ws, fileId, file);                                                                 // 365
        };                                                                                                             // 366
    }                                                                                                                  // 367
                                                                                                                       //
    if (Meteor.isServer) {                                                                                             // 369
        (function () {                                                                                                 // 369
            var fs = Npm.require('fs');                                                                                // 370
                                                                                                                       //
            // Code executed after removing file                                                                       // 372
            collection.after.remove(function (userId, file) {                                                          // 373
                // Remove associated tokens                                                                            // 374
                UploadFS.tokens.remove({ fileId: file._id });                                                          // 375
                                                                                                                       //
                if (copyTo instanceof Array) {                                                                         // 377
                    for (var i = 0; i < copyTo.length; i += 1) {                                                       // 378
                        // Remove copies in stores                                                                     // 379
                        copyTo[i].getCollection().remove({ originalId: file._id });                                    // 380
                    }                                                                                                  // 381
                }                                                                                                      // 382
            });                                                                                                        // 383
                                                                                                                       //
            // Code executed before inserting file                                                                     // 385
            collection.before.insert(function (userId, file) {                                                         // 386
                if (!self.permissions.checkInsert(userId, file)) {                                                     // 387
                    throw new Meteor.Error('forbidden', "Forbidden");                                                  // 388
                }                                                                                                      // 389
            });                                                                                                        // 390
                                                                                                                       //
            // Code executed before updating file                                                                      // 392
            collection.before.update(function (userId, file, fields, modifiers) {                                      // 393
                if (!self.permissions.checkUpdate(userId, file, fields, modifiers)) {                                  // 394
                    throw new Meteor.Error('forbidden', "Forbidden");                                                  // 395
                }                                                                                                      // 396
            });                                                                                                        // 397
                                                                                                                       //
            // Code executed before removing file                                                                      // 399
            collection.before.remove(function (userId, file) {                                                         // 400
                if (!self.permissions.checkRemove(userId, file)) {                                                     // 401
                    throw new Meteor.Error('forbidden', "Forbidden");                                                  // 402
                }                                                                                                      // 403
                                                                                                                       //
                // Delete the physical file in the store                                                               // 405
                self['delete'](file._id);                                                                              // 406
                                                                                                                       //
                var tmpFile = UploadFS.getTempFilePath(file._id);                                                      // 408
                                                                                                                       //
                // Delete the temp file                                                                                // 410
                fs.stat(tmpFile, function (err) {                                                                      // 411
                    !err && fs.unlink(tmpFile, function (err) {                                                        // 412
                        err && console.error('ufs: cannot delete temp file at ' + tmpFile + ' (' + err.message + ')');
                    });                                                                                                // 414
                });                                                                                                    // 415
            });                                                                                                        // 416
        })();                                                                                                          // 369
    }                                                                                                                  // 417
};                                                                                                                     // 418
                                                                                                                       //
/**                                                                                                                    // 420
 * Returns the file URL                                                                                                //
 * @param fileId                                                                                                       //
 */                                                                                                                    //
UploadFS.Store.prototype.getFileRelativeURL = function (fileId) {                                                      // 424
    var file = this.getCollection().findOne({ _id: fileId }, { fields: { name: 1 } });                                 // 425
    return file && this.getRelativeURL(fileId + '/' + encodeURIComponent(file.name));                                  // 426
};                                                                                                                     // 427
                                                                                                                       //
/**                                                                                                                    // 429
 * Returns the file URL                                                                                                //
 * @param fileId                                                                                                       //
 */                                                                                                                    //
UploadFS.Store.prototype.getFileURL = function (fileId) {                                                              // 433
    var file = this.getCollection().findOne({ _id: fileId }, { fields: { name: 1 } });                                 // 434
    return file && this.getURL(fileId + '/' + encodeURIComponent(file.name));                                          // 435
};                                                                                                                     // 436
                                                                                                                       //
/**                                                                                                                    // 438
 * Returns the store relative URL                                                                                      //
 * @param path                                                                                                         //
 */                                                                                                                    //
UploadFS.Store.prototype.getRelativeURL = function (path) {                                                            // 442
    return [UploadFS.config.storesPath, this.getName(), path].join('/').replace(/\/$/, '');                            // 443
};                                                                                                                     // 444
                                                                                                                       //
/**                                                                                                                    // 446
 * Returns the store absolute URL                                                                                      //
 * @param path                                                                                                         //
 */                                                                                                                    //
UploadFS.Store.prototype.getURL = function (path) {                                                                    // 450
    return Meteor.absoluteUrl(this.getRelativeURL(path), { secure: UploadFS.config.https });                           // 451
};                                                                                                                     // 452
                                                                                                                       //
/**                                                                                                                    // 454
 * Completes the file upload                                                                                           //
 * @param url                                                                                                          //
 * @param file                                                                                                         //
 * @param callback                                                                                                     //
 */                                                                                                                    //
UploadFS.Store.prototype.importFromURL = function (url, file, callback) {                                              // 460
    Meteor.call('ufsImportURL', url, file, this.getName(), callback);                                                  // 461
};                                                                                                                     // 462
                                                                                                                       //
if (Meteor.isServer) {                                                                                                 // 464
    /**                                                                                                                // 465
     * Deletes a file async                                                                                            //
     * @param fileId                                                                                                   //
     * @param callback                                                                                                 //
     */                                                                                                                //
    UploadFS.Store.prototype['delete'] = function (fileId, callback) {                                                 // 470
        throw new Error('delete is not implemented');                                                                  // 471
    };                                                                                                                 // 472
                                                                                                                       //
    /**                                                                                                                // 474
     * Returns the file read stream                                                                                    //
     * @param fileId                                                                                                   //
     * @param file                                                                                                     //
     */                                                                                                                //
    UploadFS.Store.prototype.getReadStream = function (fileId, file) {                                                 // 479
        throw new Error('getReadStream is not implemented');                                                           // 480
    };                                                                                                                 // 481
                                                                                                                       //
    /**                                                                                                                // 483
     * Returns the file write stream                                                                                   //
     * @param fileId                                                                                                   //
     * @param file                                                                                                     //
     */                                                                                                                //
    UploadFS.Store.prototype.getWriteStream = function (fileId, file) {                                                // 488
        throw new Error('getWriteStream is not implemented');                                                          // 489
    };                                                                                                                 // 490
                                                                                                                       //
    /**                                                                                                                // 492
     * Callback for copy errors                                                                                        //
     * @param err                                                                                                      //
     * @param fileId                                                                                                   //
     * @param file                                                                                                     //
     * @return boolean                                                                                                 //
     */                                                                                                                //
    UploadFS.Store.prototype.onCopyError = function (err, fileId, file) {                                              // 499
        console.error('ufs: cannot copy file "' + fileId + '" (' + err.message + ')', err);                            // 500
    };                                                                                                                 // 501
                                                                                                                       //
    /**                                                                                                                // 503
     * Called when a file has been uploaded                                                                            //
     * @param file                                                                                                     //
     */                                                                                                                //
    UploadFS.Store.prototype.onFinishUpload = function (file) {};                                                      // 507
                                                                                                                       //
    /**                                                                                                                // 510
     * Called when a file is read from the store                                                                       //
     * @param fileId                                                                                                   //
     * @param file                                                                                                     //
     * @param request                                                                                                  //
     * @param response                                                                                                 //
     * @return boolean                                                                                                 //
     */                                                                                                                //
    UploadFS.Store.prototype.onRead = function (fileId, file, request, response) {                                     // 518
        return true;                                                                                                   // 519
    };                                                                                                                 // 520
                                                                                                                       //
    /**                                                                                                                // 522
     * Callback for read errors                                                                                        //
     * @param err                                                                                                      //
     * @param fileId                                                                                                   //
     * @param file                                                                                                     //
     * @return boolean                                                                                                 //
     */                                                                                                                //
    UploadFS.Store.prototype.onReadError = function (err, fileId, file) {                                              // 529
        console.error('ufs: cannot read file "' + fileId + '" (' + err.message + ')', err);                            // 530
    };                                                                                                                 // 531
                                                                                                                       //
    /**                                                                                                                // 533
     * Callback for write errors                                                                                       //
     * @param err                                                                                                      //
     * @param fileId                                                                                                   //
     * @param file                                                                                                     //
     * @return boolean                                                                                                 //
     */                                                                                                                //
    UploadFS.Store.prototype.onWriteError = function (err, fileId, file) {                                             // 540
        console.error('ufs: cannot write file "' + fileId + '" (' + err.message + ')', err);                           // 541
    };                                                                                                                 // 542
}                                                                                                                      // 543
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"ufs-helpers.js":["meteor/templating",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/jalik_ufs/ufs-helpers.js                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Template;module.import('meteor/templating',{"Template":function(v){Template=v}});                                  // 1
                                                                                                                       //
var isMIME = function isMIME(type, mime) {                                                                             // 3
    return typeof type === 'string' && typeof mime === 'string' && mime.indexOf(type + '/') === 0;                     // 4
};                                                                                                                     // 7
                                                                                                                       //
Template.registerHelper('isApplication', function (type) {                                                             // 9
    return isMIME('application', this.type || type);                                                                   // 10
});                                                                                                                    // 11
                                                                                                                       //
Template.registerHelper('isAudio', function (type) {                                                                   // 13
    return isMIME('audio', this.type || type);                                                                         // 14
});                                                                                                                    // 15
                                                                                                                       //
Template.registerHelper('isImage', function (type) {                                                                   // 17
    return isMIME('image', this.type || type);                                                                         // 18
});                                                                                                                    // 19
                                                                                                                       //
Template.registerHelper('isText', function (type) {                                                                    // 21
    return isMIME('text', this.type || type);                                                                          // 22
});                                                                                                                    // 23
                                                                                                                       //
Template.registerHelper('isVideo', function (type) {                                                                   // 25
    return isMIME('video', this.type || type);                                                                         // 26
});                                                                                                                    // 27
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"ufs-uploader.js":["babel-runtime/helpers/typeof","meteor/underscore","meteor/meteor",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/jalik_ufs/ufs-uploader.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _typeof;module.import('babel-runtime/helpers/typeof',{"default":function(v){_typeof=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});
                                                                                                                       // 1
                                                                                                                       // 2
                                                                                                                       //
/**                                                                                                                    // 4
 * File uploader                                                                                                       //
 * @param options                                                                                                      //
 * @constructor                                                                                                        //
 */                                                                                                                    //
UploadFS.Uploader = function (options) {                                                                               // 9
    var self = this;                                                                                                   // 10
                                                                                                                       //
    // Set default options                                                                                             // 12
    options = _.extend({                                                                                               // 13
        adaptive: true,                                                                                                // 14
        capacity: 0.9,                                                                                                 // 15
        chunkSize: 16 * 1024,                                                                                          // 16
        data: null,                                                                                                    // 17
        file: null,                                                                                                    // 18
        maxChunkSize: 4 * 1024 * 1000,                                                                                 // 19
        maxTries: 5,                                                                                                   // 20
        onAbort: UploadFS.Uploader.prototype.onAbort,                                                                  // 21
        onComplete: UploadFS.Uploader.prototype.onComplete,                                                            // 22
        onCreate: UploadFS.Uploader.prototype.onCreate,                                                                // 23
        onError: UploadFS.Uploader.prototype.onError,                                                                  // 24
        onProgress: UploadFS.Uploader.prototype.onProgress,                                                            // 25
        onStart: UploadFS.Uploader.prototype.onStart,                                                                  // 26
        onStop: UploadFS.Uploader.prototype.onStop,                                                                    // 27
        retryDelay: 2000,                                                                                              // 28
        store: null,                                                                                                   // 29
        transferDelay: 100                                                                                             // 30
    }, options);                                                                                                       // 13
                                                                                                                       //
    // Check options                                                                                                   // 33
    if (typeof options.adaptive !== 'boolean') {                                                                       // 34
        throw new TypeError('adaptive is not a number');                                                               // 35
    }                                                                                                                  // 36
    if (typeof options.capacity !== 'number') {                                                                        // 37
        throw new TypeError('capacity is not a number');                                                               // 38
    }                                                                                                                  // 39
    if (options.capacity <= 0 || options.capacity > 1) {                                                               // 40
        throw new RangeError('capacity must be a float between 0.1 and 1.0');                                          // 41
    }                                                                                                                  // 42
    if (typeof options.chunkSize !== 'number') {                                                                       // 43
        throw new TypeError('chunkSize is not a number');                                                              // 44
    }                                                                                                                  // 45
    if (!(options.data instanceof Blob) && !(options.data instanceof File)) {                                          // 46
        throw new TypeError('data is not an Blob or File');                                                            // 47
    }                                                                                                                  // 48
    if (options.file === null || _typeof(options.file) !== 'object') {                                                 // 49
        throw new TypeError('file is not an object');                                                                  // 50
    }                                                                                                                  // 51
    if (typeof options.maxChunkSize !== 'number') {                                                                    // 52
        throw new TypeError('maxChunkSize is not a number');                                                           // 53
    }                                                                                                                  // 54
    if (typeof options.maxTries !== 'number') {                                                                        // 55
        throw new TypeError('maxTries is not a number');                                                               // 56
    }                                                                                                                  // 57
    if (typeof options.retryDelay !== 'number') {                                                                      // 58
        throw new TypeError('retryDelay is not a number');                                                             // 59
    }                                                                                                                  // 60
    if (typeof options.transferDelay !== 'number') {                                                                   // 61
        throw new TypeError('transferDelay is not a number');                                                          // 62
    }                                                                                                                  // 63
    if (typeof options.onAbort !== 'function') {                                                                       // 64
        throw new TypeError('onAbort is not a function');                                                              // 65
    }                                                                                                                  // 66
    if (typeof options.onComplete !== 'function') {                                                                    // 67
        throw new TypeError('onComplete is not a function');                                                           // 68
    }                                                                                                                  // 69
    if (typeof options.onCreate !== 'function') {                                                                      // 70
        throw new TypeError('onCreate is not a function');                                                             // 71
    }                                                                                                                  // 72
    if (typeof options.onError !== 'function') {                                                                       // 73
        throw new TypeError('onError is not a function');                                                              // 74
    }                                                                                                                  // 75
    if (typeof options.onProgress !== 'function') {                                                                    // 76
        throw new TypeError('onProgress is not a function');                                                           // 77
    }                                                                                                                  // 78
    if (typeof options.onStart !== 'function') {                                                                       // 79
        throw new TypeError('onStart is not a function');                                                              // 80
    }                                                                                                                  // 81
    if (typeof options.onStop !== 'function') {                                                                        // 82
        throw new TypeError('onStop is not a function');                                                               // 83
    }                                                                                                                  // 84
    if (typeof options.store !== 'string' && !(options.store instanceof UploadFS.Store)) {                             // 85
        throw new TypeError('store must be the name of the store or an instance of UploadFS.Store');                   // 86
    }                                                                                                                  // 87
                                                                                                                       //
    // Public attributes                                                                                               // 89
    self.adaptive = options.adaptive;                                                                                  // 90
    self.capacity = parseFloat(options.capacity);                                                                      // 91
    self.chunkSize = parseInt(options.chunkSize);                                                                      // 92
    self.maxChunkSize = parseInt(options.maxChunkSize);                                                                // 93
    self.maxTries = parseInt(options.maxTries);                                                                        // 94
    self.retryDelay = parseInt(options.retryDelay);                                                                    // 95
    self.transferDelay = parseInt(options.transferDelay);                                                              // 96
    self.onAbort = options.onAbort;                                                                                    // 97
    self.onComplete = options.onComplete;                                                                              // 98
    self.onCreate = options.onCreate;                                                                                  // 99
    self.onError = options.onError;                                                                                    // 100
    self.onProgress = options.onProgress;                                                                              // 101
    self.onStart = options.onStart;                                                                                    // 102
    self.onStop = options.onStop;                                                                                      // 103
                                                                                                                       //
    // Private attributes                                                                                              // 105
    var store = options.store;                                                                                         // 106
    var data = options.data;                                                                                           // 107
    var capacityMargin = 0.1;                                                                                          // 108
    var file = options.file;                                                                                           // 109
    var fileId = null;                                                                                                 // 110
    var offset = 0;                                                                                                    // 111
    var loaded = 0;                                                                                                    // 112
    var total = data.size;                                                                                             // 113
    var tries = 0;                                                                                                     // 114
    var postUrl = null;                                                                                                // 115
    var token = null;                                                                                                  // 116
    var complete = false;                                                                                              // 117
    var uploading = false;                                                                                             // 118
                                                                                                                       //
    var timeA = null;                                                                                                  // 120
    var timeB = null;                                                                                                  // 121
                                                                                                                       //
    var elapsedTime = 0;                                                                                               // 123
    var startTime = 0;                                                                                                 // 124
                                                                                                                       //
    // Keep only the name of the store                                                                                 // 126
    if (store instanceof UploadFS.Store) {                                                                             // 127
        store = store.getName();                                                                                       // 128
    }                                                                                                                  // 129
                                                                                                                       //
    // Assign file to store                                                                                            // 131
    file.store = store;                                                                                                // 132
                                                                                                                       //
    function finish() {                                                                                                // 134
        // Finish the upload by telling the store the upload is complete                                               // 135
        Meteor.call('ufsComplete', fileId, store, token, function (err, uploadedFile) {                                // 136
            if (err) {                                                                                                 // 137
                // todo retry instead of abort                                                                         // 138
                self.abort();                                                                                          // 139
            } else if (uploadedFile) {                                                                                 // 141
                uploading = false;                                                                                     // 142
                complete = true;                                                                                       // 143
                file = uploadedFile;                                                                                   // 144
                self.onComplete(uploadedFile);                                                                         // 145
            }                                                                                                          // 146
        });                                                                                                            // 147
    }                                                                                                                  // 148
                                                                                                                       //
    /**                                                                                                                // 150
     * Aborts the current transfer                                                                                     //
     */                                                                                                                //
    self.abort = function () {                                                                                         // 153
        // Remove the file from database                                                                               // 154
        Meteor.call('ufsDelete', fileId, store, token, function (err, result) {                                        // 155
            if (err) {                                                                                                 // 156
                console.error('ufs: cannot remove file "' + fileId + '" (' + err.message + ')');                       // 157
                self.onError(err);                                                                                     // 158
            }                                                                                                          // 159
        });                                                                                                            // 160
                                                                                                                       //
        // Reset uploader status                                                                                       // 162
        uploading = false;                                                                                             // 163
        fileId = null;                                                                                                 // 164
        offset = 0;                                                                                                    // 165
        tries = 0;                                                                                                     // 166
        loaded = 0;                                                                                                    // 167
        complete = false;                                                                                              // 168
        startTime = null;                                                                                              // 169
        self.onAbort(file);                                                                                            // 170
    };                                                                                                                 // 171
                                                                                                                       //
    /**                                                                                                                // 173
     * Returns the average speed in bytes per second                                                                   //
     * @returns {number}                                                                                               //
     */                                                                                                                //
    self.getAverageSpeed = function () {                                                                               // 177
        var seconds = self.getElapsedTime() / 1000;                                                                    // 178
        return self.getLoaded() / seconds;                                                                             // 179
    };                                                                                                                 // 180
                                                                                                                       //
    /**                                                                                                                // 182
     * Returns the elapsed time in milliseconds                                                                        //
     * @returns {number}                                                                                               //
     */                                                                                                                //
    self.getElapsedTime = function () {                                                                                // 186
        if (startTime && self.isUploading()) {                                                                         // 187
            return elapsedTime + (Date.now() - startTime);                                                             // 188
        }                                                                                                              // 189
        return elapsedTime;                                                                                            // 190
    };                                                                                                                 // 191
                                                                                                                       //
    /**                                                                                                                // 193
     * Returns the file                                                                                                //
     * @return {object}                                                                                                //
     */                                                                                                                //
    self.getFile = function () {                                                                                       // 197
        return file;                                                                                                   // 198
    };                                                                                                                 // 199
                                                                                                                       //
    /**                                                                                                                // 201
     * Returns the loaded bytes                                                                                        //
     * @return {number}                                                                                                //
     */                                                                                                                //
    self.getLoaded = function () {                                                                                     // 205
        return loaded;                                                                                                 // 206
    };                                                                                                                 // 207
                                                                                                                       //
    /**                                                                                                                // 209
     * Returns current progress                                                                                        //
     * @return {number}                                                                                                //
     */                                                                                                                //
    self.getProgress = function () {                                                                                   // 213
        return Math.min(loaded / total * 100 / 100, 1.0);                                                              // 214
    };                                                                                                                 // 215
                                                                                                                       //
    /**                                                                                                                // 217
     * Returns the remaining time in milliseconds                                                                      //
     * @returns {number}                                                                                               //
     */                                                                                                                //
    self.getRemainingTime = function () {                                                                              // 221
        var averageSpeed = self.getAverageSpeed();                                                                     // 222
        var remainingBytes = total - self.getLoaded();                                                                 // 223
        return averageSpeed && remainingBytes ? Math.max(remainingBytes / averageSpeed, 0) : 0;                        // 224
    };                                                                                                                 // 225
                                                                                                                       //
    /**                                                                                                                // 227
     * Returns the upload speed in bytes per second                                                                    //
     * @returns {number}                                                                                               //
     */                                                                                                                //
    self.getSpeed = function () {                                                                                      // 231
        if (timeA && timeB && self.isUploading()) {                                                                    // 232
            var seconds = (timeB - timeA) / 1000;                                                                      // 233
            return self.chunkSize / seconds;                                                                           // 234
        }                                                                                                              // 235
        return 0;                                                                                                      // 236
    };                                                                                                                 // 237
                                                                                                                       //
    /**                                                                                                                // 239
     * Returns the total bytes                                                                                         //
     * @return {number}                                                                                                //
     */                                                                                                                //
    self.getTotal = function () {                                                                                      // 243
        return total;                                                                                                  // 244
    };                                                                                                                 // 245
                                                                                                                       //
    /**                                                                                                                // 247
     * Checks if the transfer is complete                                                                              //
     * @return {boolean}                                                                                               //
     */                                                                                                                //
    self.isComplete = function () {                                                                                    // 251
        return complete;                                                                                               // 252
    };                                                                                                                 // 253
                                                                                                                       //
    /**                                                                                                                // 255
     * Checks if the transfer is active                                                                                //
     * @return {boolean}                                                                                               //
     */                                                                                                                //
    self.isUploading = function () {                                                                                   // 259
        return uploading;                                                                                              // 260
    };                                                                                                                 // 261
                                                                                                                       //
    /**                                                                                                                // 263
     * Reads a portion of file                                                                                         //
     * @param start                                                                                                    //
     * @param length                                                                                                   //
     * @param callback                                                                                                 //
     * @returns {Blob}                                                                                                 //
     */                                                                                                                //
    self.readChunk = function (start, length, callback) {                                                              // 270
        if (typeof callback != 'function') {                                                                           // 271
            throw new Error('readChunk is missing callback');                                                          // 272
        }                                                                                                              // 273
        try {                                                                                                          // 274
            var end = void 0;                                                                                          // 275
                                                                                                                       //
            // Calculate the chunk size                                                                                // 277
            if (length && start + length > total) {                                                                    // 278
                end = total;                                                                                           // 279
            } else {                                                                                                   // 280
                end = start + length;                                                                                  // 281
            }                                                                                                          // 282
            // Get chunk                                                                                               // 283
            var chunk = data.slice(start, end);                                                                        // 284
            // Pass chunk to callback                                                                                  // 285
            callback.call(self, null, chunk);                                                                          // 286
        } catch (err) {                                                                                                // 288
            console.error('read error', err);                                                                          // 289
            // Retry to read chunk                                                                                     // 290
            Meteor.setTimeout(function () {                                                                            // 291
                if (tries < self.maxTries) {                                                                           // 292
                    tries += 1;                                                                                        // 293
                    self.readChunk(start, length, callback);                                                           // 294
                }                                                                                                      // 295
            }, self.retryDelay);                                                                                       // 296
        }                                                                                                              // 297
    };                                                                                                                 // 298
                                                                                                                       //
    /**                                                                                                                // 300
     * Sends a file chunk to the store                                                                                 //
     */                                                                                                                //
    self.sendChunk = function () {                                                                                     // 303
        if (!complete && startTime !== null) {                                                                         // 304
            if (offset < total) {                                                                                      // 305
                (function () {                                                                                         // 305
                    var chunkSize = self.chunkSize;                                                                    // 306
                                                                                                                       //
                    // Use adaptive length                                                                             // 308
                    if (self.adaptive && timeA && timeB && timeB > timeA) {                                            // 309
                        var duration = (timeB - timeA) / 1000;                                                         // 310
                        var max = self.capacity * (1 + capacityMargin);                                                // 311
                        var min = self.capacity * (1 - capacityMargin);                                                // 312
                                                                                                                       //
                        if (duration >= max) {                                                                         // 314
                            chunkSize = Math.abs(Math.round(chunkSize * (max - duration)));                            // 315
                        } else if (duration < min) {                                                                   // 317
                            chunkSize = Math.round(chunkSize * (min / duration));                                      // 318
                        }                                                                                              // 319
                        // Limit to max chunk size                                                                     // 320
                        if (self.maxChunkSize > 0 && chunkSize > self.maxChunkSize) {                                  // 321
                            chunkSize = self.maxChunkSize;                                                             // 322
                        }                                                                                              // 323
                    }                                                                                                  // 324
                                                                                                                       //
                    // Limit to max chunk size                                                                         // 326
                    if (self.maxChunkSize > 0 && chunkSize > self.maxChunkSize) {                                      // 327
                        chunkSize = self.maxChunkSize;                                                                 // 328
                    }                                                                                                  // 329
                                                                                                                       //
                    // Reduce chunk size to fit total                                                                  // 331
                    if (offset + chunkSize > total) {                                                                  // 332
                        chunkSize = total - offset;                                                                    // 333
                    }                                                                                                  // 334
                                                                                                                       //
                    // Prepare the chunk                                                                               // 336
                    self.readChunk(offset, chunkSize, function (err, chunk) {                                          // 337
                        if (err) {                                                                                     // 338
                            self.onError(err, file);                                                                   // 339
                            return;                                                                                    // 340
                        }                                                                                              // 341
                                                                                                                       //
                        var xhr = new XMLHttpRequest();                                                                // 343
                        xhr.onreadystatechange = function () {                                                         // 344
                            if (xhr.readyState === 4) {                                                                // 345
                                if (_.contains([200, 201, 202, 204], xhr.status)) {                                    // 346
                                    timeB = Date.now();                                                                // 347
                                    offset += chunkSize;                                                               // 348
                                    loaded += chunkSize;                                                               // 349
                                                                                                                       //
                                    // Send next chunk                                                                 // 351
                                    self.onProgress(file, self.getProgress());                                         // 352
                                                                                                                       //
                                    // Finish upload                                                                   // 354
                                    if (loaded >= total) {                                                             // 355
                                        elapsedTime = Date.now() - startTime;                                          // 356
                                        finish();                                                                      // 357
                                    } else {                                                                           // 358
                                        Meteor.setTimeout(self.sendChunk, self.transferDelay);                         // 359
                                    }                                                                                  // 360
                                } else if (!_.contains([402, 403, 404, 500], xhr.status)) {                            // 361
                                    // Retry until max tries is reach                                                  // 363
                                    // But don't retry if these errors occur                                           // 364
                                    if (tries <= self.maxTries) {                                                      // 365
                                        tries += 1;                                                                    // 366
                                        // Wait before retrying                                                        // 367
                                        Meteor.setTimeout(self.sendChunk, self.retryDelay);                            // 368
                                    } else {                                                                           // 369
                                        self.abort();                                                                  // 370
                                    }                                                                                  // 371
                                } else {                                                                               // 372
                                    self.abort();                                                                      // 374
                                }                                                                                      // 375
                            }                                                                                          // 376
                        };                                                                                             // 377
                                                                                                                       //
                        // Calculate upload progress                                                                   // 379
                        var progress = (offset + chunkSize) / total;                                                   // 380
                        // let formData = new FormData();                                                              // 381
                        // formData.append('progress', progress);                                                      // 382
                        // formData.append('chunk', chunk);                                                            // 383
                        var url = postUrl + '&progress=' + progress;                                                   // 384
                                                                                                                       //
                        timeA = Date.now();                                                                            // 386
                        timeB = null;                                                                                  // 387
                        uploading = true;                                                                              // 388
                                                                                                                       //
                        // Send chunk to the store                                                                     // 390
                        xhr.open('POST', url, true);                                                                   // 391
                        xhr.send(chunk);                                                                               // 392
                    });                                                                                                // 393
                })();                                                                                                  // 305
            }                                                                                                          // 394
        }                                                                                                              // 395
    };                                                                                                                 // 396
                                                                                                                       //
    /**                                                                                                                // 398
     * Starts or resumes the transfer                                                                                  //
     */                                                                                                                //
    self.start = function () {                                                                                         // 401
        if (!fileId) {                                                                                                 // 402
            // Create the file document and get the token                                                              // 403
            // that allows the user to send chunks to the store.                                                       // 404
            Meteor.call('ufsCreate', _.extend({}, file), function (err, result) {                                      // 405
                if (err) {                                                                                             // 406
                    self.onError(err, file);                                                                           // 407
                } else if (result) {                                                                                   // 408
                    token = result.token;                                                                              // 409
                    postUrl = result.url;                                                                              // 410
                    fileId = result.fileId;                                                                            // 411
                    file._id = result.fileId;                                                                          // 412
                    self.onCreate(file);                                                                               // 413
                    tries = 0;                                                                                         // 414
                    startTime = Date.now();                                                                            // 415
                    self.onStart(file);                                                                                // 416
                    self.sendChunk();                                                                                  // 417
                }                                                                                                      // 418
            });                                                                                                        // 419
        } else if (!uploading && !complete) {                                                                          // 420
            // Resume uploading                                                                                        // 421
            tries = 0;                                                                                                 // 422
            startTime = Date.now();                                                                                    // 423
            self.onStart(file);                                                                                        // 424
            self.sendChunk();                                                                                          // 425
        }                                                                                                              // 426
    };                                                                                                                 // 427
                                                                                                                       //
    /**                                                                                                                // 429
     * Stops the transfer                                                                                              //
     */                                                                                                                //
    self.stop = function () {                                                                                          // 432
        if (uploading) {                                                                                               // 433
            // Update elapsed time                                                                                     // 434
            elapsedTime = Date.now() - startTime;                                                                      // 435
            startTime = null;                                                                                          // 436
            uploading = false;                                                                                         // 437
            self.onStop(file);                                                                                         // 438
                                                                                                                       //
            Meteor.call('ufsStop', fileId, store, token, function (err, result) {                                      // 440
                if (err) {                                                                                             // 441
                    self.onError(err, file);                                                                           // 442
                }                                                                                                      // 443
            });                                                                                                        // 444
        }                                                                                                              // 445
    };                                                                                                                 // 446
};                                                                                                                     // 447
                                                                                                                       //
/**                                                                                                                    // 449
 * Called when the file upload is aborted                                                                              //
 * @param file                                                                                                         //
 */                                                                                                                    //
UploadFS.Uploader.prototype.onAbort = function (file) {};                                                              // 453
                                                                                                                       //
/**                                                                                                                    // 456
 * Called when the file upload is complete                                                                             //
 * @param file                                                                                                         //
 */                                                                                                                    //
UploadFS.Uploader.prototype.onComplete = function (file) {};                                                           // 460
                                                                                                                       //
/**                                                                                                                    // 463
 * Called when the file is created in the collection                                                                   //
 * @param file                                                                                                         //
 */                                                                                                                    //
UploadFS.Uploader.prototype.onCreate = function (file) {};                                                             // 467
                                                                                                                       //
/**                                                                                                                    // 470
 * Called when an error occurs during file upload                                                                      //
 * @param err                                                                                                          //
 */                                                                                                                    //
UploadFS.Uploader.prototype.onError = function (err) {                                                                 // 474
    console.error(err.message);                                                                                        // 475
};                                                                                                                     // 476
                                                                                                                       //
/**                                                                                                                    // 478
 * Called when a file chunk has been sent                                                                              //
 * @param file                                                                                                         //
 * @param progress is a float from 0.0 to 1.0                                                                          //
 */                                                                                                                    //
UploadFS.Uploader.prototype.onProgress = function (file, progress) {};                                                 // 483
                                                                                                                       //
/**                                                                                                                    // 486
 * Called when the file upload starts                                                                                  //
 * @param file                                                                                                         //
 */                                                                                                                    //
UploadFS.Uploader.prototype.onStart = function (file) {};                                                              // 490
                                                                                                                       //
/**                                                                                                                    // 493
 * Called when the file upload stops                                                                                   //
 * @param file                                                                                                         //
 */                                                                                                                    //
UploadFS.Uploader.prototype.onStop = function (file) {};                                                               // 497
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}}}},{"extensions":[".js",".json"]});
require("./node_modules/meteor/jalik:ufs/ufs.js");
require("./node_modules/meteor/jalik:ufs/ufs-mime.js");
require("./node_modules/meteor/jalik:ufs/ufs-utilities.js");
require("./node_modules/meteor/jalik:ufs/ufs-config.js");
require("./node_modules/meteor/jalik:ufs/ufs-filter.js");
require("./node_modules/meteor/jalik:ufs/ufs-store-permissions.js");
require("./node_modules/meteor/jalik:ufs/ufs-store.js");
require("./node_modules/meteor/jalik:ufs/ufs-helpers.js");
require("./node_modules/meteor/jalik:ufs/ufs-uploader.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['jalik:ufs'] = {}, {
  UploadFS: UploadFS
});

})();
