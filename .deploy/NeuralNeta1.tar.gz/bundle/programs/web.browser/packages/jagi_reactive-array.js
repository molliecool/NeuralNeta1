//////////////////////////////////////////////////////////////////////////
//                                                                      //
// This is a generated file. You can view the original                  //
// source in your browser if your browser supports source maps.         //
// Source maps are supported by all recent versions of Chrome, Safari,  //
// and Firefox, and by Internet Explorer 11.                            //
//                                                                      //
//////////////////////////////////////////////////////////////////////////


(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var lodash = Package['stevezhu:lodash'].lodash;
var _ = Package['stevezhu:lodash']._;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;

/* Package-scope variables */
var ReactiveArray;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/jagi_reactive-array/lib/reactive_array.js                //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
var changed = function(v) {                                          // 1
  v && v.changed();                                                  // 2
};                                                                   // 3
                                                                     // 4
ReactiveArray = function(dictName) {                                 // 5
  this._length = 0;                                                  // 6
  this._values = [];                                                 // 7
                                                                     // 8
  // Dependencies.                                                   // 9
  this._allDep = new Tracker.Dependency;                             // 10
  this._lengthDep = new Tracker.Dependency;                          // 11
  this._indexesDeps = [];                                            // 12
};                                                                   // 13
                                                                     // 14
_.extend(ReactiveArray.prototype, {                                  // 15
  _ensureIndex: function(index) {                                    // 16
    if (!this._indexesDeps[index]) {                                 // 17
      this._indexesDeps[index] = new Tracker.Dependency;             // 18
    }                                                                // 19
  },                                                                 // 20
                                                                     // 21
  // Getters.                                                        // 22
                                                                     // 23
  _getOne: function(index) {                                         // 24
    this._ensureIndex(index);                                        // 25
    this._indexesDeps[index].depend();                               // 26
                                                                     // 27
    return this._values[index];                                      // 28
  },                                                                 // 29
                                                                     // 30
  _getAll: function() {                                              // 31
    var self = this;                                                 // 32
                                                                     // 33
    self._allDep.depend();                                           // 34
                                                                     // 35
    var values = new Array(this._values.length);                     // 36
    _.each(this._values, function(value, index) {                    // 37
      values[index] = _.isUndefined(value) ? null : value;           // 38
    });                                                              // 39
                                                                     // 40
    return values;                                                   // 41
  },                                                                 // 42
                                                                     // 43
  get: function() {                                                  // 44
    if (arguments.length === 0) {                                    // 45
      return this._getAll.apply(this, arguments);                    // 46
    } else if (arguments.length === 1) {                             // 47
      return this._getOne.apply(this, arguments);                    // 48
    }                                                                // 49
  },                                                                 // 50
                                                                     // 51
  length: function() {                                               // 52
    this._lengthDep.depend();                                        // 53
                                                                     // 54
    return this._values.length;                                      // 55
  },                                                                 // 56
                                                                     // 57
  slice: function(beg, end) {                                        // 58
    beg = _.isNumber(beg) ? beg : 0;                                 // 59
    end = _.isNumber(end) ? end : this._values.length;               // 60
                                                                     // 61
    var result = this._values.slice.apply(this._values, arguments);  // 62
                                                                     // 63
    if (beg < 0 || end < 0) {                                        // 64
      this._allDep.depend();                                         // 65
      return result;                                                 // 66
    }                                                                // 67
                                                                     // 68
    for (var i = beg; i < end; i++) {                                // 69
      this._ensureIndex(i);                                          // 70
      this._indexesDeps[i].depend();                                 // 71
    }                                                                // 72
                                                                     // 73
    return result;                                                   // 74
  },                                                                 // 75
                                                                     // 76
  // Modifiers.                                                      // 77
                                                                     // 78
  _setOne: function(index, value) {                                  // 79
    // If value has not changed than do nothing.                     // 80
    if (value === this._values[index]) {                             // 81
      return;                                                        // 82
    }                                                                // 83
                                                                     // 84
    // Get a current length of an array.                             // 85
    var length = this._values.length;                                // 86
    this._values[index] = value;                                     // 87
                                                                     // 88
    if (length < index) {                                            // 89
      this._lengthDep.changed();                                     // 90
    }                                                                // 91
    this._allDep.changed();                                          // 92
    changed(this._indexesDeps[index]);                               // 93
  },                                                                 // 94
                                                                     // 95
  _setAll: function(values) {                                        // 96
    var orgLength = this._values.length;                             // 97
    this._values = values.slice();                                   // 98
    var newLength = this._values.length;                             // 99
                                                                     // 100
    if (orgLength !== newLength) {                                   // 101
      this._lengthDep.changed();                                     // 102
    }                                                                // 103
    this._allDep.changed();                                          // 104
    var length = Math.max(orgLength, newLength);                     // 105
    for (var i = 0; i < length; i++) {                               // 106
      changed(this._indexesDeps[i]);                                 // 107
    }                                                                // 108
  },                                                                 // 109
                                                                     // 110
  set: function() {                                                  // 111
    if (arguments.length === 1 && _.isArray(arguments[0])) {         // 112
      this._setAll.apply(this, arguments);                           // 113
    } else if (arguments.length === 2) {                             // 114
      this._setOne.apply(this, arguments);                           // 115
    }                                                                // 116
  },                                                                 // 117
                                                                     // 118
  push: function() {                                                 // 119
    this._values.push.apply(this._values, arguments);                // 120
    var from = this._values.length - arguments.length;               // 121
                                                                     // 122
    this._lengthDep.changed();                                       // 123
    this._allDep.changed();                                          // 124
    for (var i = from; i < this._values.length; i++) {               // 125
      changed(this._indexesDeps[i]);                                 // 126
    }                                                                // 127
                                                                     // 128
    return length;                                                   // 129
  },                                                                 // 130
                                                                     // 131
  pop: function() {                                                  // 132
    if (this._values.length === 0) {                                 // 133
      return;                                                        // 134
    }                                                                // 135
                                                                     // 136
    var popped = this._values.pop();                                 // 137
    this._lengthDep.changed();                                       // 138
    this._allDep.changed();                                          // 139
    changed(this._indexesDeps[this._values.length]);                 // 140
                                                                     // 141
    return popped;                                                   // 142
  },                                                                 // 143
                                                                     // 144
  unshift: function() {                                              // 145
    this._values.unshift.apply(this._values, arguments);             // 146
                                                                     // 147
    this._lengthDep.changed();                                       // 148
    this._allDep.changed();                                          // 149
    for (var i = 0; i < this._values.length; i++) {                  // 150
      changed(this._indexesDeps[i]);                                 // 151
    }                                                                // 152
                                                                     // 153
    return this._values.length;                                      // 154
  },                                                                 // 155
                                                                     // 156
  shift: function() {                                                // 157
    if (this._values.length === 0) {                                 // 158
      return;                                                        // 159
    }                                                                // 160
                                                                     // 161
    var shifted = this._values.shift();                              // 162
                                                                     // 163
    this._lengthDep.changed();                                       // 164
    this._allDep.changed();                                          // 165
    for (var i = 0; i <= this._values.length; i++) {                 // 166
      changed(this._indexesDeps[i]);                                 // 167
    }                                                                // 168
                                                                     // 169
    return shifted;                                                  // 170
  }                                                                  // 171
});                                                                  // 172
                                                                     // 173
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['jagi:reactive-array'] = {}, {
  ReactiveArray: ReactiveArray
});

})();
