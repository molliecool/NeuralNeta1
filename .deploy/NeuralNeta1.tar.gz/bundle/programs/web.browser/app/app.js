var require = meteorInstall({"imports":{"components":{"authorization":{"authorization.html":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/components/authorization/authorization.html                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
                                                                                                                       // 1
      if (Meteor.isServer) return;                                                                                     // 2
                                                                                                                       // 3
      var templateUrl = "/imports/components/authorization/authorization.html";                                        // 4
      var template = " <div layout=\"column\" ng-controller=\"AuthorizationCtrl as authCtrl\"> <md-button flex ui-sref=\"login\" ng-hide=\"authCtrl.isLoggedIn()\">Login</md-button> <md-button flex ui-sref=\"register\" ng-hide=\"authCtrl.isLoggedIn()\">Sign up</md-button> <md-button flex ng-click=\"authCtrl.logout()\" ng-show=\"authCtrl.isLoggedIn()\">Logout</md-button> <div ng-if=\"authCtrl.isLoggedIn()\">{{ authCtrl.currentUser().emails[0].address }}</div> <div ng-if=\"authCtrl.isLoggedIn()\"> </div> </div> ";
                                                                                                                       // 6
      angular.module('angular-templates')                                                                              // 7
        .run(['$templateCache', function($templateCache) {                                                             // 8
          $templateCache.put(templateUrl, template);                                                                   // 9
        }]);                                                                                                           // 10
                                                                                                                       // 11
      module.exports = {};                                                                                             // 12
      module.exports.__esModule = true;                                                                                // 13
      module.exports.default = templateUrl;                                                                            // 14
                                                                                                                       // 15
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"authorization.js":["babel-runtime/helpers/classCallCheck","angular","angular-meteor","angular-ui-router","meteor/accounts-base","../login/login","../register/register","../password/password","../userPage/userPage","./authorization.html",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/components/authorization/authorization.js                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var angular;module.import('angular',{"default":function(v){angular=v}});var angularMeteor;module.import('angular-meteor',{"default":function(v){angularMeteor=v}});var uiRouter;module.import('angular-ui-router',{"default":function(v){uiRouter=v}});var Accounts;module.import('meteor/accounts-base',{"Accounts":function(v){Accounts=v}});var login;module.import('../login/login',{"login":function(v){login=v}});var register;module.import('../register/register',{"register":function(v){register=v}});var password;module.import('../password/password',{"password":function(v){password=v}});var userPage;module.import('../userPage/userPage',{"userPage":function(v){userPage=v}});var template;module.import('./authorization.html',{"default":function(v){template=v}});
                                                                                                                       // 1
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       //
                                                                                                                       // 5
                                                                                                                       // 6
                                                                                                                       // 7
                                                                                                                       // 8
                                                                                                                       //
                                                                                                                       // 10
                                                                                                                       //
                                                                                                                       // 12
                                                                                                                       //
var AuthorizationCtrl = function () {                                                                                  //
  function AuthorizationCtrl($scope) {                                                                                 // 15
                                                                                                                       //
    //$scope.viewModel(this);                                                                                          // 17
                                                                                                                       //
    _classCallCheck(this, AuthorizationCtrl);                                                                          // 15
  }                                                                                                                    // 19
                                                                                                                       //
  return AuthorizationCtrl;                                                                                            //
}();                                                                                                                   //
                                                                                                                       //
module.export("default",exports.default=(angular.module('authorization', [angularMeteor]).component('authorization', {
  templateUrl: 'imports/components/authorization/authorization.html'                                                   // 26
}).controller('AuthorizationCtrl', ['$scope', '$state', function ($scope, $state) {                                    // 25
  this.isLoggedIn = function () {                                                                                      // 29
    return !!Meteor.userId();                                                                                          // 30
  };                                                                                                                   // 31
                                                                                                                       //
  this.currentUser = function () {                                                                                     // 33
    return Meteor.user();                                                                                              // 34
  };                                                                                                                   // 35
                                                                                                                       //
  this.logout = function () {                                                                                          // 37
                                                                                                                       //
    Accounts.logout();                                                                                                 // 39
    $state.go('authorization');                                                                                        // 40
  };                                                                                                                   // 41
}]).config(config)));                                                                                                  // 42
                                                                                                                       //
function config($stateProvider) {                                                                                      // 45
  'ngInject';                                                                                                          // 46
                                                                                                                       //
  $stateProvider.state('authorization', {                                                                              // 47
    url: '/authorization',                                                                                             // 48
    template: '<authorization></authorization>'                                                                        // 49
  });                                                                                                                  // 47
}                                                                                                                      // 51
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"comments":{"comments.html":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/components/comments/comments.html                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
                                                                                                                       // 1
      if (Meteor.isServer) return;                                                                                     // 2
                                                                                                                       // 3
      var templateUrl = "/imports/components/comments/comments.html";                                                  // 4
      var template = "<!--\r\nmake this a service\r\nneed to be able to fetch all comments associated with a resource\r\nneed to be able to fetch comments associated with a user\r\nneed different ways to sort\r\nsummarize the results of comments/feedback\r\n\r\n\r\n--> <div> comments getting added </div> ";
                                                                                                                       // 6
      angular.module('angular-templates')                                                                              // 7
        .run(['$templateCache', function($templateCache) {                                                             // 8
          $templateCache.put(templateUrl, template);                                                                   // 9
        }]);                                                                                                           // 10
                                                                                                                       // 11
      module.exports = {};                                                                                             // 12
      module.exports.__esModule = true;                                                                                // 13
      module.exports.default = templateUrl;                                                                            // 14
                                                                                                                       // 15
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"comments.js":["babel-runtime/helpers/classCallCheck","angular","angular-meteor","../../api/resources.js","meteor/accounts-base","./comments.html",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/components/comments/comments.js                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var angular;module.import('angular',{"default":function(v){angular=v}});var angularMeteor;module.import('angular-meteor',{"default":function(v){angularMeteor=v}});var Resources;module.import('../../api/resources.js',{"Resources":function(v){Resources=v}});var Accounts;module.import('meteor/accounts-base',{"Accounts":function(v){Accounts=v}});var template;module.import('./comments.html',{"default":function(v){template=v}});
                                                                                                                       // 1
                                                                                                                       // 2
                                                                                                                       //
                                                                                                                       // 4
                                                                                                                       // 5
                                                                                                                       //
                                                                                                                       // 7
                                                                                                                       //
var CommentsCtrl = function () {                                                                                       //
  function CommentsCtrl($scope, $state, $mdMedia, $mdDialog) {                                                         // 10
    _classCallCheck(this, CommentsCtrl);                                                                               // 10
                                                                                                                       //
    $scope.viewModel(this);                                                                                            // 11
  }                                                                                                                    // 14
                                                                                                                       //
  return CommentsCtrl;                                                                                                 //
}();                                                                                                                   //
                                                                                                                       //
module.export("default",exports.default=(angular.module("comments", [])                                                // 17
//  .controller('commentsCtrl', ['$scope', CommentsCtrl])                                                              // 18
.component('comments', {                                                                                               // 17
  templateUrl: 'imports/components/comments/comments.html',                                                            // 20
  controller: ('CommentsCtrl', ['$scope', CommentsCtrl]),                                                              // 21
  controllerAs: 'commentsCtrl'                                                                                         // 22
}).factory('getComments', function (resourceID) {                                                                      // 19
  var commentsList = Comments.find({ ResourceID: resourceID } /**/).fetch()[0];                                        // 25
                                                                                                                       //
  console.log("got comments");                                                                                         // 27
  console.log(commentsList);                                                                                           // 28
                                                                                                                       //
  return commentsList;                                                                                                 // 30
})));                                                                                                                  // 31
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"login":{"login.html":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/components/login/login.html                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
                                                                                                                       // 1
      if (Meteor.isServer) return;                                                                                     // 2
                                                                                                                       // 3
      var templateUrl = "/imports/components/login/login.html";                                                        // 4
      var template = "<md-content ng-controller=\"LoginCtrl as login\" layout=\"row\" layout-align=\"center start\" layout-fill layout-margin> <md-whiteframe layout=\"column\" flex flex-md=\"50\" flex-lg=\"50\" flex-gt-lg=\"33\" class=\"md-whiteframe-z2\" layout-fill> <md-toolbar class=\"md-primary\" layout=\"column\" layout-align=\"end\" layout-fill> <div layout=\"row\" class=\"md-toolbar-tools md-toolbar-tools-bottom\"> <h3 class=\"md-display-1\"> Sign in </h3> </div> </md-toolbar> <div layout=\"column\" layout-fill layout-margin layout-padding> <div layout=\"row\" layout-fill layout-margin> <p class=\"md-body-2\"> Use existing account</p> </div> <div layout=\"row\" layout-fill layout-margin layout-padding layout-wrap> <md-button class=\"md-primary\"> <i class=\"material-icons\">whatshot</i> <span>Google</span> </md-button> <md-button class=\"md-primary\"> <i class=\"material-icons\">whatshot</i> <span>Facebook </span> </md-button> <md-button class=\"md-primary\"> <i class=\"material-icons\">whatshot</i> <span>Twitter </span> </md-button> </div> <md-divider class=\"inset\"></md-divider> <div layout=\"row\" layout-fill layout-margin> <p class=\"md-body-2\"> Sign in with your email</p> </div> <form name=\"loginForm\" layout=\"column\" layout-fill layout-padding layout-margin> <md-input-container> <label> Email </label> <input type=\"text\" ng-model=\"login.credentials.email\" aria-label=\"email\" required> </md-input-container> <md-input-container> <label> Password </label> <input type=\"password\" ng-model=\"login.credentials.password\" aria-label=\"password\" required> </md-input-container> <div layout=\"row\" layout-align=\"space-between center\"> <a class=\"md-button\" href=\"/password\">Forgot password?</a> <md-button class=\"md-raised md-primary\" ng-click=\"login.login()\" aria-label=\"login\" ng-disabled=\"login.loginForm.$invalid()\">Sign In </md-button> </div> </form> <md-toolbar ng-show=\"login.error\" class=\"md-warn\" layout=\"row\" layout-fill layout-padding layout-margin> <p class=\"md-body-1\">{{ login.error }}</p> </md-toolbar> <md-divider></md-divider> <div layout=\"row\" layout-align=\"center\"> <a class=\"md-button\" href=\"/register\">Need an account?</a> </div> </div> </md-whiteframe> </md-content> ";
                                                                                                                       // 6
      angular.module('angular-templates')                                                                              // 7
        .run(['$templateCache', function($templateCache) {                                                             // 8
          $templateCache.put(templateUrl, template);                                                                   // 9
        }]);                                                                                                           // 10
                                                                                                                       // 11
      module.exports = {};                                                                                             // 12
      module.exports.__esModule = true;                                                                                // 13
      module.exports.default = templateUrl;                                                                            // 14
                                                                                                                       // 15
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"login.js":["babel-runtime/helpers/classCallCheck","angular","angular-meteor","angular-ui-router","./login.html",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/components/login/login.js                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var angular;module.import('angular',{"default":function(v){angular=v}});var angularMeteor;module.import('angular-meteor',{"default":function(v){angularMeteor=v}});var uiRouter;module.import('angular-ui-router',{"default":function(v){uiRouter=v}});var template;module.import('./login.html',{"default":function(v){template=v}});
                                                                                                                       // 1
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       //
                                                                                                                       // 5
                                                                                                                       //
//import { Register } from '../register/register';                                                                     // 7
                                                                                                                       //
var LoginCtrl = function () {                                                                                          //
  function LoginCtrl($scope, $state) {                                                                                 // 10
    _classCallCheck(this, LoginCtrl);                                                                                  // 10
                                                                                                                       //
    this.$state = $state;                                                                                              // 11
  }                                                                                                                    // 12
                                                                                                                       //
  return LoginCtrl;                                                                                                    //
}();                                                                                                                   //
                                                                                                                       //
// create a module                                                                                                     // 16
                                                                                                                       //
                                                                                                                       //
module.export("default",exports.default=(angular.module('login', [angularMeteor, uiRouter]).component('login', {       // 17
  templateUrl: 'imports/components/login/login.html'                                                                   // 22
                                                                                                                       //
}).controller('LoginCtrl', ['$scope', '$state', function ($scope, $state) {                                            // 21
                                                                                                                       //
  this.credentials = {                                                                                                 // 27
    email: '',                                                                                                         // 28
    password: ''                                                                                                       // 29
  };                                                                                                                   // 27
                                                                                                                       //
  this.error = '';                                                                                                     // 32
                                                                                                                       //
  this.login = function () {                                                                                           // 35
    Meteor.loginWithPassword(this.credentials.email, this.credentials.password, function (error) {                     // 36
      if (error) {                                                                                                     // 38
        console.log(error.reason);                                                                                     // 39
      } else {                                                                                                         // 40
        $state.go('resourcesList');                                                                                    // 42
      }                                                                                                                // 43
    });                                                                                                                // 44
  };                                                                                                                   // 45
}]).config(config)));                                                                                                  // 46
                                                                                                                       //
function config($stateProvider) {                                                                                      // 49
  'ngInject';                                                                                                          // 50
                                                                                                                       //
  $stateProvider.state('login', {                                                                                      // 52
    url: '/login',                                                                                                     // 53
    template: '<login></login>'                                                                                        // 54
  });                                                                                                                  // 52
}                                                                                                                      // 56
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"navigation":{"navigation.html":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/components/navigation/navigation.html                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
                                                                                                                       // 1
      if (Meteor.isServer) return;                                                                                     // 2
                                                                                                                       // 3
      var templateUrl = "/imports/components/navigation/navigation.html";                                              // 4
      var template = " <div ng-controller=\"NavigationCtrl as navCtrl\" ng-cloak> <md-toolbar class=\"md-hue-2\"> <div class=\"md-toolbar-tools\"> <a aria-label=\"Neural Net Ninja\" ng-disabled=\"false\" ui-sref=\"resourcesList\"> <h2> <span>Neural Net Ninja</span> </h2> </a> <span flex></span> <md-button class=\"md-icon-button\" aria-label=\"Search\" ui-sref=\"resourcesList\"> <i class=\"material-icons\">search</i> </md-button> <md-button class=\"md-icon-button\" aria-label=\"Add\" ui-sref=\"resourceSubmit\"> <!-- grey this out --> <i class=\"material-icons\">add</i> </md-button> <md-button class=\"md-icon-button\" aria-label=\"Profile\" ui-sref=\"userPage\"> <!-- home page --> <i class=\"material-icons\">home</i> </md-button> <md-button class=\"md-icon-button\" aria-label=\"System\" ui-sref=\"authorization\"> <!-- make this a drop down--> <i class=\"material-icons\">person</i> </md-button> </div> </md-toolbar> </div> ";
                                                                                                                       // 6
      angular.module('angular-templates')                                                                              // 7
        .run(['$templateCache', function($templateCache) {                                                             // 8
          $templateCache.put(templateUrl, template);                                                                   // 9
        }]);                                                                                                           // 10
                                                                                                                       // 11
      module.exports = {};                                                                                             // 12
      module.exports.__esModule = true;                                                                                // 13
      module.exports.default = templateUrl;                                                                            // 14
                                                                                                                       // 15
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"navigation.js":["babel-runtime/helpers/classCallCheck","angular","angular-meteor","angular-ui-router","meteor/accounts-base","./navigation.html","../resourcesList/resourcesList","../resourceDetail/resourceDetail","../resourceSubmit/resourceSubmit",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/components/navigation/navigation.js                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var angular;module.import('angular',{"default":function(v){angular=v}});var angularMeteor;module.import('angular-meteor',{"default":function(v){angularMeteor=v}});var uiRouter;module.import('angular-ui-router',{"default":function(v){uiRouter=v}});var Accounts;module.import('meteor/accounts-base',{"Accounts":function(v){Accounts=v}});var template;module.import('./navigation.html',{"default":function(v){template=v}});var resourcesList;module.import('../resourcesList/resourcesList',{"default":function(v){resourcesList=v}});var resourceDetail;module.import('../resourceDetail/resourceDetail',{"default":function(v){resourceDetail=v}});var resourceSubmit;module.import('../resourceSubmit/resourceSubmit',{"default":function(v){resourceSubmit=v}});
                                                                                                                       // 1
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       //
                                                                                                                       // 5
                                                                                                                       //
                                                                                                                       // 7
                                                                                                                       //
                                                                                                                       // 9
                                                                                                                       // 10
                                                                                                                       // 11
/*import signUp from '../signUp/signUp';*/                                                                             // 12
                                                                                                                       //
var NavigationCtrl = function () {                                                                                     //
  function NavigationCtrl($scope) {                                                                                    // 17
    _classCallCheck(this, NavigationCtrl);                                                                             // 17
                                                                                                                       //
    $scope.viewModel(this);                                                                                            // 18
                                                                                                                       //
    this.helpers({});                                                                                                  // 20
  }                                                                                                                    // 23
                                                                                                                       //
  return NavigationCtrl;                                                                                               //
}();                                                                                                                   //
                                                                                                                       //
module.export("default",exports.default=(angular.module("navigation", [angularMeteor, uiRouter]).component("navigation", {
  templateUrl: 'imports/components/navigation/navigation.html'                                                         // 32
}).controller("NavigationCtrl", ["$scope", function ($scope) {                                                         // 31
                                                                                                                       //
  this.tab = 1;                                                                                                        // 36
                                                                                                                       //
  this.selectTab = function (setTab) {                                                                                 // 38
    this.tab = setTab;                                                                                                 // 39
  };                                                                                                                   // 40
                                                                                                                       //
  this.isSelected = function (checkTab) {                                                                              // 42
    return this.tab === checkTab;                                                                                      // 43
  };                                                                                                                   // 44
                                                                                                                       //
  this.currentUser = function () {                                                                                     // 46
    return Meteor.user();                                                                                              // 47
  };                                                                                                                   // 48
}]).config(config)));                                                                                                  // 49
                                                                                                                       //
function config($stateProvider, $urlRouterProvider, $locationProvider) {                                               // 53
                                                                                                                       //
  $urlRouterProvider.otherwise("/");                                                                                   // 55
                                                                                                                       //
  $stateProvider.state('resourcesList', {                                                                              // 57
    url: '/resourcesList',                                                                                             // 59
    template: '<resources-list></resources-list>'                                                                      // 60
  }).state('userPage', {                                                                                               // 58
    url: '/userPage',                                                                                                  // 63
    template: '<user-page></user-page>'                                                                                // 64
  }).state('resourceDetail/:rTitle', {                                                                                 // 62
    url: '/resourceDetail',                                                                                            // 67
    template: '<resource-detail></resource-detail>',                                                                   // 68
    params: {                                                                                                          // 69
      resourceTitle: null                                                                                              // 70
    }                                                                                                                  // 69
  }).state('smallCard', {                                                                                              // 66
    url: '/smallCard',                                                                                                 // 74
    templateURL: './templates/smallCard.html',                                                                         // 75
    controller: function () {                                                                                          // 76
      function controller($scope, resourceID) {                                                                        // 76
        this.res = Resources.find({ _id: resourceID }).fetch()[0];                                                     // 77
      }                                                                                                                // 78
                                                                                                                       //
      return controller;                                                                                               // 76
    }()                                                                                                                // 76
  });                                                                                                                  // 73
  //$locationProvider.html5Mode(true);                                                                                 // 80
                                                                                                                       //
  //for an unmatched url redirect to list                                                                              // 82
}                                                                                                                      // 84
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"password":{"password.html":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/components/password/password.html                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
                                                                                                                       // 1
      if (Meteor.isServer) return;                                                                                     // 2
                                                                                                                       // 3
      var templateUrl = "/imports/components/password/password.html";                                                  // 4
      var template = "<md-content layout=\"row\" layout-align=\"center start\" layout-fill layout-margin> <md-whiteframe layout=\"column\" flex flex-md=\"50\" flex-lg=\"50\" flex-gt-lg=\"33\" class=\"md-whiteframe-z2\" layout-fill> <md-toolbar class=\"md-primary md-tall\" layout=\"column\" layout-align=\"end\" layout-fill> <div layout=\"row\" class=\"md-toolbar-tools md-toolbar-tools-bottom\"> <h3 class=\"md-display-1\"> Reset Password</h3> </div> </md-toolbar> <div layout=\"column\" layout-fill layout-margin layout-padding> <div layout=\"row\" layout-fill layout-margin> <p class=\"md-body-2\">Enter your email so we can send you a reset link</p> </div> <form name=\"resetForm\" layout=\"column\" layout-fill layout-padding layout-margin> <md-input-container> <label> Email </label> <input type=\"text\" ng-model=\"password.credentials.email\" placeholder=\"email\" aria-label=\"email\" required> </md-input-container> <div layout=\"row\" layout-align=\"end center\"> <md-button class=\"md-raised md-primary\" ng-click=\"password.reset()\" aria-label=\"reset\" ng-disabled=\"password.resetForm.$invalid()\">Send Email </md-button> </div> </form> <md-toolbar ng-show=\"password.error\" class=\"md-warn\" layout=\"row\" layout-fill layout-padding layout-margin> <p class=\"md-body-1\">{{ password.error }}</p> </md-toolbar> <md-divider></md-divider> <div layout=\"row\" layout-align=\"center\"> <a class=\"md-button\" href=\"/login\">Sign in</a> </div> </div> </md-whiteframe> </md-content> ";
                                                                                                                       // 6
      angular.module('angular-templates')                                                                              // 7
        .run(['$templateCache', function($templateCache) {                                                             // 8
          $templateCache.put(templateUrl, template);                                                                   // 9
        }]);                                                                                                           // 10
                                                                                                                       // 11
      module.exports = {};                                                                                             // 12
      module.exports.__esModule = true;                                                                                // 13
      module.exports.default = templateUrl;                                                                            // 14
                                                                                                                       // 15
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"password.js":["angular","angular-meteor","angular-ui-router","meteor/accounts-base","./password.html",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/components/password/password.js                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var angular;module.import('angular',{"default":function(v){angular=v}});var angularMeteor;module.import('angular-meteor',{"default":function(v){angularMeteor=v}});var uiRouter;module.import('angular-ui-router',{"default":function(v){uiRouter=v}});var Accounts;module.import('meteor/accounts-base',{"Accounts":function(v){Accounts=v}});module.import('./password.html');
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       //
                                                                                                                       // 5
                                                                                                                       //
                                                                                                                       // 7
                                                                                                                       //
/*                                                                                                                     // 9
  reset() {                                                                                                            //
    Accounts.forgotPassword(this.credentials, this.$bindToContext((err) => {                                           //
      if (err) {                                                                                                       //
        this.error = err;                                                                                              //
      } else {                                                                                                         //
        this.$state.go('parties');                                                                                     //
      }                                                                                                                //
    }));                                                                                                               //
  }                                                                                                                    //
}                                                                                                                      //
                                                                                                                       //
// create a module                                                                                                     //
export default angular.module("password", [                                                                            //
  angularMeteor,                                                                                                       //
//  uiRouter                                                                                                           //
])                                                                                                                     //
  .component("password", {                                                                                             //
    templateUrl: `imports/components/password/password.html`,                                                          //
    controller: Ctrl                                                                                                   //
  })                                                                                                                   //
  .config(config);                                                                                                     //
                                                                                                                       //
function config($stateProvider) {                                                                                      //
  'ngInject';                                                                                                          //
                                                                                                                       //
  $stateProvider.state('password', {                                                                                   //
    url: '/password',                                                                                                  //
    template: '<password></password>'                                                                                  //
  });                                                                                                                  //
}*/                                                                                                                    //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"register":{"register.html":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/components/register/register.html                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
                                                                                                                       // 1
      if (Meteor.isServer) return;                                                                                     // 2
                                                                                                                       // 3
      var templateUrl = "/imports/components/register/register.html";                                                  // 4
      var template = "<md-content ng-controller=\"RegisterCtrl as register\" layout=\"row\" layout-align=\"center start\" layout-fill layout-margin> <md-whiteframe layout=\"column\" flex flex-md=\"50\" flex-lg=\"50\" flex-gt-lg=\"33\" class=\"md-whiteframe-z2\" layout-fill> <md-toolbar class=\"md-primary md-tall\" layout=\"column\" layout-align=\"end\" layout-fill> <div layout=\"row\" class=\"md-toolbar-tools md-toolbar-tools-bottom\"> <h3 class=\"md-display-1\"> Register a new account</h3> </div> </md-toolbar> <div layout=\"column\" layout-fill layout-margin layout-padding> <div layout=\"row\" layout-fill layout-margin> <p class=\"md-body-2\">Use your email?</p> </div> <form name=\"registerForm\" layout=\"column\" layout-fill layout-padding layout-margin> <md-input-container> <label> Email </label> <input type=\"text\" ng-model=\"register.credentials.email\" aria-label=\"email\" required> </md-input-container> <md-input-container> <label> Password </label> <input type=\"password\" ng-model=\"register.credentials.password\" aria-label=\"password\" required> </md-input-container> <div layout=\"row\" layout-align=\"end center\"> <md-button class=\"md-raised md-primary\" ng-click=\"register.register()\" aria-label=\"login\" ng-disabled=\"register.registerForm.$invalid()\">Register</md-button> </div> </form> <md-divider class=\"inset\"></md-divider> <div layout=\"row\" layout-fill layout-margin> <p class=\"md-body-2\"> Want to use an existing account? </p> </div> <div layout=\"row\" layout-fill layout-margin layout-padding layout-wrap> <md-button class=\"md-raised\"> <i class=\"material-icons\">whatshot</i> <span>Google</span> </md-button> <md-button class=\"md-raised\"> <i class=\"material-icons\">whatshot</i> <span>Facebook</span> </md-button> </div> <md-toolbar ng-show=\"register.error\" class=\"md-warn\" layout=\"row\" layout-fill layout-padding layout-margin> <p class=\"md-body-1\">{{ register.error.reason }}</p> </md-toolbar> <md-divider></md-divider> <div layout=\"row\" layout-align=\"center\"> <a class=\"md-button\" href ui-sref=\"/login\">Already a user?</a> </div> </div> </md-whiteframe> </md-content> ";
                                                                                                                       // 6
      angular.module('angular-templates')                                                                              // 7
        .run(['$templateCache', function($templateCache) {                                                             // 8
          $templateCache.put(templateUrl, template);                                                                   // 9
        }]);                                                                                                           // 10
                                                                                                                       // 11
      module.exports = {};                                                                                             // 12
      module.exports.__esModule = true;                                                                                // 13
      module.exports.default = templateUrl;                                                                            // 14
                                                                                                                       // 15
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"register.js":["babel-runtime/helpers/classCallCheck","angular","angular-meteor","angular-ui-router","meteor/accounts-base","./register.html",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/components/register/register.js                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var angular;module.import('angular',{"default":function(v){angular=v}});var angularMeteor;module.import('angular-meteor',{"default":function(v){angularMeteor=v}});var uiRouter;module.import('angular-ui-router',{"default":function(v){uiRouter=v}});var Accounts;module.import('meteor/accounts-base',{"Accounts":function(v){Accounts=v}});module.import('./register.html');
                                                                                                                       // 1
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       //
                                                                                                                       // 5
                                                                                                                       //
                                                                                                                       // 7
                                                                                                                       //
var RegisterCtrl = function () {                                                                                       //
  function RegisterCtrl($scope) {                                                                                      // 10
    _classCallCheck(this, RegisterCtrl);                                                                               // 10
  }                                                                                                                    // 12
                                                                                                                       //
  return RegisterCtrl;                                                                                                 //
}();                                                                                                                   //
                                                                                                                       //
// create a module                                                                                                     // 16
                                                                                                                       //
                                                                                                                       //
module.export("default",exports.default=(angular.module('register', [angularMeteor, uiRouter]).component('register', {
  templateUrl: 'imports/components/register/register.html'                                                             // 22
}).controller('RegisterCtrl', ['$scope', '$state', function ($scope, $state) {                                         // 21
                                                                                                                       //
  this.credentials = {                                                                                                 // 26
    email: '',                                                                                                         // 27
    password: ''                                                                                                       // 28
  };                                                                                                                   // 26
                                                                                                                       //
  this.error = '';                                                                                                     // 31
                                                                                                                       //
  this.register = function (event) {                                                                                   // 33
    //event.preventDefault();                                                                                          // 34
                                                                                                                       //
    Accounts.createUser(this.credentials, function (error) {                                                           // 36
      console.log("create user process initiated");                                                                    // 37
                                                                                                                       //
      if (error) {                                                                                                     // 39
        console.log(error.reason);                                                                                     // 40
      } else {                                                                                                         // 41
        $state.go('resourcesList');                                                                                    // 43
      }                                                                                                                // 44
    });                                                                                                                // 45
  };                                                                                                                   // 46
}]).config(config)));                                                                                                  // 47
                                                                                                                       //
function config($stateProvider) {                                                                                      // 50
  'ngInject';                                                                                                          // 51
                                                                                                                       //
  $stateProvider.state('register', {                                                                                   // 52
    url: '/register',                                                                                                  // 53
    template: '<register></register>'                                                                                  // 54
  });                                                                                                                  // 52
}                                                                                                                      // 56
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"resourceDetail":{"resourceDetail.html":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/components/resourceDetail/resourceDetail.html                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
                                                                                                                       // 1
      if (Meteor.isServer) return;                                                                                     // 2
                                                                                                                       // 3
      var templateUrl = "/imports/components/resourceDetail/resourceDetail.html";                                      // 4
      var template = " <div layout-align=\"center center\"> <md-content flex id=\"content\" style=\"max-width:960px\"> <md-card> <md-card-title flex layout=\"row\"> <span class=\"md-headline\">{{ rDetailCtrl.res.Title }}</span> </md-card-title> <div layout-margin class=\"md-subhead\">{{rDetailCtrl.res.Summary}}</div> <div layout=\"row\" layout-margin> <div flex layout=\"row\" class=\"end\" layout-margin> <div ng-repeat=\"n in [1,2,3,4,5]\"> <img ng-src=\"{{rDetailCtrl.res.Image}}\" style=\"height:5px;width:5px\"> </div> </div> <div flex layout=\"column\" layout-margin> <div class=\"md-title\">Type: {{rDetailCtrl.res.Type}}</div> <div class=\"md-subhead\">Subjects: {{rDetailCtrl.res.Subjects}}</div> <div>Recommended Ages: {{rDetailCtrl.res.Recommended_Ages}}</div> <div>Where to get it</div> <md-card-avatar> </md-card-avatar> </div> <div flex layout-margin layout=\"column\"> <div layout=\"row\"> <div flex layout=\"column\"> <div>Prep Time</div> <div>Diff. Instruction</div> <div>Common Core Tags</div> </div> <div flex layout=\"column\"> <div ng-repeat=\"n in [1,2,3,4,5]\"> <img ng-src=\"icons/icon_favorite-4.png\" style=\"height:25px;width:25px\"> </div> </div> </div> </div> </div> <md-card-content> <p>{{rDetailCtrl.res.Description}}</p> </md-card-content> <md-card-actions layout=\"row\" layout-align=\"end center\" class=\"layout-align-end-center layout-row\"> <!--button class=\"md-icon-button md-button md-ink-ripple\" type=\"button\" ng-transclude aria-label=\"Favorite\">\r\n              <md-icon ng-src=\"{{$ctrl.isFavorite(res._id) ? 'icons/icon_favorite-4.png' : 'icons/icon_favorite-2.png'}}\" class=\"ng-scope\" aria-hidden=\"true\"></md-icon--> <a href ng-click=\"$rDetailCtrl.toggleFavorite(res._id)\"> <img style=\"width:45px\" ng-src=\"{{rDetailCtrl.isFavorite(res._id) ? 'icons/icon_favorite-4.png' : 'icons/icon_favorite-2.png'}}\"> </a> <!--/button--> </md-card-actions> </md-card> </md-content> </div> ";
                                                                                                                       // 6
      angular.module('angular-templates')                                                                              // 7
        .run(['$templateCache', function($templateCache) {                                                             // 8
          $templateCache.put(templateUrl, template);                                                                   // 9
        }]);                                                                                                           // 10
                                                                                                                       // 11
      module.exports = {};                                                                                             // 12
      module.exports.__esModule = true;                                                                                // 13
      module.exports.default = templateUrl;                                                                            // 14
                                                                                                                       // 15
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"resourceDetail.js":["babel-runtime/helpers/classCallCheck","angular","angular-meteor","angular-ui-router","../../api/resources.js","./resourceDetail.html",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/components/resourceDetail/resourceDetail.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var angular;module.import('angular',{"default":function(v){angular=v}});var angularMeteor;module.import('angular-meteor',{"default":function(v){angularMeteor=v}});var uiRouter;module.import('angular-ui-router',{"default":function(v){uiRouter=v}});var Resources;module.import('../../api/resources.js',{"Resources":function(v){Resources=v}});var template;module.import('./resourceDetail.html',{"default":function(v){template=v}});
                                                                                                                       // 1
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       //
                                                                                                                       // 5
                                                                                                                       // 6
                                                                                                                       //
var ResourceDetailCtrl = function () {                                                                                 //
  function ResourceDetailCtrl($scope, $stateParams, $mdDialog, $mdMedia) {                                             // 9
    _classCallCheck(this, ResourceDetailCtrl);                                                                         // 9
                                                                                                                       //
    $scope.viewModel(this);                                                                                            // 10
                                                                                                                       //
    if (!$stateParams.resourceTitle) {                                                                                 // 12
      console.log('resource not found');                                                                               // 13
    }                                                                                                                  // 14
                                                                                                                       //
    this.resTitle = $stateParams.resourceTitle;                                                                        // 16
    console.log(this.resTitle);                                                                                        // 17
    console.log($stateParams.resourceTitle);                                                                           // 18
                                                                                                                       //
    this.res = Resources.find({ Title: this.resTitle }).fetch()[0];                                                    // 20
    console.log(Resources.find({ Title: this.resTitle }).fetch()[0]);                                                  // 21
                                                                                                                       //
    this.helpers({                                                                                                     // 23
      resources: function () {                                                                                         // 24
        function resources() {}                                                                                        // 23
                                                                                                                       //
        return resources;                                                                                              // 23
      }()                                                                                                              // 23
    });                                                                                                                // 23
  }                                                                                                                    // 28
                                                                                                                       //
  return ResourceDetailCtrl;                                                                                           //
}();                                                                                                                   //
                                                                                                                       //
Deps.autorun(function () {                                                                                             // 31
  Meteor.subscribe('resources');                                                                                       // 32
});                                                                                                                    // 33
                                                                                                                       //
module.export("default",exports.default=(angular.module('resourceDetail', [angularMeteor, uiRouter]).component('resourceDetail', {
  templateUrl: 'imports/components/resourceDetail/resourceDetail.html',                                                // 40
  controller: ['$scope', '$stateParams', ResourceDetailCtrl],                                                          // 41
  controllerAs: 'rDetailCtrl'                                                                                          // 42
}).config(config)));                                                                                                   // 39
                                                                                                                       //
function config($stateProvider) {}                                                                                     // 46
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"resourceSubmit":{"resourceSubmit.html":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/components/resourceSubmit/resourceSubmit.html                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
                                                                                                                       // 1
      if (Meteor.isServer) return;                                                                                     // 2
                                                                                                                       // 3
      var templateUrl = "/imports/components/resourceSubmit/resourceSubmit.html";                                      // 4
      var template = "<header> <h1>Submit Resource</h1> </header> <form name=\"submitResourceForm\" ng-controller=\"ResourceSubmitCtrl as rsCtrl\" ng-submit=\"rsCtrl.addResource(rsCtrl.submittedResource)\"> <div layout=\"row\" class=\"flex\"> <div layout=\"column\" class=\"flex\" style=\"padding-right:50px\"> <md-input-container class=\"flex\"> <label>Resource Name</label> <input type=\"text\" ng-model=\"rsCtrl.submittedResource.text\" placeholder=\"enter name\"> </md-input-container> <md-input-container class=\"flex\"> <label>Summary</label> <input type=\"text\" ng-model=\"rsCtrl.submittedResource.text\" placeholder=\"input summary\"> </md-input-container> </div> <upload-image files=\"resourceSubmit.resource.images\"></upload-image> </div> <div layout=\"row\" class=\"flex\"> <div layout=\"column\" class=\"flex\"> <md-radio-group> <label>What type of resource is it?</label> <md-radio-button ng-repeat=\"t in rsCtrl.typeOptions\" ng-model=\"rsCtrl.submittedResource.type\" ng-value=\"t\" aria-label=\"{{t}}\"> {{t}} </md-radio-button> </md-radio-group> </div> <div layout=\"column\" class=\"flex\"> <label>What subjects does it cover?</label> <br> <md-checkbox ng-repeat=\"t in rsCtrl.subjectOptions\" ng-value=\"t\" aria-label=\"{{t}}\"> {{t}} </md-checkbox> </div> </div> <md-button class=\"md-accent\"> <input type=\"submit\" value=\"Submit\"> </md-button> </form> ";
                                                                                                                       // 6
      angular.module('angular-templates')                                                                              // 7
        .run(['$templateCache', function($templateCache) {                                                             // 8
          $templateCache.put(templateUrl, template);                                                                   // 9
        }]);                                                                                                           // 10
                                                                                                                       // 11
      module.exports = {};                                                                                             // 12
      module.exports.__esModule = true;                                                                                // 13
      module.exports.default = templateUrl;                                                                            // 14
                                                                                                                       // 15
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"resourceSubmit.js":["babel-runtime/helpers/classCallCheck","angular","angular-meteor","../../api/resources.js","./resourceSubmit.html","../uploadImage/uploadImage",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/components/resourceSubmit/resourceSubmit.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var angular;module.import('angular',{"default":function(v){angular=v}});var angularMeteor;module.import('angular-meteor',{"default":function(v){angularMeteor=v}});var Resources;module.import('../../api/resources.js',{"Resources":function(v){Resources=v}});var template;module.import('./resourceSubmit.html',{"default":function(v){template=v}});var uploadImage;module.import('../uploadImage/uploadImage',{"default":function(v){uploadImage=v}});
                                                                                                                       // 1
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       //
                                                                                                                       // 5
                                                                                                                       // 6
                                                                                                                       //
var ResourceSubmitCtrl = function () {                                                                                 //
  function ResourceSubmitCtrl($scope) {                                                                                // 9
    _classCallCheck(this, ResourceSubmitCtrl);                                                                         // 9
                                                                                                                       //
    $scope.viewModel(this);                                                                                            // 10
                                                                                                                       //
    this.helpers({});                                                                                                  // 12
  }                                                                                                                    // 14
                                                                                                                       //
  return ResourceSubmitCtrl;                                                                                           //
}();                                                                                                                   //
                                                                                                                       //
module.export("default",exports.default=(angular.module('resourceSubmit', [angularMeteor]).component('resourceSubmit', {
  templateUrl: 'imports/components/resourceSubmit/resourceSubmit.html'                                                 // 21
}).controller('ResourceSubmitCtrl', ['$scope', function ($scope) {                                                     // 20
  //console.log("submit works");                                                                                       // 24
  this.submittedResource = {};                                                                                         // 25
  this.typeOptions = ["Book", "Digital Game", "Website", "Class Activity"];                                            // 26
  this.subjectOptions = ["Math", "History", "Science", "Health"];                                                      // 27
                                                                                                                       //
  this.addResource = function (submittedResource) {                                                                    // 29
    console.log("begin insert");                                                                                       // 30
    // Insert a task into the collection                                                                               // 31
    console.log(submittedResource.type);                                                                               // 32
                                                                                                                       //
    /*                                                                                                                 // 34
    onChange call a push function                                                                                      //
    need to push the subjects onto an array                                                                            //
    if a box is checked push it on the array                                                                           //
    else if a box is unchecked find and splice it from the array                                                       //
    */                                                                                                                 //
                                                                                                                       //
    Resources.insert({                                                                                                 // 43
      name: submittedResource.text,                                                                                    // 44
                                                                                                                       //
      description: submittedResource.description,                                                                      // 46
      type: submittedResource.type,                                                                                    // 47
      subject: submittedResource.subject,                                                                              // 48
      createdAt: new Date()                                                                                            // 49
    });                                                                                                                // 43
                                                                                                                       //
    this.clearForm = function () {}                                                                                    // 52
    /* for each field in this.submittedResource,                                                                       // 53
      set the child === ''                                                                                             //
      */                                                                                                               //
                                                                                                                       //
    // Clear form - replace this with a method                                                                         // 57
    ;this.submittedResource.text = '';                                                                                 // 52
    this.submittedResource.description = '';                                                                           // 59
    this.submittedResource.type = ''; //make this better                                                               // 60
    this.submittedResource.subject = '';                                                                               // 61
  };                                                                                                                   // 63
}]).config(config)));                                                                                                  // 64
                                                                                                                       //
function config($stateProvider) {                                                                                      // 67
  'ngInject';                                                                                                          // 68
                                                                                                                       //
  $stateProvider.state('resourceSubmit', {                                                                             // 69
    url: '/resourceSubmit',                                                                                            // 70
    template: '<resource-submit></resource-submit>'                                                                    // 71
  });                                                                                                                  // 69
}                                                                                                                      // 73
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"resourcesList":{"resourcesList.html":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/components/resourcesList/resourcesList.html                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
                                                                                                                       // 1
      if (Meteor.isServer) return;                                                                                     // 2
                                                                                                                       // 3
      var templateUrl = "/imports/components/resourcesList/resourcesList.html";                                        // 4
      var template = "<header> </header> <div> <md-content flex id=\"content\"> <div class=\"masonry\"> <md-card ng-repeat=\"res in rListCtrl.resources\" class=\"brick\"> <!--md-card-avatar>\r\n        </md-card-avatar--> <md-card-actions ng-click=\"rListCtrl.showAdvanced($event, res._id)\"> <!--a ui-sref=\"detail-page({resourceID: id})\">Go</a--> <img ng-src=\"{{res.Image}}\"> <md-card-title> <span class=\"md-headline\">{{ res.Title }}</span> </md-card-title> <md-card-content> <div layout=\"row\"> <div layout=\"column\" flex> <p>{{res.Recommended_Ages}}</p> <p>{{res.Type}}</p> <p>{{res.Subjects}}</p> <p>$$</p> </div> <div layout=\"column\" layout-align=\"start stretch\" flex> <p><i class=\"material-icons\">sentiment_very_satisfied</i>DI</p> <p><i class=\"material-icons\">sentiment_satisfied</i>Prep Time</p> <p><i class=\"material-icons\">sentiment_very_dissatisfied</i>Common Core</p> </div> </div> <div layout=\"row\"> <p>{{res.Summary}}</p> </div> </md-card-content> </md-card-actions> <md-card-actions layout=\"row\" layout-align=\"end center\" class=\"layout-align-end-center layout-row\"> <!--button class=\"md-icon-button md-button md-ink-ripple\" type=\"button\" ng-transclude aria-label=\"Favorite\">\r\n            <md-icon ng-src=\"{{$ctrl.isFavorite(res._id) ? 'icons/icon_favorite-4.png' : 'icons/icon_favorite-2.png'}}\" class=\"ng-scope\" aria-hidden=\"true\"></md-icon--> <a href ng-click=\"rListCtrl.toggleFavorite(res._id)\"> <img style=\"width:45px\" ng-src=\"{{rListCtrl.isFavorite(res._id) ? 'icons/icon_favorite-4.png' : 'icons/icon_favorite-2.png'}}\"> </a> <!--/button--> </md-card-actions> <!--comments ng-src=\"{{rListCtrl.comments(res._id)}}\"></comments--> </md-card> <!-- end res controller --> </div> </md-content> </div> ";
                                                                                                                       // 6
      angular.module('angular-templates')                                                                              // 7
        .run(['$templateCache', function($templateCache) {                                                             // 8
          $templateCache.put(templateUrl, template);                                                                   // 9
        }]);                                                                                                           // 10
                                                                                                                       // 11
      module.exports = {};                                                                                             // 12
      module.exports.__esModule = true;                                                                                // 13
      module.exports.default = templateUrl;                                                                            // 14
                                                                                                                       // 15
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"resourcesList.js":["babel-runtime/helpers/classCallCheck","angular","angular-meteor","../../api/resources.js","meteor/accounts-base","./resourcesList.html","../../templates/bigCard.html",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/components/resourcesList/resourcesList.js                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var angular;module.import('angular',{"default":function(v){angular=v}});var angularMeteor;module.import('angular-meteor',{"default":function(v){angularMeteor=v}});var Resources;module.import('../../api/resources.js',{"Resources":function(v){Resources=v}});var Accounts;module.import('meteor/accounts-base',{"Accounts":function(v){Accounts=v}});var template;module.import('./resourcesList.html',{"default":function(v){template=v}});var templateUrl;module.import('../../templates/bigCard.html',{"default":function(v){templateUrl=v}});
                                                                                                                       // 1
                                                                                                                       // 2
                                                                                                                       //
                                                                                                                       // 4
                                                                                                                       // 5
                                                                                                                       //
                                                                                                                       // 7
                                                                                                                       // 8
                                                                                                                       //
var ResourcesListCtrl = function () {                                                                                  //
  function ResourcesListCtrl($scope, $state, $mdMedia, $mdDialog) {                                                    // 14
    _classCallCheck(this, ResourcesListCtrl);                                                                          // 14
                                                                                                                       //
    $scope.viewModel(this);                                                                                            // 15
                                                                                                                       //
    //open the modal window                                                                                            // 17
                                                                                                                       //
    this.status = ' ';                                                                                                 // 19
    this.customFullscreen = $mdMedia('xs') || $mdMedia('sm');                                                          // 20
                                                                                                                       //
    this.showAdvanced = function (ev, resourceID) {                                                                    // 22
      console.log("called show advanced");                                                                             // 23
      this.res = Resources.find({ _id: resourceID }).fetch()[0];                                                       // 24
                                                                                                                       //
      var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;                               // 26
      $mdDialog.show({                                                                                                 // 27
        controller: DialogController,                                                                                  // 28
        templateUrl: templateUrl,                                                                                      // 29
        parent: angular.element(document.body),                                                                        // 30
        targetEvent: ev,                                                                                               // 31
        clickOutsideToClose: true,                                                                                     // 32
        fullscreen: useFullScreen,                                                                                     // 33
        locals: { res: this.res }                                                                                      // 34
      }).then(function (answer) {                                                                                      // 27
        console.log('then');                                                                                           // 37
      }, function () {                                                                                                 // 38
        console.log('then again');                                                                                     // 39
      });                                                                                                              // 41
      $scope.$watch(function () {                                                                                      // 42
        return $mdMedia('xs') || $mdMedia('sm');                                                                       // 43
      }, function (wantsFullScreen) {                                                                                  // 44
        $scope.customFullscreen = wantsFullScreen === true;                                                            // 45
      });                                                                                                              // 46
    };                                                                                                                 // 47
                                                                                                                       //
    this.helpers({                                                                                                     // 51
      resources: function () {                                                                                         // 52
        function resources() {                                                                                         // 51
          return Resources.find({});                                                                                   // 53
        }                                                                                                              // 54
                                                                                                                       //
        return resources;                                                                                              // 51
      }()                                                                                                              // 51
    });                                                                                                                // 51
                                                                                                                       //
    this.isFavorite = function (resourceID) {                                                                          // 57
      var flag = false;                                                                                                // 58
      for (res in meteorBabelHelpers.sanitizeForInObject(Meteor.user().favoritedResources)) {                          // 59
        //console.log(Meteor.user().favoritedResources[res]);                                                          // 60
        if (resourceID === Meteor.user().favoritedResources[res]) {                                                    // 61
          flag = true;                                                                                                 // 62
          break;                                                                                                       // 63
        }                                                                                                              // 64
      }                                                                                                                // 65
                                                                                                                       //
      if (flag) {                                                                                                      // 67
        //console.log("is favorite");                                                                                  // 68
        return true;                                                                                                   // 69
      } else {                                                                                                         // 70
        //console.log("not favorite");                                                                                 // 72
        return false;                                                                                                  // 73
      }                                                                                                                // 74
    };                                                                                                                 // 75
                                                                                                                       //
    this.toggleFavorite = function (resourceID) {                                                                      // 77
                                                                                                                       //
      if (this.isFavorite(resourceID)) {                                                                               // 79
        console.log("removing favorite");                                                                              // 80
        Meteor.call('removeFavorite', resourceID);                                                                     // 81
      } else {                                                                                                         // 82
        console.log("adding favorite");                                                                                // 84
        Meteor.call('addFavorite', resourceID);                                                                        // 85
      }                                                                                                                // 86
      console.log(Meteor.user().favoritedResources);                                                                   // 87
    };                                                                                                                 // 88
                                                                                                                       //
    this.openDetail = function (rTitle) {                                                                              // 90
      console.log("go to detail page");                                                                                // 91
      $state.go('resourceDetail/:rTitle', { resourceTitle: rTitle });                                                  // 92
    };                                                                                                                 // 93
                                                                                                                       //
    this.getComments = function () {                                                                                   // 95
      if (Meteor.user()) {                                                                                             // 96
        if (!this.comments) {                                                                                          // 97
          console.log("test test");                                                                                    // 98
          if (this.comments.length == 0) {                                                                             // 99
            return this.popComments();                                                                                 // 100
          }                                                                                                            // 101
        } else {                                                                                                       // 103
          return this.comments;                                                                                        // 105
        }                                                                                                              // 106
      }                                                                                                                // 107
    };                                                                                                                 // 108
  }                                                                                                                    // 111
                                                                                                                       //
  return ResourcesListCtrl;                                                                                            //
}();                                                                                                                   //
                                                                                                                       //
function DialogController($scope, $mdDialog, res) {                                                                    // 115
                                                                                                                       //
  $scope.res = res;                                                                                                    // 117
  console.log(res);                                                                                                    // 118
                                                                                                                       //
  this.hide = function () {                                                                                            // 120
    $mdDialog.hide();                                                                                                  // 121
  };                                                                                                                   // 122
  this.cancel = function () {                                                                                          // 123
    $mdDialog.cancel();                                                                                                // 124
  };                                                                                                                   // 125
  this.answer = function (answer) {                                                                                    // 126
    $mdDialog.hide(answer);                                                                                            // 127
  };                                                                                                                   // 128
}                                                                                                                      // 129
                                                                                                                       //
Deps.autorun(function () {                                                                                             // 131
  Meteor.subscribe('resources');                                                                                       // 132
  Meteor.subscribe('favoritedResources');                                                                              // 133
});                                                                                                                    // 134
                                                                                                                       //
module.export("default",exports.default=(angular.module("resourcesList", [angularMeteor]).component('resourcesList', {
  templateUrl: 'imports/components/resourcesList/resourcesList.html',                                                  // 141
  controller: ('ResourcesListCtrl', ['$scope', '$state', '$mdMedia', '$mdDialog', ResourcesListCtrl]),                 // 142
  controllerAs: 'rListCtrl'                                                                                            // 143
}).config(config)));                                                                                                   // 140
                                                                                                                       //
function config($stateProvider) {}                                                                                     // 147
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"uploadImage":{"uploadImage.html":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/components/uploadImage/uploadImage.html                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
                                                                                                                       // 1
      if (Meteor.isServer) return;                                                                                     // 2
                                                                                                                       // 3
      var templateUrl = "/imports/components/uploadImage/uploadImage.html";                                            // 4
      var template = " <div layout=\"column\" ng-controller=\"UploadImageCtrl as imageCtrl\"> <div ngf-drop ngf-select ng-model=\"files\" ngf-change=\"imageCtrl.addImages($files)\" ngf-drag-over-class=\"dragover\" class=\"drop-box\" ngf-multiple=\"false\" ngf-allow-dir=\"false\" accept=\"image/*\" ngf-pattern=\"image/*\" ngf-drop-available=\"true\"> <div>Click here to select image</div> <div> <strong>OR</strong> </div> <div>You can also drop image to here</div> </div> Files: <ul> <li ng-repeat=\"f in files\" style=\"font:smaller\">{{f.name}} {{f.$error}} {{f.$errorParam}}</li> </ul> Upload Log: <pre>{{log}}</pre> </div> ";
                                                                                                                       // 6
      angular.module('angular-templates')                                                                              // 7
        .run(['$templateCache', function($templateCache) {                                                             // 8
          $templateCache.put(templateUrl, template);                                                                   // 9
        }]);                                                                                                           // 10
                                                                                                                       // 11
      module.exports = {};                                                                                             // 12
      module.exports.__esModule = true;                                                                                // 13
      module.exports.default = templateUrl;                                                                            // 14
                                                                                                                       // 15
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"uploadImage.js":["babel-runtime/helpers/classCallCheck","angular","angular-meteor","ng-file-upload","./uploadImage.html",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/components/uploadImage/uploadImage.js                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var angular;module.import('angular',{"default":function(v){angular=v}});var angularMeteor;module.import('angular-meteor',{"default":function(v){angularMeteor=v}});var ngFileUpload;module.import('ng-file-upload',{"default":function(v){ngFileUpload=v}});var template;module.import('./uploadImage.html',{"default":function(v){template=v}});
                                                                                                                       // 1
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       //
                                                                                                                       // 5
                                                                                                                       //
var UploadImageCtrl = function () {                                                                                    //
  function UploadImageCtrl() {                                                                                         //
    _classCallCheck(this, UploadImageCtrl);                                                                            //
  }                                                                                                                    //
                                                                                                                       //
  return UploadImageCtrl;                                                                                              //
}();                                                                                                                   //
                                                                                                                       //
// create a module                                                                                                     // 23
module.export("default",exports.default=(angular.module('uploadImage', [angularMeteor, ngFileUpload]).component('uploadImage', {
  templateUrl: 'imports/components/uploadImage/uploadImage.html'                                                       // 29
}).controller('UploadImageCtrl', ['$scope', 'Upload', '$timeout', function ($scope, Upload, $timeout) {                // 28
                                                                                                                       //
  console.log("uploadimage created");                                                                                  // 36
                                                                                                                       //
  $scope.$watch('files', function () {                                                                                 // 38
    $scope.upload($scope.files);                                                                                       // 39
  });                                                                                                                  // 40
                                                                                                                       //
  $scope.$watch('file', function () {                                                                                  // 42
    if ($scope.file != null) {                                                                                         // 43
      $scope.files = [$scope.file];                                                                                    // 44
    }                                                                                                                  // 45
  });                                                                                                                  // 46
                                                                                                                       //
  $scope.log = '';                                                                                                     // 48
                                                                                                                       //
  $scope.upload = function (files) {                                                                                   // 51
    console.log("upload called");                                                                                      // 52
    /*  if (files && files.length) {                                                                                   // 53
          for (var i = 0; i < files.length; i++) {                                                                     //
            var file = files[i];                                                                                       //
            if (!file.$error) {                                                                                        //
              Upload.upload({                                                                                          //
                  url: 'api/files',                                                                                    //
                  data: {                                                                                              //
                    //username: $scope.username,                                                                       //
                    file: file                                                                                         //
                  }                                                                                                    //
              }).then(function (resp) {                                                                                //
                  $timeout(function() {                                                                                //
                      $scope.log = 'file: ' +                                                                          //
                      resp.config.data.file.name +                                                                     //
                      ', Response: ' + JSON.stringify(resp.data) +                                                     //
                      '\n' + $scope.log;                                                                               //
                  });                                                                                                  //
              }, null, function (evt) {                                                                                //
                  var progressPercentage = parseInt(100.0 *                                                            //
                  		evt.loaded / evt.total);                                                                           //
                  $scope.log = 'progress: ' + progressPercentage +                                                     //
                  	'% ' + evt.config.data.file.name + '\n' +                                                           //
                    $scope.log;                                                                                        //
              });                                                                                                      //
            }                                                                                                          //
          }                                                                                                            //
      }*/                                                                                                              //
  };                                                                                                                   // 80
}])));                                                                                                                 // 81
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"userPage":{"userPage.html":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/components/userPage/userPage.html                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
                                                                                                                       // 1
      if (Meteor.isServer) return;                                                                                     // 2
                                                                                                                       // 3
      var templateUrl = "/imports/components/userPage/userPage.html";                                                  // 4
      var template = " <md-content class=\"md-padding\" layout-xs=\"column\" layout=\"row\"> <div name=\"search bar row\" layout=\"row\"> </div> <div name=\"next row\" layout=\"row\"> <div name=\"activity and news column\" layout=\"column\"> </div> <div name=\"game and call to actions column\"> </div> <!-- other needs: groups, watchers, experts --> </div> <div class=\"masonry\"> <md-card ng-repeat=\"res in uPageCtrl.getFaves() track by $index\" class=\"brick\"> <!--md-card-avatar>\r\n        </md-card-avatar--> <md-card-header-text> <span class=\"md-title\">{{res.type}}</span> <span class=\"md-subhead\">{{res.Subjects}}</span> </md-card-header-text> <md-card-actions ng-click=\"uPageCtrl.openDetail(res.Title)\"> <!--a ui-sref=\"detail-page({resourceID: id})\">Go</a--> <img ng-src=\"{{res.Image}}\"> <md-card-title> <span class=\"md-headline\">{{ res.Title }}</span> </md-card-title> <md-card-content> <p>{{res.Summary}}</p> </md-card-content> </md-card-actions> <md-card-actions layout=\"row\" layout-align=\"end center\" class=\"layout-align-end-center layout-row\"> <!--button class=\"md-icon-button md-button md-ink-ripple\" type=\"button\" ng-transclude aria-label=\"Favorite\">\r\n            <md-icon ng-src=\"{{$ctrl.isFavorite(res._id) ? 'icons/icon_favorite-4.png' : 'icons/icon_favorite-2.png'}}\" class=\"ng-scope\" aria-hidden=\"true\"></md-icon--> <a href ng-click=\"uPageCtrl.toggleFavorite(res._id)\"> <img style=\"width:45px\" ng-src=\"{{uPageCtrl.isFavorite(res._id) ? 'icons/icon_favorite-4.png' : 'icons/icon_favorite-2.png'}}\"> </a> <!--/button--> </md-card-actions> </md-card> <!-- end res controller --> </div> </md-content> ";
                                                                                                                       // 6
      angular.module('angular-templates')                                                                              // 7
        .run(['$templateCache', function($templateCache) {                                                             // 8
          $templateCache.put(templateUrl, template);                                                                   // 9
        }]);                                                                                                           // 10
                                                                                                                       // 11
      module.exports = {};                                                                                             // 12
      module.exports.__esModule = true;                                                                                // 13
      module.exports.default = templateUrl;                                                                            // 14
                                                                                                                       // 15
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"userPage.js":["babel-runtime/helpers/classCallCheck","angular","angular-meteor","angular-ui-router","../../api/resources.js","meteor/accounts-base","meteor/session","./userPage.html","../../templates/bigCard.html",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/components/userPage/userPage.js                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var angular;module.import('angular',{"default":function(v){angular=v}});var angularMeteor;module.import('angular-meteor',{"default":function(v){angularMeteor=v}});var uiRouter;module.import('angular-ui-router',{"default":function(v){uiRouter=v}});var Resources;module.import('../../api/resources.js',{"Resources":function(v){Resources=v}});var Accounts;module.import('meteor/accounts-base',{"Accounts":function(v){Accounts=v}});var Session;module.import('meteor/session',{"Session":function(v){Session=v}});var template;module.import('./userPage.html',{"default":function(v){template=v}});var templateUrl;module.import('../../templates/bigCard.html',{"default":function(v){templateUrl=v}});
                                                                                                                       // 1
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       //
                                                                                                                       // 5
                                                                                                                       // 6
                                                                                                                       // 7
                                                                                                                       //
                                                                                                                       // 9
                                                                                                                       // 10
                                                                                                                       //
var UserPageCtrl = function () {                                                                                       //
  function UserPageCtrl($scope, $state, $reactive) {                                                                   // 14
    _classCallCheck(this, UserPageCtrl);                                                                               // 14
                                                                                                                       //
    $scope.viewModel(this);                                                                                            // 15
    $reactive(this).attach($scope);                                                                                    // 16
                                                                                                                       //
    this.favorites = []; //new ReactiveArray();                                                                        // 19
    this.initialized = false;                                                                                          // 20
                                                                                                                       //
    this.helpers({                                                                                                     // 22
      popFavorites: function () {                                                                                      // 23
        function popFavorites() {                                                                                      // 22
          if (Meteor.user()) {                                                                                         // 24
            currentUser = Meteor.user();                                                                               // 25
            Meteor.call('getFavorites', currentUser.favoritedResources, function (error, result) {                     // 26
              if (error) {                                                                                             // 27
                console.log(error.reason);                                                                             // 28
                return;                                                                                                // 29
              }                                                                                                        // 30
              Session.set('faves', result);                                                                            // 31
              console.log("result " + result);                                                                         // 32
            });                                                                                                        // 33
                                                                                                                       //
            this.favorites = Session.get('faves');                                                                     // 35
            console.log(this.favorites);                                                                               // 36
            return this.favorites;                                                                                     // 37
          }                                                                                                            // 39
        }                                                                                                              // 40
                                                                                                                       //
        return popFavorites;                                                                                           // 22
      }()                                                                                                              // 22
    });                                                                                                                // 22
                                                                                                                       //
    this.isFavorite = function (resourceID) {                                                                          // 45
      var flag = false;                                                                                                // 46
      for (res in meteorBabelHelpers.sanitizeForInObject(Meteor.user().favoritedResources)) {                          // 47
        //console.log(Meteor.user().favoritedResources[res]);                                                          // 48
        if (resourceID === Meteor.user().favoritedResources[res]) {                                                    // 49
          flag = true;                                                                                                 // 50
          break;                                                                                                       // 51
        }                                                                                                              // 52
      }                                                                                                                // 53
                                                                                                                       //
      if (flag) {                                                                                                      // 55
        //console.log("is favorite");                                                                                  // 56
        return true;                                                                                                   // 57
      } else {                                                                                                         // 58
        //console.log("not favorite");                                                                                 // 60
        return false;                                                                                                  // 61
      }                                                                                                                // 62
    };                                                                                                                 // 63
                                                                                                                       //
    this.toggleFavorite = function (resourceID) {                                                                      // 65
                                                                                                                       //
      if (this.isFavorite(resourceID)) {                                                                               // 67
        console.log("removing favorite");                                                                              // 68
        Meteor.call('removeFavorite', resourceID);                                                                     // 69
      } else {                                                                                                         // 70
        console.log("adding favorite");                                                                                // 72
        Meteor.call('addFavorite', resourceID);                                                                        // 73
      }                                                                                                                // 74
      console.log(Meteor.user().favoritedResources);                                                                   // 75
    };                                                                                                                 // 76
                                                                                                                       //
    this.getFaves = function () {                                                                                      // 78
      if (Meteor.user()) {                                                                                             // 79
        //  if(!this.favorites){                                                                                       // 80
        if (this.favorites.length == 0) {                                                                              // 81
          return this.popFavorites();                                                                                  // 82
        }                                                                                                              // 83
                                                                                                                       //
        // }                                                                                                           // 85
        else {                                                                                                         // 81
            return this.favorites;                                                                                     // 87
          }                                                                                                            // 88
      }                                                                                                                // 89
    };                                                                                                                 // 90
                                                                                                                       //
    this.openDetail = function (rID) {                                                                                 // 92
      console.log("go to detail page");                                                                                // 93
      $state.go('resourceDetail', { resourceID: rID });                                                                // 94
    };                                                                                                                 // 95
                                                                                                                       //
    this.userXP = function () {                                                                                        // 97
      if (Meteor.user()) {                                                                                             // 98
        var temp = Meteor.user().userXP;                                                                               // 99
        return temp;                                                                                                   // 100
      }                                                                                                                // 101
    };                                                                                                                 // 102
  }                                                                                                                    // 103
                                                                                                                       //
  return UserPageCtrl;                                                                                                 //
}() //end constructor                                                                                                  //
;                                                                                                                      //
                                                                                                                       //
Deps.autorun(function () {                                                                                             // 106
  Meteor.subscribe('userXP');                                                                                          // 107
  Meteor.subscribe('resources');                                                                                       // 108
  Meteor.subscribe('favoritedResources');                                                                              // 109
  //  Meteor.subscribe('favoriteObjects');  //not used                                                                 // 110
});                                                                                                                    // 111
                                                                                                                       //
module.export("default",exports.default=(angular.module('userPage', [angularMeteor, uiRouter]).component('userPage', {
  templateUrl: 'imports/components/userPage/userPage.html',                                                            // 119
  controller: ['$scope', '$state', '$reactive', UserPageCtrl],                                                         // 120
  controllerAs: 'uPageCtrl'                                                                                            // 121
})                                                                                                                     // 118
//.controller('UserPageCtrl', ['$scope', function($scope) {  }])                                                       // 123
.config(config)));                                                                                                     // 114
                                                                                                                       //
function config($stateProvider) {}                                                                                     // 126
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"api":{"comments.js":["meteor/mongo","meteor/aldeed:simple-schema","meteor/accounts-base","./resources.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/comments.js                                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({Comments:function(){return Comments}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var Accounts;module.import('meteor/accounts-base',{"Accounts":function(v){Accounts=v}});var Resources;module.import('./resources.js',{"Resources":function(v){Resources=v}});
                                                                                                                       // 2
                                                                                                                       //
                                                                                                                       // 4
                                                                                                                       // 5
                                                                                                                       //
var Comments = new Mongo.Collection('Comments');                                                                       // 8
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"resources.js":["meteor/mongo","meteor/aldeed:simple-schema","meteor/accounts-base","./comments.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/resources.js                                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({Resources:function(){return Resources}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});var Accounts;module.import('meteor/accounts-base',{"Accounts":function(v){Accounts=v}});var Comments;module.import('./comments.js',{"Comments":function(v){Comments=v}});
                                                                                                                       // 2
                                                                                                                       //
                                                                                                                       // 4
                                                                                                                       // 5
                                                                                                                       //
/*class ResourcesCollection extends Mongo.Collection {                                                                 // 7
                                                                                                                       //
}*/                                                                                                                    //
                                                                                                                       //
var Resources = new Mongo.Collection('Resources');                                                                     // 11
                                                                                                                       //
Meteor.methods({                                                                                                       // 14
  //add resource id to users list of favorited Resources                                                               // 15
  'addFavorite': function () {                                                                                         // 16
    function addFavorite(resourceID) {                                                                                 // 16
      var currentUserId = Meteor.userId();                                                                             // 17
      Meteor.users.update({ _id: currentUserId }, { $push: { favoritedResources: resourceID } });                      // 18
    }                                                                                                                  // 19
                                                                                                                       //
    return addFavorite;                                                                                                // 16
  }(),                                                                                                                 // 16
  /*                                                                                                                   // 20
    'getFavorites': function() {                                                                                       //
      //check if a resource is in the favorite list                                                                    //
      var currentUserId = Meteor.userId();                                                                             //
      return Meteor.users.find({ favoritedResources: resourceID });                                                    //
    },*/                                                                                                               //
                                                                                                                       //
  'removeFavorite': function () {                                                                                      // 27
    function removeFavorite(resourceID) {                                                                              // 27
      //removes ID from favorited list - mollie put checks in here                                                     // 28
      var currentUserId = Meteor.userId();                                                                             // 29
      Meteor.users.update({ _id: currentUserId }, { $pull: { favoritedResources: resourceID } });                      // 30
    }                                                                                                                  // 31
                                                                                                                       //
    return removeFavorite;                                                                                             // 27
  }(),                                                                                                                 // 27
                                                                                                                       //
  'getResource': function () {                                                                                         // 33
    function getResource(resourceID) {                                                                                 // 33
      // console.log(Resources.find({_id: resourceID}).fetch());                                                       // 34
      return Resources.find({ _id: resourceID }).fetch();                                                              // 35
    }                                                                                                                  // 36
                                                                                                                       //
    return getResource;                                                                                                // 33
  }(),                                                                                                                 // 33
                                                                                                                       //
  'getFavorites': function () {                                                                                        // 38
    function getFavorites(resourceIDs) {                                                                               // 38
      if (!this.userId) return null;                                                                                   // 39
      var favorites = [];                                                                                              // 40
                                                                                                                       //
      for (i in meteorBabelHelpers.sanitizeForInObject(resourceIDs)) {                                                 // 42
        var obj = Resources.find({ _id: resourceIDs[i] }).fetch();                                                     // 43
        //console.log("resourceID " + resourceIDs[i]);                                                                 // 44
        //console.log(obj[0]);                                                                                         // 45
        favorites.push(obj[0]);                                                                                        // 46
      }                                                                                                                // 47
                                                                                                                       //
      //console.log(favorites);                                                                                        // 49
      return favorites;                                                                                                // 50
    }                                                                                                                  // 51
                                                                                                                       //
    return getFavorites;                                                                                               // 38
  }()                                                                                                                  // 38
});                                                                                                                    // 14
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"startup":{"accounts-config.js":["meteor/accounts-base",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/accounts-config.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Accounts;module.import('meteor/accounts-base',{"Accounts":function(v){Accounts=v}});                               // 1
                                                                                                                       //
Accounts.ui.config({                                                                                                   // 3
  passwordSignupFields: 'USERNAME_ONLY'                                                                                // 4
});                                                                                                                    // 3
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"templates":{"bigCard.html":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/templates/bigCard.html                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
                                                                                                                       // 1
      if (Meteor.isServer) return;                                                                                     // 2
                                                                                                                       // 3
      var templateUrl = "/imports/templates/bigCard.html";                                                             // 4
      var template = "<md-dialog aria-label=\"\" ng-cloak> <md-dialog-content> <div> <md-card> <div layout=\"row\"> <!-- this is the image column --> <div flex=\"35\" layout=\"column\" layout-margin layout-padding> <img ng-src=\"{{res.Image}}\"> <div layout=\"row\" layout-margin> <div ng-repeat=\"n in [1,2,3]\"> <img ng-src=\"{{res.Image}}\"> </div> </div> <div> <p>Used by your connections</p> <div flex layout=\"row\"> <div flex ng-repeat=\"i in [1,2,3,4]\"> <div layout=\"column\" layout-align=\"center center\"> <i flex style=\"font-size:48px\" class=\"material-icons\">person</i> <div>{{res.Connections[i]}}</div> </div> </div> </div> <div flex layout=\"row\" layout-align=\"end start\"><a>more...</a></div> </div> </div> <!-- this is the start of the overview column--> <div layout=\"column\" layout-margin layout-padding flex> <div> <script>console.log()</script> <div class=\"md-headline\">{{res.Title}}</div> <div class=\"md-subhead\">{{res.Summary}}</div> </div> <div layout=\"row\" layout-margin> <!-- this is the first detail column --> <div layout=\"column\" style=\"padding-right:2em\" flex=\"50\"> <p>{{res.Type}}</p> <p>{{res.Subjects}}</p> <p>{{res.Recommended_Ages}}</p> <p>Where to get it</p> </div> <!-- this is the second detail column--> <div layout=\"column\" flex> <div layout=\"row\"> <div flex layout=\"column\"> <span style=\"display:inline-flex\"><i style=\"margin:.04em .5em 0 0\" class=\"material-icons\">sentiment_very_satisfied</i><p>Prep Time</p></span> <span style=\"display:inline-flex\"><i style=\"margin:.04em .5em 0 0\" class=\"material-icons\">sentiment_very_satisfied</i><p>Differentiation</p></span> <span style=\"display:inline-flex\"><i style=\"margin:.04em .5em 0 0\" class=\"material-icons\">sentiment_very_satisfied</i><p>Common Core</p></span> </div> </div> </div> </div> <span style=\"font-size:80%;margin-top:-1em\"><a ng-repeat=\"tag in res.CC_Tags track by $index\">{{tag}}, </a></span> <p>{{res.Description}}</p> <span flex style=\"display:inline-flex\" layout-align=\"space-between center\"> <md-button aria-label=\"Visit Website\" class=\"md-raised\">Visit Website</md-button> <md-button class=\"md-raised\">Post Review</md-button> <md-button aria-label=\"Visit Website\" class=\"md-icon-button\"><md-icon md-svg-icon=\"facebook\"></md-icon></md-button> <md-button aria-label=\"Visit Website\" class=\"md-icon-button\"><md-icon md-svg-icon=\"twitter\"></md-icon></md-button> <md-button aria-label=\"Visit Website\" class=\"md-icon-button\"><md-icon md-svg-icon=\"pinterest\"></md-icon></md-button> <md-button aria-label=\"Visit Website\" class=\"md-icon-button\"><md-icon md-svg-icon=\"share\"></md-icon></md-button> </span> </div> <!-- end overview column --> </div><!-- end first row --> <div layout-margin layout-padding> <!-- others like this row --> <p>Other resouces like this</p> <div layout=\"row\" layout-padding layout-margin layout-align=\"space-around center\"> <i style=\"font-size:48px\" class=\"material-icons\">keyboard_arrow_left</i> <div ng-repeat=\"n in [1,2,3,4,5]\"> <div>Fake Title</div> <img ng-src=\"{{res.Image}}\"> </div> <i style=\"font-size:48px\" class=\"material-icons\">keyboard_arrow_right</i> </div> <!-- comments section --> <hr> <div layout=\"row\"> <!-- left side --> <div layout=\"column\" flex=\"70\"> <div layout=\"row\" layout-align=\"start start\" layout-margin layout-padding> <div flex=\"20\" layout=\"column\" contenteditable=\"\" style=\"font-size:80%;padding-top:1em\"> <span style=\"display:inline-flex\"><i style=\"margin:.04em .5em 0 0\" class=\"material-icons\">sentiment_very_satisfied</i><p>Prep Time</p></span> <span style=\"display:inline-flex\"><i style=\"margin:.04em .5em 0 0\" class=\"material-icons\">sentiment_very_satisfied</i><p>Differentiation</p></span> <span style=\"display:inline-flex\"><i style=\"margin:.04em .5em 0 0\" class=\"material-icons\">sentiment_very_satisfied</i><p>Common Core</p></span> </div> <div style=\"display:block;margin-left:1em\" layout=\"column\" flex> <p>Mollie H.</p> <p>{{res.Description}}</p> </div> </div> <div layout=\"row\" layout-align=\"start start\" layout-margin layout-padding> <div flex=\"20\" layout=\"column\" style=\"font-size:80%;padding-top:1em\"> <span style=\"display:inline-flex\"><i style=\"margin:.04em .5em 0 0\" class=\"material-icons\">sentiment_very_satisfied</i><p>Prep Time</p></span> <span style=\"display:inline-flex\"><i style=\"margin:.04em .5em 0 0\" class=\"material-icons\">sentiment_very_satisfied</i><p>Differentiation</p></span> <span style=\"display:inline-flex\"><i style=\"margin:.04em .5em 0 0\" class=\"material-icons\">sentiment_very_satisfied</i><p>Common Core</p></span> </div> <div flex style=\"display:block;margin-left:1em\" layout=\"column\"> <p>Rich G.</p> <p>{{res.Description}}</p> </div> </div> </div> <!-- right side --> <div layout=\"column\" flex=\"30\" layout-padding> <p>Expert Reviews</p> </div> </div> </div> <md-card-actions layout=\"row\" layout-align=\"end center\" class=\"layout-align-end-center layout-row\"> <!--button class=\"md-icon-button md-button md-ink-ripple\" type=\"button\" ng-transclude aria-label=\"Favorite\">\r\n        <md-icon ng-src=\"{{$ctrl.isFavorite(res._id) ? 'icons/icon_favorite-4.png' : 'icons/icon_favorite-2.png'}}\" class=\"ng-scope\" aria-hidden=\"true\"></md-icon--> <a href ng-click=\"$rDetailCtrl.toggleFavorite(res._id)\"> <img style=\"width:45px\" ng-src=\"{{rDetailCtrl.isFavorite(res._id) ? 'icons/icon_favorite-4.png' : 'icons/icon_favorite-2.png'}}\"> </a> </md-card-actions> <!--/button--> </md-card> </div> </md-dialog-content> </md-dialog> ";
                                                                                                                       // 6
      angular.module('angular-templates')                                                                              // 7
        .run(['$templateCache', function($templateCache) {                                                             // 8
          $templateCache.put(templateUrl, template);                                                                   // 9
        }]);                                                                                                           // 10
                                                                                                                       // 11
      module.exports = {};                                                                                             // 12
      module.exports.__esModule = true;                                                                                // 13
      module.exports.default = templateUrl;                                                                            // 14
                                                                                                                       // 15
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"mup.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// mup.js                                                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/*                                                                                                                     // 1
to push:                                                                                                               //
cd to project folder                                                                                                   //
meteor build .deploy                                                                                                   //
cd to .deploy                                                                                                          //
mup init                                                                                                               //
mup.cmd setup                                                                                                          //
mup.cmd deploy                                                                                                         //
*/                                                                                                                     //
                                                                                                                       //
module.exports = {                                                                                                     // 11
  servers: {                                                                                                           // 12
    one: {                                                                                                             // 13
      host: '54.200.31.83',                                                                                            // 14
      username: 'ubuntu',                                                                                              // 15
      pem: 'C:/Users/molli_000/Documents/GitHub/NeuralNeta1/neuralnet-kp-actual.ppk'                                   // 16
      // password:                                                                                                     // 17
      // or leave blank for authenticate from ssh-agent                                                                // 18
    }                                                                                                                  // 13
  },                                                                                                                   // 12
                                                                                                                       //
  meteor: {                                                                                                            // 22
    name: 'NeuralNeta1',                                                                                               // 23
    path: 'C:/Users/molli_000/Documents/GitHub/NeuralNeta1/.deploy',                                                   // 24
    servers: {                                                                                                         // 25
      one: {}                                                                                                          // 26
    },                                                                                                                 // 25
    buildOptions: {                                                                                                    // 28
      serverOnly: true                                                                                                 // 29
    },                                                                                                                 // 28
    env: {                                                                                                             // 31
      //ROOT_URL: 'app.com',                                                                                           // 32
      MONGO_URL: 'mongodb://localhost/meteor'                                                                          // 33
    },                                                                                                                 // 31
    dockerImage: "abernix/meteord:base",                                                                               // 35
    //dockerImage: 'kadirahq/meteord',                                                                                 // 36
    deployCheckWaitTime: 60                                                                                            // 37
  },                                                                                                                   // 22
                                                                                                                       //
  mongo: {                                                                                                             // 40
    oplog: true,                                                                                                       // 41
    port: 27017,                                                                                                       // 42
    servers: {                                                                                                         // 43
      one: {}                                                                                                          // 44
    }                                                                                                                  // 43
  }                                                                                                                    // 40
};                                                                                                                     // 11
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mup1.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// mup1.js                                                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.exports = {                                                                                                     // 1
  servers: {                                                                                                           // 2
    one: {                                                                                                             // 3
      host: '54.200.31.83',                                                                                            // 4
      username: 'ubuntu',                                                                                              // 5
      pem: 'C:/Users/molli_000/Documents/GitHub/NeuralNeta1/neuralnet-kp-actual.ppk'                                   // 6
      // password:                                                                                                     // 7
      // or leave blank for authenticate from ssh-agent                                                                // 8
    }                                                                                                                  // 3
  },                                                                                                                   // 2
                                                                                                                       //
  meteor: {                                                                                                            // 12
    name: 'NeuralNeta1',                                                                                               // 13
    path: 'C:/Users/molli_000/Documents/GitHub/NeuralNeta1',                                                           // 14
    servers: {                                                                                                         // 15
      one: {}                                                                                                          // 16
    },                                                                                                                 // 15
    buildOptions: {                                                                                                    // 18
      serverOnly: true                                                                                                 // 19
    },                                                                                                                 // 18
    env: {                                                                                                             // 21
      ROOT_URL: 'app.com',                                                                                             // 22
      MONGO_URL: 'mongodb://localhost/meteor'                                                                          // 23
    },                                                                                                                 // 21
    //dockerImage: "abernix/meteord:base",                                                                             // 25
    //dockerImage: 'kadirahq/meteord'                                                                                  // 26
    deployCheckWaitTime: 60                                                                                            // 27
  },                                                                                                                   // 12
                                                                                                                       //
  mongo: {                                                                                                             // 30
    oplog: true,                                                                                                       // 31
    port: 27017,                                                                                                       // 32
    servers: {                                                                                                         // 33
      one: {}                                                                                                          // 34
    }                                                                                                                  // 33
  }                                                                                                                    // 30
};                                                                                                                     // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"client":{"main.html.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// client/main.html.js                                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
                                                                                                                       // 1
            Meteor.startup(function() {                                                                                // 2
              var attrs = {};                                                                                          // 3
              for (var prop in attrs) {                                                                                // 4
                document.body.setAttribute(prop, attrs[prop]);                                                         // 5
              }                                                                                                        // 6
            });                                                                                                        // 7
                                                                                                                       // 8
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":["angular","angular-meteor","angular-ui-router","angular-material","../imports/components/resourcesList/resourcesList","../imports/components/resourceDetail/resourceDetail","../imports/components/resourceSubmit/resourceSubmit","../imports/components/uploadImage/uploadImage","../imports/components/navigation/navigation","../imports/components/authorization/authorization","../imports/components/login/login","../imports/components/register/register","../imports/components/password/password","../imports/components/userPage/userPage","../imports/components/comments/comments","../imports/startup/accounts-config.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// client/main.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var angular;module.import('angular',{"default":function(v){angular=v}});var angularMeteor;module.import('angular-meteor',{"default":function(v){angularMeteor=v}});var uiRouter;module.import('angular-ui-router',{"default":function(v){uiRouter=v}});var ngMaterial;module.import('angular-material',{"default":function(v){ngMaterial=v}});var resourcesList;module.import('../imports/components/resourcesList/resourcesList',{"default":function(v){resourcesList=v}});var resourceDetail;module.import('../imports/components/resourceDetail/resourceDetail',{"default":function(v){resourceDetail=v}});var resourceSubmit;module.import('../imports/components/resourceSubmit/resourceSubmit',{"default":function(v){resourceSubmit=v}});var uploadImage;module.import('../imports/components/uploadImage/uploadImage',{"default":function(v){uploadImage=v}});var navigation;module.import('../imports/components/navigation/navigation',{"default":function(v){navigation=v}});var authorization;module.import('../imports/components/authorization/authorization',{"default":function(v){authorization=v}});var login;module.import('../imports/components/login/login',{"default":function(v){login=v}});var register;module.import('../imports/components/register/register',{"default":function(v){register=v}});var password;module.import('../imports/components/password/password',{"default":function(v){password=v}});var userPage;module.import('../imports/components/userPage/userPage',{"default":function(v){userPage=v}});var comments;module.import('../imports/components/comments/comments',{"default":function(v){comments=v}});module.import('../imports/startup/accounts-config.js');
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       // 4
                                                                                                                       //
                                                                                                                       // 6
                                                                                                                       // 7
                                                                                                                       // 8
                                                                                                                       // 9
                                                                                                                       // 10
/*import signUp from '../imports/components/signUp/signUp';*/                                                          // 11
                                                                                                                       // 12
                                                                                                                       // 13
                                                                                                                       // 14
                                                                                                                       // 15
                                                                                                                       // 16
                                                                                                                       // 17
                                                                                                                       //
                                                                                                                       // 19
                                                                                                                       //
angular.module('neuralnet', [angularMeteor, ngMaterial, 'accounts.ui', navigation.name, resourcesList.name, resourceDetail.name, resourceSubmit.name, uploadImage.name, authorization.name, login.name, register.name,
//  password.name,                                                                                                     // 33
userPage.name, comments.name]).config(config);                                                                         // 34
                                                                                                                       //
function config($stateProvider, $urlRouterProvider, $mdIconProvider, $mdThemingProvider) {                             // 40
                                                                                                                       //
  $mdThemingProvider.theme('default').primaryPalette('orange', {                                                       // 43
    'default': '400' }).accentPalette('purple');                                                                       // 45
                                                                                                                       //
  var iconPath = '/packages/planettraining_material-design-icons/bower_components/material-design-icons/sprites/svg-sprite/';
                                                                                                                       //
  $mdIconProvider.defaultIconSet('icons/mdi.svg')                                                                      // 54
  //.iconSet('mdi','icons/mdi.svg')                                                                                    // 56
  .iconSet('social', iconPath + 'svg-sprite-social.svg').iconSet('action', iconPath + 'svg-sprite-action.svg').iconSet('communication', iconPath + 'svg-sprite-communication.svg').iconSet('content', iconPath + 'svg-sprite-content.svg').iconSet('toggle', iconPath + 'svg-sprite-toggle.svg').iconSet('navigation', iconPath + 'svg-sprite-navigation.svg').iconSet('image', iconPath + 'svg-sprite-image.svg');
}                                                                                                                      // 64
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json",".css",".html"]});
require("./mup.js");
require("./mup1.js");
require("./client/main.html.js");
require("./client/main.js");